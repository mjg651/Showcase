//
//  PokemonAtkVC.h
//  tcgbrainstorm_beta
//
//  Created by Matt Guarneri on 4/5/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomPokeCard.h"

@interface PokemonAtkVC : UIViewController
@property (nonatomic) CustomPokeCard *card;

@end

