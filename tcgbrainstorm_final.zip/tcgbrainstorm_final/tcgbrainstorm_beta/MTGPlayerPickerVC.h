//
//  MTGPlayerPickerVC.h
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/12/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTGLifeCounterVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface MTGPlayerPickerVC : UIViewController
@property int life;
@end

NS_ASSUME_NONNULL_END
