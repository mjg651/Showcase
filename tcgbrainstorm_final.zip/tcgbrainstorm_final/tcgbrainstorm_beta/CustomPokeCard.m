//
//  NSObject+CustomPokeCard.m
//  tcgbrainstorm_beta
//
//  Created by Matt Guarneri on 4/7/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "CustomPokeCard.h"

@interface CustomPokeCard()

@end
@implementation CustomPokeCard



@end
