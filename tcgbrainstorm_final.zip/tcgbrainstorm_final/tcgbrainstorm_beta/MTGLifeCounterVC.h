//
//  MTGLifeCounterVC.h
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/12/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MTGLifeCounterVC : UIViewController
@property int players;
@property int life;

-(void) resetGame;
-(void) rollDice;
-(void) addDie:(CGFloat) x andY:(CGFloat) y;
-(void) finishDieRoll;
-(void) hideEverything;
-(void) showEverything;
-(NSString*) constructMessage;
@end

NS_ASSUME_NONNULL_END
