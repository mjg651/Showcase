//
//  PokeRulesVC.m
//  tcgbrainstorm_beta
//
//  Created by Matt Guarneri on 4/20/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "PokeRulesVC.h"

@interface PokeRulesVC () <UIScrollViewDelegate>
{
    UIScrollView* scrollView;
}
@property (weak, nonatomic) IBOutlet UINavigationBar *navigationBar;
@property (weak, nonatomic) IBOutlet UIButton *scrollToTop;
@property (weak, nonatomic) IBOutlet UIButton *zonesTOC;
@property (weak, nonatomic) IBOutlet UIButton *gameTOC;
@property (weak, nonatomic) IBOutlet UIButton *tapTOC;
@property (weak, nonatomic) IBOutlet UIButton *typeTOC;
@property (weak, nonatomic) IBOutlet UIButton *partsTOC;
@property (weak, nonatomic) IBOutlet UIButton *timingTOC;
@property (weak, nonatomic) IBOutlet UIButton *keywordTOC;
@end

@implementation PokeRulesVC

-(void) tableOfContentsSetup: (UIButton*) toc
{
    toc.hidden = NO;
    toc.layer.cornerRadius = 10;
    toc.clipsToBounds = true;
    toc.layer.borderWidth = 2.0;
    toc.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:15];
    toc.layer.borderColor = [[UIColor blackColor] CGColor];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.zonesTOC.hidden = YES;
    self.gameTOC.hidden = YES;
    self.tapTOC.hidden = YES;
    self.typeTOC.hidden = YES;
    self.partsTOC.hidden = YES;
    self.timingTOC.hidden = YES;
    self.keywordTOC.hidden = YES;
    self.scrollToTop.hidden = YES;
    self.navigationBar.hidden = YES;
    
    // get the phone width and phone height of the device we're using
    CGFloat phoneWidth = [UIScreen mainScreen].bounds.size.width;
    
    // initialize the scroll view
    scrollView = [[UIScrollView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    scrollView.bouncesZoom = YES;
    
    // add the scroll view as a subview to the main view
    [self.view addSubview:scrollView];
    
    // create a container view where all of the content will end up going
    UIView* containerView = [[UIView alloc] initWithFrame:CGRectZero];
    [scrollView addSubview:containerView];
    
    [containerView addSubview:self.navigationBar];
    self.navigationBar.hidden = NO;
    
    UIImageView* logoView = [[UIImageView alloc] initWithFrame:CGRectMake(phoneWidth/4-25, 50, 230, 80)];
    logoView.image = [UIImage imageNamed:@"pkmn_logo.png"];
    [containerView addSubview:logoView];
    
    // declare the rules header
    UILabel* rulesHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 135, phoneWidth,20)];
    rulesHeader.text = @"Rules";
    rulesHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:30];
    [containerView addSubview:rulesHeader];
    
    // declare the rules subtext
    UILabel* rulesText = [[UILabel alloc] initWithFrame:CGRectMake(0, 135, phoneWidth, 190)];
    rulesText.text = @"The Pokémon Trading Card Game often abbreviated as Pokémon TCG or just TCG, is a tabletop game that involves collecting, trading and playing with Pokémon themed playing cards. It has its own set of rules but uses many motifs and ideas derived from the video games. There are Pokémon cards for every species of Pokémon, as well as Trainer cards featuring characters, items and other themes of the franchise (each with a different use) and Energy cards to power various actions.";
    rulesText.font = [UIFont fontWithName:@"MPlantin" size:15];
    rulesText.numberOfLines = 10;
    [containerView addSubview:rulesText];
    
    // table of contents header
    UILabel* TOC = [[UILabel alloc] initWithFrame:CGRectMake(0, 310, phoneWidth,30)];
    TOC.text = @"Table of Contents";
    TOC.font = [UIFont fontWithName:@"Matrix-Bold" size:30];
    [containerView addSubview:TOC];
    
    // the following lines of code format the table of contents properly
    CGRect zonesTOCFrame = self.zonesTOC.frame;
    zonesTOCFrame.origin.x = 0;
    zonesTOCFrame.origin.y = 345;
    self.zonesTOC.frame = zonesTOCFrame;
    [self tableOfContentsSetup:self.zonesTOC];
    [containerView addSubview:self.zonesTOC];
    
    CGRect gameTOCFrame = self.gameTOC.frame;
    gameTOCFrame.origin.x = 0;
    gameTOCFrame.origin.y = 385;
    self.gameTOC.frame = gameTOCFrame;
    [self tableOfContentsSetup:self.gameTOC];
    [containerView addSubview:self.gameTOC];
    
    CGRect tapTOCFrame = self.tapTOC.frame;
    tapTOCFrame.origin.x = 0;
    tapTOCFrame.origin.y = 425;
    self.tapTOC.frame = tapTOCFrame;
    [self tableOfContentsSetup:self.tapTOC];
    [containerView addSubview:self.tapTOC];
    
    CGRect typeTOCFrame = self.typeTOC.frame;
    typeTOCFrame.origin.x = 0;
    typeTOCFrame.origin.y = 465;
    self.typeTOC.frame = typeTOCFrame;
    [self tableOfContentsSetup:self.typeTOC];
    [containerView addSubview:self.typeTOC];
    
    CGRect partsTOCFrame = self.partsTOC.frame;
    partsTOCFrame.origin.x = 0;
    partsTOCFrame.origin.y = 505;
    self.partsTOC.frame = partsTOCFrame;
    [self tableOfContentsSetup:self.partsTOC];
    [containerView addSubview:self.partsTOC];
    
    CGRect timingTOCFrame = self.timingTOC.frame;
    timingTOCFrame.origin.x = 0;
    timingTOCFrame.origin.y = 545;
    self.timingTOC.frame = timingTOCFrame;
    [self tableOfContentsSetup:self.timingTOC];
    [containerView addSubview:self.timingTOC];
    
    CGRect keywordTOCFrame = self.keywordTOC.frame;
    keywordTOCFrame.origin.x = 0;
    keywordTOCFrame.origin.y = 585;
    self.keywordTOC.frame = keywordTOCFrame;
    [self tableOfContentsSetup:self.keywordTOC];
    [containerView addSubview:self.keywordTOC];
    
    UILabel* zonesHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 675, phoneWidth,50)];
    zonesHeader.text = @"Zones: Areas of Play";
    zonesHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:30];
    [containerView addSubview:zonesHeader];
    
    UILabel* zonesIntro = [[UILabel alloc] initWithFrame:CGRectMake(0, 720, phoneWidth, 30)];
    zonesIntro.text = @"At any given time, every card is located in one of the following zones:";
    zonesIntro.font = [UIFont fontWithName:@"MPlantin" size:15];
    zonesIntro.numberOfLines = 2;
    [containerView addSubview:zonesIntro];
    
    UILabel* libraryHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 755, phoneWidth, 20)];
    libraryHeader.text = @"Hand";
    libraryHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    [containerView addSubview:libraryHeader];
    
    UILabel* libraryText = [[UILabel alloc] initWithFrame:CGRectMake(0, 725, phoneWidth, 200)];
    libraryText.text = @"Each player draws 7 cards at the beginning of the game and keeps their own hand hidden.Cards you draw go into your hand. Players may not look at their opponent’s hand unless a card says so.";
    libraryText.font = [UIFont fontWithName:@"MPlantin" size:15];
    libraryText.numberOfLines = 15;
    [containerView addSubview:libraryText];
    
    UILabel* graveyardHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 875, phoneWidth, 20)];
    graveyardHeader.text = @"Discard Pile";
    graveyardHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    [containerView addSubview:graveyardHeader];
    
    UILabel* graveyardText = [[UILabel alloc] initWithFrame:CGRectMake(0, 850, phoneWidth, 200)];
    graveyardText.text = @"Each player has their own discard pile. Cards taken out of play go to the discard pile, unless a card is played that says otherwise. Typically when a Pokémon is Knocked Out, it and any cards attached to it (such as Energy cards) are sent to its owner’s discard pile.";
    graveyardText.font = [UIFont fontWithName:@"MPlantin" size:15];
    graveyardText.numberOfLines = 15;
    [containerView addSubview:graveyardText];
    
    UILabel* handHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 1010, phoneWidth, 20)];
    handHeader.text = @"In Play";
    handHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    [containerView addSubview:handHeader];
    
    UILabel* handText = [[UILabel alloc] initWithFrame:CGRectMake(0, 1020, phoneWidth, 200)];
    handText.text = @"The in-play zone is shared by the players. Each player has two sections, divided into two rows, for their Pokémon: Active Pokemon and the Bench. The top row of a player’s in-play section is for the Active Pokémon. Each player starts with (and must always have) one Active Pokémon. Each player may have only one Active Pokémon at a time. If your opponent doesn’t have any more Pokémon in play, you win the game! The bottom row of a player’s in-play section is for the Benched Pokémon. Each player may have up to 5 Pokémon on the Bench at any one time. Any Pokémon in play other than the Active Pokémon must be put onthe Bench.";
    handText.font = [UIFont fontWithName:@"MPlantin" size:15];
    handText.numberOfLines = 15;
    [containerView addSubview:handText];
    
    UILabel* stackHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 1220, phoneWidth, 20)];
    stackHeader.text = @"Deck";
    stackHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    [containerView addSubview:stackHeader];
    
    UILabel* stackText = [[UILabel alloc] initWithFrame:CGRectMake(0, 1190, phoneWidth, 200)];
    stackText.text = @"Each player starts with their own deck of 60 cards to play the game. While both players know how many cards are in each deck, no one can look at or change the order of the cards in either player’s deck unless a card says so.";
    stackText.font = [UIFont fontWithName:@"MPlantin" size:15];
    stackText.numberOfLines = 15;
    [containerView addSubview:stackText];
    
    UILabel* battlefieldHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 1330, phoneWidth, 20)];
    battlefieldHeader.text = @"Prize Cards";
    battlefieldHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    [containerView addSubview:battlefieldHeader];

    UILabel* battlefieldText = [[UILabel alloc] initWithFrame:CGRectMake(0, 1310, phoneWidth, 200)];
    battlefieldText.text = @"Each player has their own Prize cards. Prize cards are 6 cards that each player sets aside, face down, from the top of their own deck while setting up to play. When you Knock Out an opposing Pokémon, you take one of your Prize cards and put it into your hand. If you’re the first one to take your last Prize card, you win!";
    battlefieldText.font = [UIFont fontWithName:@"MPlantin" size:15];
    battlefieldText.numberOfLines = 15;
    [containerView addSubview:battlefieldText];
    
    UILabel* beginHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 1610, phoneWidth,50)];
    beginHeader.text = @"Playing the Game";
    beginHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:29];
    [containerView addSubview:beginHeader];
    
    UILabel* beginText = [[UILabel alloc] initWithFrame:CGRectMake(0, 1655, phoneWidth, 350)];
    beginText.text = @"YOU CAN WIN THE GAME IN THREE WAYS: \n 1) Take all of your Prize cards \n 2) Knock Out all of your opponent’s in-play Pokémon \n 3) If your opponent has no cards in their deck at the beginning of their turn. \n \n SETTING UP TO PLAY: \n 1) Shake hands with your opponent. \n 2) Flip a coin. The winner of the coin flip decides which player goes first. \n 3) Shuffle your 60-card deck and draw the top 7 cards. \n 4) Check to see if you have any Basic Pokémon in your hand (You can call a mulligan if you have no basics). \n 5) Put one of your Basic Pokémon face down as your Active Pokémon. \n 6) Put up to 5 more Basic Pokémon face down on your Bench. \n 7) Put the top 6 cards of your deck off to the side face down as your Prize cards. \n 8) Both players flip their Active and Benched Pokémon face up and start the game! ";
    beginText.font = [UIFont fontWithName:@"MPlantin" size:15];
    beginText.numberOfLines = 25;
    [containerView addSubview:beginText];
    
    UILabel* tapHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 2000, phoneWidth,50)];
    tapHeader.text = @"Typical Turn";
    tapHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:30];
    [containerView addSubview:tapHeader];
    
    UILabel* tapSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 2050, phoneWidth, 20)];
    tapSubheader.text = @"Draw a Card";
    tapSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    [containerView addSubview:tapSubheader];
    
    UILabel* tapText = [[UILabel alloc] initWithFrame:CGRectMake(0, 1920, phoneWidth, 350)];
    tapText.text = @"Start your turn by drawing a card. If there are no cards in your deck at the beginning of your turn and you cannot draw a card,the game is over, and your opponent wins.";
    tapText.font = [UIFont fontWithName:@"MPlantin" size:15];
    tapText.numberOfLines = 25;
    [containerView addSubview:tapText];
    
    UILabel* manaSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 2140, phoneWidth, 20)];
    manaSubheader.text = @"Do Any Of These In Any Order:";
    manaSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    [containerView addSubview:manaSubheader];
    
    UILabel* manaText1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 2200, phoneWidth, 850)];
    manaText1.text = @"A) Put Basic Pokémon cards from your hand onto your Bench (as many as you want).Choose a Basic Pokémon card from your hand and put it face up onto your Bench. Your Bench can hold up to 5 Pokémon, so you can only do this if there are 4 or fewer Pokémon on your Bench. \n B) Evolve Pokémon (as many as you want).If you have a card in your hand that says “Evolves from X,” and X is the name of a Pokémon you had in play at the beginning of your turn, you may play that card in your hand on top of Pokémon X. This is called “evolving” a Pokémon.You may evolve a Basic Pokémon to a Stage 1 Pokémon or a Stage 1 Pokémon to a Stage 2 Pokémon. When a Pokémon evolves, it keeps all cards attached to it (Energy cards, Evolution cards, etc.) and any damage counters on it. Any effects of attacks or Special Conditions affecting the Pokémon—such as Asleep, Confused,or Poisoned—end when it evolves. A Pokémon cannot evolve during it's first turn on the field (including newly evolved Pokémon).\n C) Attach an Energy card from your hand to one of your Pokémon (once per turn). \n D) Play Trainer cards.When you play any Trainer card, do what it says and obey the rule at the bottom of the card, and then put it in the discard pile. You can play as many Item cards as you like. Supporter cards are played like Item cards, but you can play only one Supporter card each turn. Stadium cards have a few special rules: A Stadium card stays in play when you play it. Only one Stadium card can be in play at a time—if a new one comes into play, discard the old one and end its effects.You can’t play a Stadium card if a card with the same name is already in play. You can play only one Stadium card each turn. \n E) If your Active Pokémon has lots of damage counters on it, you might want to retreat it and bring out a Pokémon from your Bench to fight instead. You may also want to do this if you have a strong Pokémon on the Bench ready to battle! To retreat, you must discard 1 Energy from your Active Pokémon for each Energy listed in it's retreat cost. Keep all damage counters and all attached cards with each Pokémon when they switch. Pokémon that are Asleep or Paralyzed cannot retreat.When your Active Pokémon goes to your Bench (whether it retreated or got there some other way), some things do go away—Special Conditions and any effects from attacks.If you retreat, you can still attack that turn with your new Active Pokémon. \n F)Use Abilities (as many as you want). Some Pokémon have special Abilities they can use. Many of them can be used before you attack. Each Ability is different, though, so read carefully to see how each one works. Some work only if a condition is met, while others work all the time even without you using them. Be sure to announce which Abilities you are using so your opponent knows what you’re doing." ;
    manaText1.font = [UIFont fontWithName:@"MPlantin" size:15];
    manaText1.numberOfLines = 75;
    [containerView addSubview:manaText1];
    
    UILabel* abSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 3100, phoneWidth, 20)];
    abSubheader.text = @"Attack and End Your Turn";
    abSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    [containerView addSubview:abSubheader];
    
    UILabel* abText = [[UILabel alloc] initWithFrame:CGRectMake(0, 3150, phoneWidth, 950)];
    abText.text = @"When you are ready to attack, first make sure that you’ve done everything in step 2 that you want to do. Once you attack, yourturn is over, so you can’t go back later! Attacking has three simple steps. Once you get it figured out, you’ll be attacking like a pro in no time! You cannot attack on the first turn.\n A) You need the right amount of Energy attached to a Pokémon for it to attack.For example, look at Litten. Its Bite attack costs 1 fire Energy, so you must have at least 1 fire Energy attached to Litten to use this attack. Next, its Flare attack costs 1 fire Energy and 1 colorless Energy. You need at least 2 Energy attached to Litten to use Flare, and the fire Energy symbol means  means you need to have 1 fire Energy attached. However, the colorless energy means that any type of Energy can be used for the second Energy.  Once you are sure you have the right Energy, announce which attack you are using. \n B) Check Weakness and Resistance of your opponent’s Active Pokémon. Some Pokémon have Weakness or Resistance to Pokémon of certain types, marked in the lower-left corner of the card.  If the attack does damage, your opponent’s Active Pokémon takes more damage if it has Weakness to the attacker’s type. It takes less damage from a Pokémon if it has Resistance to that Pokémon’s type. \n C) PUT damage counters on your opponent’s Active Pokémon.When you attack, put 1 damage counter on your opponent’s Active Pokémon for each 10 damage your Pokémon’s attack does (written to the right of the attack name). In the example above, Litten’s Bite attack does 10 damage. Then, Rowlet’s Weakness of ×2 to fire  Pokémon makes that 10 ×2 = 20 damage. So put 2 damage counters on Rowlet. If an attack says to do something else, be sure to do that, too!Your attack is complete, so check to see if any Pokémon were Knocked Out by the attack. Some attacks can damage more than one Pokémon, and sometimes they can even damage the Attacking Pokémon! So, make sure to check every Pokémon that was affected by the attack.If a Pokémon has total damage at least equal to its HP (for example, 5 or more damage counters on a Pokémon with 50 HP), it is Knocked Out. If a player’s Pokémon is Knocked Out, that player puts it and all cards attached to it in the discard pile. That player’s opponent takes 1 of their own Prize cards and puts it into their hand.The player whose Pokémon was Knocked Out chooses a new Active Pokémon from their Bench. If your opponent can’t do this because their Bench is empty (or for any other reason), you win the game! If your opponent still has Pokémon in play, but you just took your last Prize card, you also win the game!\n D) Next, you take care of a few special things during the between-turns step. Before the game continues to the next player, take care of Special Conditions in this order: \n 1. POISONED 2. BURNED 3. ASLEEP 4. PARALYZED \n Then, apply the effects of any Abilities (or anything else that a card states must happen between turns). After both players have done these things, check to see if any affected Pokémon were Knocked Out. Then, start the next player’s turn!";
    abText.font = [UIFont fontWithName:@"MPlantin" size:15];
    abText.numberOfLines = 85;
    [containerView addSubview:abText];
    
    UILabel* typesHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 4105, phoneWidth,50)];
    typesHeader.text = @"Special Conditions";
    typesHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:30];
    [containerView addSubview:typesHeader];
    
    UILabel* landText = [[UILabel alloc] initWithFrame:CGRectMake(0, 4125, phoneWidth, 200)];
    landText.text = @"Some attacks leave the Active Pokémon Asleep, Burned, Confused, Paralyzed, or Poisoned—these are called “Special Conditions.” They can only happen to an Active Pokémon—when a Pokémon goes to the Bench, you remove all its Special Conditions. Evolving a Pokémon also removes its Special Conditions.";
    landText.font = [UIFont fontWithName:@"MPlantin" size:15];
    landText.numberOfLines = 15;
    [containerView addSubview:landText];
    
    UILabel* creatureSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 4300, phoneWidth, 20)];
    creatureSubheader.text = @"Asleep";
    creatureSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    [containerView addSubview:creatureSubheader];
    
    UILabel* creatureText = [[UILabel alloc] initWithFrame:CGRectMake(0, 4280, phoneWidth, 200)];
    creatureText.text = @"Turn the Pokémon counterclockwise to show that it is Asleep.If a Pokémon is Asleep, it cannot attack or retreat. Between turns, flip a coin. If you flip heads, the Pokémon wakes up (turn the card right-side up), but if you flip tails, it stays Asleep.";
    creatureText.font = [UIFont fontWithName:@"MPlantin" size:15];
    creatureText.numberOfLines = 15;
    [containerView addSubview:creatureText];
    
    UILabel* enchantmentSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 4420, phoneWidth, 20)];
    enchantmentSubheader.text = @"Burned";
    enchantmentSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    [containerView addSubview:enchantmentSubheader];
    
    UILabel* enchantmentText = [[UILabel alloc] initWithFrame:CGRectMake(0, 4420, phoneWidth, 200)];
    enchantmentText.text = @"A Burned Pokémon takes damage between turns, but the condition might heal on its own. When a Pokémon is Burned, put a Burn marker on it. Between turns, put 2 damage counters on your Burned Pokémon, then flip a coin. If heads, remove the Special Condition Burned.A Pokémon cannot have two Burn markers; if an attack gives it another Burn marker, the new Burned Condition simply replaces the old one. Make sure your Burn markers look different from your damage counters.";
    enchantmentText.font = [UIFont fontWithName:@"MPlantin" size:15];
    enchantmentText.numberOfLines = 15;
    [containerView addSubview:enchantmentText];
    
    UILabel* artifactSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 4600, phoneWidth, 20)];
    artifactSubheader.text = @"Confused";
    artifactSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    [containerView addSubview:artifactSubheader];
    
    UILabel* artifactText = [[UILabel alloc] initWithFrame:CGRectMake(0, 4560, phoneWidth, 250)];
    artifactText.text = @"Turn a Confused Pokémon with its head pointed toward you to show that it is Confused.If your Pokémon is Confused, you must flip a coin before attacking with it. If heads, the attack works normally. If tails, the attack doesn’t happen, and you put 3 damage counters on your Confused Pokémon.";
    artifactText.font = [UIFont fontWithName:@"MPlantin" size:15];
    artifactText.numberOfLines = 20;
    [containerView addSubview:artifactText];
    
    UILabel* sorcerySubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 4750, phoneWidth, 20)];
    sorcerySubheader.text = @"Paralyzed";
    sorcerySubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    [containerView addSubview:sorcerySubheader];
    
    UILabel* sorceryText = [[UILabel alloc] initWithFrame:CGRectMake(0, 4730, phoneWidth, 200)];
    sorceryText.text = @"Turn the Paralyzed Pokémon clockwise to show that it is Paralyzed.If a Pokémon is Paralyzed, it cannot attack or retreat. Remove the Special Condition Paralyzed during the between-turns step if your Pokémon was Paralyzed since the beginning of your last turn.";
    sorceryText.font = [UIFont fontWithName:@"MPlantin" size:15];
    sorceryText.numberOfLines = 15;
    [containerView addSubview:sorceryText];
    
    UILabel* partsHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 4880, phoneWidth,50)];
    partsHeader.text = @"Poisoned";
    partsHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    [containerView addSubview:partsHeader];
    
    UILabel* beginningText = [[UILabel alloc] initWithFrame:CGRectMake(0, 4850, phoneWidth, 300)];
    beginningText.text = @"A Poisoned Pokémon takes damage between turns. When a Pokémon is Poisoned, put a Poison marker on it. Between turns, put a damage counter on your Poisoned Pokémon.A Pokémon cannot have two Poison markers; if an attack gives it another Poison marker, the new Poisoned Condition simply replaces the old one. Make sure your Poison markers look different from your damage counters.";
    beginningText.font = [UIFont fontWithName:@"MPlantin" size:15];
    beginningText.numberOfLines = 15;
    [containerView addSubview:beginningText];
    
    containerView.frame = CGRectMake(0, 0, phoneWidth, 5100);
    scrollView.contentSize = containerView.frame.size;
    
    // add the scroll to top button to the main view
    [self.view addSubview:self.scrollToTop];
    
    // set the scroll view delegate to self
    scrollView.delegate = self;
}

// scroll to the Zones: Areas of Play section
- (IBAction)zonesTOCPicker:(id)sender {
    [scrollView setContentOffset:CGPointMake(0, 675) animated:YES];
}

// scroll to Beginning and Ending the Game section
- (IBAction)beginningTOCPicker:(id)sender {
    [scrollView setContentOffset:CGPointMake(0, 1610) animated:YES];
}

// scroll to Tapping, Untapping and Mana section
- (IBAction)tappingTOCPicker:(id)sender {
    [scrollView setContentOffset:CGPointMake(0, 2000) animated:YES];
}

// scroll to Types of Cards section
- (IBAction)typesTOCPicker:(id)sender {
    [scrollView setContentOffset:CGPointMake(0, 4105) animated:YES];
}

// scroll to Parts of a Turn section
- (IBAction)partsTOCPicker:(id)sender {
    [scrollView setContentOffset:CGPointMake(0, 5335) animated:YES];
}

// scroll to Timing and the Stack section
- (IBAction)timingTOCPicker:(id)sender {
    [scrollView setContentOffset:CGPointMake(0, 6675) animated:YES];
}

// scroll to Keyword Abilities section
- (IBAction)keywordTOCPicker:(id)sender {
    [scrollView setContentOffset:CGPointMake(0, 8690) animated:YES];
}

// scroll to top functionality
- (IBAction)scrollToTop:(id)sender {
    [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
}

// when the back button is pressed
- (IBAction)backButtonPressed:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

// detect when the scroll view is scrolling
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView.contentOffset.y > [UIScreen mainScreen].bounds.size.height)
        self.scrollToTop.hidden = NO;
    else
        self.scrollToTop.hidden = YES;
}

@end
