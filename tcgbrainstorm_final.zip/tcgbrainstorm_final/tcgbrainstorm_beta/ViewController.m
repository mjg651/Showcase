//
//  ViewController.m
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/4/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>

@interface ViewController ()
@property (strong,nonatomic) AVAudioPlayer *audioPlayer;
@end

@implementation ViewController

// Input: void
// Output: boolean value
// Function to hide the status bar
- (BOOL)prefersStatusBarHidden {
    return YES;
}

// Input: void
// Output: void
// Do any additional setup after loading the view
- (void)viewDidLoad {
    // call the superview's viewDidLoad method
    [super viewDidLoad];
}

// Input: UIStoryboardSegue*
// Output: IBAction
// Return to this view controller when unwinding from view controllers deeper in the navigation
- (IBAction)unwindToViewControllerNameHere:(UIStoryboardSegue *)segue {
    
}

// Input: id but will be a button
// Output: IBAction
// When you choose Magic the Gathering, play a sound and advance to the Magic the Gathering main menu
- (IBAction)magicButtonPressed:(id)sender {
    
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"OOT_MainMenu_Select" ofType:@"wav" ];
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    [self.audioPlayer play];
}

// Input: id but will be a button
// Output: IBAction
// When you choose Pokemon, play a sound and advance to the Pokemon main menu
- (IBAction)pokeButtonPressed:(id)sender {
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"pokeBeep" ofType:@"wav" ];
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    [self.audioPlayer play];
}

@end
