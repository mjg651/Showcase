//
//  PokeMainMenuVC.m
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/11/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "PokeMainMenuVC.h"
#import <AVFoundation/AVFoundation.h>

@interface PokeMainMenuVC ()
//Buttons for each screen
@property (weak, nonatomic) IBOutlet UIButton *cardCreate;
@property (weak, nonatomic) IBOutlet UIButton *hpCalc;
@property (weak, nonatomic) IBOutlet UIButton *rules;
@property (strong,nonatomic) AVAudioPlayer *audioPlayer;//Calle to play sound
@end

@implementation PokeMainMenuVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //Set boundaries of buttons
    self.cardCreate.layer.cornerRadius = 15;
    self.cardCreate.clipsToBounds = true;
    self.cardCreate.layer.borderWidth = 1.0;
    self.cardCreate.layer.borderColor = [[UIColor blackColor] CGColor];
    
    self.hpCalc.layer.cornerRadius = 15;
    self.hpCalc.clipsToBounds = true;
    self.hpCalc.layer.borderWidth = 1.0;
    self.hpCalc.layer.borderColor = [[UIColor blackColor] CGColor];
    
    self.rules.layer.cornerRadius = 15;
    self.rules.clipsToBounds = true;
    self.rules.layer.borderWidth = 1.0;
    self.rules.layer.borderColor = [[UIColor blackColor] CGColor];
}
- (IBAction)backButtonPressed:(id)sender {
    //Go back to main menu. Play a cancel sound effect
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"pokeBack" ofType:@"wav" ];
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    [self.audioPlayer play];
    [self dismissViewControllerAnimated:YES completion:nil];
}
//PLAY SOUND WHEN PRESSED BY USING AUDIO PLAYER
- (IBAction)customCardPressed:(id)sender {
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"pokeBeep" ofType:@"wav" ];
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    [self.audioPlayer play];
}

- (IBAction)hpPressed:(id)sender {
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"pokeBeep" ofType:@"wav" ];
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    [self.audioPlayer play];
}
- (IBAction)rulesPressed:(id)sender {
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"pokeBeep" ofType:@"wav" ];
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    [self.audioPlayer play];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
