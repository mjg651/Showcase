//
//  NSObject+CustomPokeCard.h
//  tcgbrainstorm_beta
//
//  Created by Matt Guarneri on 4/7/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
//Contains all the variables for each facet of the Pokemon card
@interface CustomPokeCard: NSObject
@property (strong, nonatomic) NSString *name;//name of the card
@property (strong, nonatomic) NSString *hp;//HP of the card
@property (strong, nonatomic) NSString *type;//type of the card; used to set BG
//Different facets of each attack; name; damage; type(cost) and description
@property (strong, nonatomic) NSString *atk1name;
@property (strong, nonatomic) NSString *atk1dmg;
@property (strong, nonatomic) NSString *atk1type;
@property (strong, nonatomic) NSString *atk1desc;
@property (strong, nonatomic) NSString *atk2name;
@property (strong, nonatomic) NSString *atk2dmg;
@property (strong, nonatomic) NSString *atk2type;
@property (strong, nonatomic) NSString *atk2desc;
@property (nonatomic) int retreat;//retreat cost
@property (strong, nonatomic) NSString *author;//Keeps track illus
@property (strong, nonatomic) NSString *weaktype;//how weak
@property (strong, nonatomic) NSString *weakamt;//what weak against
@property (strong, nonatomic) NSString *strongtype;//what strong against
@property (strong, nonatomic) NSString *strongamt;//how strong
@property (strong, nonatomic) NSString *flavor;//flavor text
@property (strong, nonatomic) UIImage* image;//uploaded image

@end

NS_ASSUME_NONNULL_END
