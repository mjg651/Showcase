//
//  NSObject+PokeFinalVC.m
//  tcgbrainstorm_beta
//
//  Created by Matt Guarneri on 4/5/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "PokeFinalVC.h"
#import "PokemonCardCreateVC.h"
#import <AVFoundation/AVFoundation.h>

@interface PokeFinalVC ()
@property (weak, nonatomic) IBOutlet UISegmentedControl *retreatSegment;//used to indicate the 5 possible vars for retreating
//Textfields here are used to display user input with the following methods
@property (weak, nonatomic) IBOutlet UITextField *weaknessText;
@property (weak, nonatomic) IBOutlet UITextField *strengthText;
@property (weak, nonatomic) IBOutlet UITextField *authorBox;
@property (weak, nonatomic) IBOutlet UITextField *flavorBox;
@property (weak, nonatomic) IBOutlet UITextField *displaywk;
@property (weak, nonatomic) IBOutlet UITextField *displayres;
@property (weak, nonatomic) IBOutlet UIButton *next;
@property (strong,nonatomic) AVAudioPlayer *audioPlayer;
@property (weak, nonatomic) IBOutlet UILabel *illuswarning;
@property (weak, nonatomic) IBOutlet UILabel *flavorwarning;




@end

@implementation PokeFinalVC
//Go back; play sound with audioPlayer
- (IBAction)backButtonPressed:(id)sender {
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"pokeBack" ofType:@"wav" ];
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    [self.audioPlayer play];
    [self dismissViewControllerAnimated:YES completion:nil];
}

//set next button size and set all fields to that of the card objects :)
-(void)viewDidLoad{
    [super viewDidLoad];
    self.next.layer.cornerRadius = 15;
    self.next.clipsToBounds = true;
    self.next.layer.borderWidth = 1.0;
    self.next.layer.borderColor = [[UIColor blackColor] CGColor];
    
    self.displaywk.enabled=NO;
    self.displayres.enabled=NO;
    self.weaknessText.enabled=NO;
    self.strengthText.enabled=NO;
    
    self.authorBox.text = self.card.author;
    self.flavorBox.text = self.card.flavor;
    self.displaywk.text= self.card.weaktype;
    self.weaknessText.text= self.card.weakamt;
    self.strengthText.text=self.card.strongamt;
    self.displayres.text=self.card.strongtype;
 self.retreatSegment.selectedSegmentIndex=self.card.retreat;
    //flash warning
    self.flavorwarning.hidden=YES;
    self.illuswarning.hidden=YES;
    
}
//Called when retreat segment index selected and sets card retreat amount. Defaults to 0
- (IBAction)retreatSegment:(id)sender {
    if(_retreatSegment.selectedSegmentIndex==0){
        _card.retreat=0;
    }else if(_retreatSegment.selectedSegmentIndex==1){
        _card.retreat=1;
    }else if (_retreatSegment.selectedSegmentIndex==2){
        _card.retreat=2;
    }else if (_retreatSegment.selectedSegmentIndex==3){
        _card.retreat=3;
    }else if(_retreatSegment.selectedSegmentIndex==4){
        _card.retreat=4;
    }
    
}
//stepper used to indicate how weak the card is to the selected type
- (IBAction)weakStepper:(UIStepper *)sender {
    double val = [sender value];
    [_weaknessText setText:[NSString stringWithFormat:@"%d",(int)val ]];
     _card.weakamt = [NSString stringWithFormat:@"%d", (int)val];
}
//stepper used to indicat how stront the card is to the selected type
- (IBAction)strongStepper:(UIStepper *)sender {
    double val = [sender value];
    [_strengthText setText:[NSString stringWithFormat:@"%d",(int)val ]];
     _card.strongamt=[NSString stringWithFormat:@"%d", (int)val];
}
//author textbox ended editing
- (IBAction)authorChanged:(id)sender {
    _card.author=_authorBox.text;
}
//segue to CardCreateVC; set it's card to the current one
- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    PokemonCardCreateVC* dest = [segue destinationViewController];
    dest.card = self.card;
}
//flavor text begain editing; scroll screen up disable author box
- (IBAction)flavorTextBegan:(id)sender {
    [self textFieldDidBeginEditing: _flavorBox];
    _authorBox.enabled=NO;
}

//check flavor input length and set if under limit or lock and display a warning
- (IBAction)flavorText:(id)sender {
    _authorBox.enabled=YES;
    if(self.flavorBox.text.length>60){
        self.flavorwarning.hidden=NO;
        self.next.enabled=NO;
    }else{
        self.flavorwarning.hidden=YES;
        self.next.enabled=YES;
        _card.flavor= _flavorBox.text;
    }
     [self textFieldDidEndEditing: _flavorBox];
}
//check illus input length and set if under limit or lock and dispaly a warning
- (IBAction)illustratorBox:(id)sender {
    if(self.authorBox.text.length>20){
        self.illuswarning.hidden=NO;
        self.next.enabled=NO;
    }else{
        self.illuswarning.hidden=YES;
        self.next.enabled=YES;
         _card.author=_authorBox.text;
    }
}

//These methods change the cards weakness type and then display it
- (IBAction)lightwk:(id)sender {
    _card.weaktype=@"Lightning";
    _displaywk.text=@"Lightning";
}
- (IBAction)firewk:(id)sender {
    _card.weaktype=@"Fire";
    _displaywk.text=@"Fire";
}
- (IBAction)waterwk:(id)sender {
    _card.weaktype=@"Water";
    _displaywk.text=@"Water";
}
- (IBAction)metalwk:(id)sender {
     _card.weaktype=@"Metal";
    _displaywk.text=@"Steel";
}
- (IBAction)psywk:(id)sender {
    _card.weaktype=@"Psychic";
    _displaywk.text=@"Psychic";
}
- (IBAction)fightwk:(id)sender {
    _card.weaktype=@"Fighting";
    _displaywk.text=@"Fighting";
}
- (IBAction)colwk:(id)sender {
     _card.weaktype=@"Colorless";
    _displaywk.text=@"Normal";
}
- (IBAction)grasswk:(id)sender {
    _card.weaktype=@"Grass";
    _displaywk.text=@"Grass";
}
//these methods display the cards resistant type and then display it
- (IBAction)lightst:(id)sender {
    _card.strongtype=@"Lightning";
    _displayres.text=@"Lightning";
}
- (IBAction)firest:(id)sender {
    _card.strongtype=@"Fire";
     _displayres.text=@"Fire";
}
- (IBAction)waterst:(id)sender {
     _card.strongtype=@"Water";
     _displayres.text=@"Water";
}
- (IBAction)metalst:(id)sender {
     _card.strongtype=@"Metal";
     _displayres.text=@"Steel";
}
- (IBAction)psyst:(id)sender {
     _card.strongtype=@"Psychic";
     _displayres.text=@"Psychic";
}
- (IBAction)fightst:(id)sender {
     _card.strongtype=@"Fighting";
     _displayres.text=@"Fighting";
}
- (IBAction)colst:(id)sender {
     _card.strongtype=@"Colorless";
     _displayres.text=@"Normal";
}
//Clear both the weakness type and its amount
- (IBAction)clearWeakness:(id)sender {
    _card.weakamt=nil;
    _card.weaktype=nil;
    _displaywk.text=@"";
    _weaknessText.text=@"";
}
//Clear both the strength type and its amount
- (IBAction)clearResistance:(id)sender {
    _card.strongamt  =nil;
    _card.strongtype  =nil;
    _displayres.text=@"";
    _strengthText.text=@"";
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self animateTextField:textField up:YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField:textField up:NO];
}

-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    const int movementDistance = -170; // tweak as needed
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? movementDistance : -movementDistance);
    
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}


- (IBAction)nextPressed:(id)sender {
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"pokeBeep" ofType:@"wav" ];
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    [self.audioPlayer play];
}

@end
