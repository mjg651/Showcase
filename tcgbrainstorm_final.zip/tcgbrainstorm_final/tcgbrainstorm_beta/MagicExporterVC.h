//
//  MagicExporterVC.h
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/5/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomMagicCard.h"

NS_ASSUME_NONNULL_BEGIN

@interface MagicExporterVC : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (strong, nonatomic) CustomMagicCard* card;

-(NSString*) getCardTemplate;
-(UIImage*) renderImage;
@end

NS_ASSUME_NONNULL_END
