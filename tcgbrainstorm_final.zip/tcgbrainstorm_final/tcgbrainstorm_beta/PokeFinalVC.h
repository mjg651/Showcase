//
//  PokeFinalVC.h
//  tcgbrainstorm_beta
//
//  Created by Matt Guarneri on 4/5/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomPokeCard.h"

@interface PokeFinalVC: UIViewController
@property (weak,nonatomic) CustomPokeCard *card;


@end
