//
//  UIViewController+PokemonCardCreate.m
//  tcgbrainstorm_beta
//
//  Created by Matt Guarneri on 4/7/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "PokemonCardCreateVC.h"
#import <MessageUI/MessageUI.h>
#import <Social/Social.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <AVFoundation/AVFoundation.h>

@interface PokemonCardCreateVC () <MFMessageComposeViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *cardImage;
@property (strong,nonatomic) AVAudioPlayer *audioPlayer;
-(UIImage*) renderImage;
@end

@implementation PokemonCardCreateVC
-(void)viewDidLoad{
    //These statements set the background of the Card based on the type chosen in the first step
    if([_card.type isEqualToString:@"Colorless"]){
        UIImage *image = [UIImage imageNamed: @"normal_basic.png"];
        [_cardImage setImage:image];
    }else if ([_card.type isEqualToString:@"Water"]){
        UIImage *image = [UIImage imageNamed: @"water_basic.png"];
        [_cardImage setImage:image];
    }else if ([_card.type isEqualToString:@"Fire"]){
        UIImage *image = [UIImage imageNamed: @"fire_basic.png"];
        [_cardImage setImage:image];
    }else if ([_card.type isEqualToString:@"Grass"]){
        UIImage *image = [UIImage imageNamed: @"grass_basic.png"];
        [_cardImage setImage:image];
    }else if ([_card.type isEqualToString:@"Psychic"]){
        UIImage *image = [UIImage imageNamed: @"psychic_basic.png"];
        [_cardImage setImage:image];
    }else if ([_card.type isEqualToString:@"Lightning"]){
        UIImage *image = [UIImage imageNamed: @"electric_basic.png"];
        [_cardImage setImage:image];
    }else if ([_card.type isEqualToString:@"Darkness"]){
        UIImage *image = [UIImage imageNamed: @"dark_basic.png"];
        [_cardImage setImage:image];
    }else if ([_card.type isEqualToString:@"Fairy"]){
        UIImage *image = [UIImage imageNamed: @"fairy_basic.png"];
        [_cardImage setImage:image];
    }else if ([_card.type isEqualToString:@"Dragon"]){
        UIImage *image = [UIImage imageNamed: @"dragon_basic.png"];
        [_cardImage setImage:image];
    }else if ([_card.type isEqualToString:@"Metal"]){
        UIImage *image = [UIImage imageNamed: @"steel_basic.png"];
        [_cardImage setImage:image];
    }else if ([_card.type isEqualToString:@"Fighting"]){
        UIImage *image = [UIImage imageNamed: @"fighting_basic.png"];
        [_cardImage setImage:image];
    }
    //Name view is insantiated in correct coordinates with the offical Pokemon Font
    UILabel* name = [[UILabel alloc] initWithFrame:CGRectMake(40,10, 100, 20)];
    name.text = self.card.name;
    name.font = [UIFont fontWithName:@"GillSans-Bold" size:14];
    [self.cardImage addSubview:name];
    
    //HP view is insantiated in correct coordinates with the offical Pokemon Font
    UILabel* hp = [[UILabel alloc] initWithFrame:CGRectMake(157,10, 50, 20)];
    hp.text = self.card.hp;
    hp.font = [UIFont fontWithName:@"Futura-Light" size:14];
    [self.cardImage addSubview:hp];
    
    //Default hp symbol is placed in front of card HP
    UILabel* hpsym = [[UILabel alloc] initWithFrame:CGRectMake(145,15, 30, 20)];
    hpsym.text = @"HP";
    hpsym.font = hpsym.font = [UIFont fontWithName:@"GillSans-UltraBold" size:8];
    [self.cardImage addSubview:hpsym];
    
    //Display the name and dmg of the attack in line with each other
    UILabel* atk1name = [[UILabel alloc] initWithFrame:CGRectMake(75,160, 150, 15)];
    atk1name.text= self.card.atk1name;
    atk1name.font = [UIFont fontWithName:@"GillSans-SemiBold" size:13];
    [self.cardImage addSubview:atk1name];
    UILabel* atk1dmg = [[UILabel alloc] initWithFrame:CGRectMake(165,160, 50, 15)];
    atk1dmg.text= self.card.atk1dmg;
    atk1dmg.font = [UIFont fontWithName:@"Futura-Heavy" size:13];
    [self.cardImage addSubview:atk1dmg];
    
    float xValue = 15;
    for (NSInteger i = 0; i < self.card.atk1type.length; i++){//This loop iterate through the damage cost
        char c = [self.card.atk1type characterAtIndex:i];
        if (c == '/')//if / ignore
            continue;
        else{
            UIImage* castImage;//if char is associated with one of the types, set the image to the type
            if(c=='f'){
                castImage = [UIImage imageNamed: @"pokeFire.png"];
            }else if(c=='w'){
                 castImage = [UIImage imageNamed: @"pokeWater.png"];
            }else if (c=='l'){
                 castImage = [UIImage imageNamed: @"pokeLightning.png"];
            }else if (c=='g'){
                 castImage = [UIImage imageNamed: @"pokeGrass.png"];
            }else if (c == 'm'){
                castImage = [UIImage imageNamed: @"pokeSteel.png"];
            }else if (c== 'd'){
                castImage = [UIImage imageNamed: @"PokeDark.png"];
            }else if (c=='p'){
                castImage = [UIImage imageNamed: @"pokePsy.png"];
            }else if (c=='c'){
                castImage = [UIImage imageNamed: @"pokeNorm.png"];
            }else if(c=='r'){
                castImage = [UIImage imageNamed: @"pokeFight.png"];
            }
            UIImageView* cast = [[UIImageView alloc] initWithFrame:CGRectMake(xValue, 160, 15, 15)];
            cast.image = castImage;
            [self.cardImage addSubview:cast];
            xValue += 15;//increment xValue over to the right to display next type :)
        }
    }
    //display the description on bottom right of card
        UILabel* atk1des = [[UILabel alloc] initWithFrame:CGRectMake(15,160, 190, 60)];
        atk1des.lineBreakMode =  NSLineBreakByWordWrapping;
        atk1des.numberOfLines=3;
        atk1des.text= self.card.atk1desc;
        atk1des.font = [UIFont fontWithName:@"GillSans" size:8];
        [self.cardImage addSubview:atk1des];
    //atk2 labels functionally identically to atk1; just change the y val
        UILabel* atk2name = [[UILabel alloc] initWithFrame:CGRectMake(75,210, 150, 15)];
        atk2name.text= self.card.atk2name;
        atk2name.font = [UIFont fontWithName:@"GillSans-SemiBold" size:13];
        [self.cardImage addSubview:atk2name];
        
        UILabel* atk2dmg = [[UILabel alloc] initWithFrame:CGRectMake(165,210, 50, 15)];
        atk2dmg.text= self.card.atk2dmg;
        atk2dmg.font = [UIFont fontWithName:@"Futura-Heavy" size:13];
        [self.cardImage addSubview:atk2dmg];
        
        xValue = 15;
        for (NSInteger i = 0; i < self.card.atk2type.length; i++){
            char c = [self.card.atk2type characterAtIndex:i];
            if (c == '/')
                continue;
            else{
                UIImage* castImage;
                if(c=='f'){
                    castImage = [UIImage imageNamed: @"pokeFire.png"];
                }else if(c=='w'){
                    castImage = [UIImage imageNamed: @"pokeWater.png"];
                }else if (c=='l'){
                    castImage = [UIImage imageNamed: @"pokeLightning.png"];
                }else if (c=='g'){
                    castImage = [UIImage imageNamed: @"pokeGrass.png"];
                }else if (c == 'm'){
                    castImage = [UIImage imageNamed: @"pokeSteel.png"];
                }else if (c== 'd'){
                    castImage = [UIImage imageNamed: @"PokeDark.png"];
                }else if (c=='p'){
                    castImage = [UIImage imageNamed: @"pokePsy.png"];
                }else if (c=='c'){
                    castImage = [UIImage imageNamed: @"pokeNorm.png"];
                }else if(c=='r'){
                    castImage = [UIImage imageNamed: @"pokeFight.png"];
                }
                UIImageView* cast = [[UIImageView alloc] initWithFrame:CGRectMake(xValue, 210, 15, 15)];
                cast.image = castImage;
                [self.cardImage addSubview:cast];
                xValue += 15;
            }
            
            
        }
    UILabel* atk2des = [[UILabel alloc] initWithFrame:CGRectMake(15,210, 190, 60)];
    atk2des.lineBreakMode =  NSLineBreakByWordWrapping;
    atk2des.numberOfLines=3;
    atk2des.text= self.card.atk2desc;
    atk2des.font = [UIFont fontWithName:@"GillSans" size:8];
    [self.cardImage addSubview:atk2des];
    
    xValue = 165;
    for (int i = 0; i < self.card.retreat; i++){//for ever retreat display a colorless symbol on the correct part
        UIImage* rtsym = [UIImage imageNamed: @"pokeNorm.png"];
        UIImageView* rt = [[UIImageView alloc] initWithFrame:CGRectMake(xValue, 265, 8, 8)];
        rt.image = rtsym;
        [self.cardImage addSubview:rt];
        xValue += 10;
    }
    
    if(_card.weaktype!=nil){//if there is a weaktype choose it's respective symbol
        UIImage* wksym;
        if([_card.weaktype isEqualToString:@"Grass"]){
         wksym = [UIImage imageNamed: @"pokeGrass.png"];
        }else if([_card.weaktype isEqualToString:@"Fire"]){
         wksym = [UIImage imageNamed: @"pokeFire.png"];
        }else if([_card.weaktype isEqualToString:@"Water"]){
          wksym = [UIImage imageNamed: @"pokeWater.png"];
        }else if([_card.weaktype isEqualToString:@"Psychic"]){
          wksym = [UIImage imageNamed: @"pokePsy.png"];
        }else if([_card.weaktype isEqualToString:@"Lightning"]){
          wksym = [UIImage imageNamed: @"pokeLightning.png"];
        }else if([_card.weaktype isEqualToString:@"Metal"]){
           wksym = [UIImage imageNamed: @"pokeSteel.png"];
        }else if([_card.weaktype isEqualToString:@"Colorless"]){
            wksym = [UIImage imageNamed: @"pokeNorm.png"];
        }else if([_card.weaktype isEqualToString:@"Darkness"]){
             wksym = [UIImage imageNamed: @"PokeDark.png"];
        }else if([_card.weaktype isEqualToString:@"Fighting"]){
              wksym = [UIImage imageNamed: @"pokeFight.png"];
        }
        
        UIImageView* wk = [[UIImageView alloc] initWithFrame:CGRectMake(40, 265, 8, 8)];
        wk.image = wksym;
        [self.cardImage addSubview:wk];
        
        UILabel* wkval = [[UILabel alloc] initWithFrame:CGRectMake(48,257, 15, 20)];//used to display how weak
        wkval.adjustsFontSizeToFitWidth=YES;
        wkval.minimumScaleFactor=.25;
        if(self.card.weakamt==NULL||self.card.weakamt==0){//default
            wkval.text= @"x2 ";
        }else{//else display how weak
        wkval.text= [NSString stringWithFormat:@"x%@ ", self.card.weakamt];
        }
        wkval.font = [UIFont fontWithName:@"Futura-Heavy" size:10];
        [self.cardImage addSubview:wkval];
        
    }
    if(_card.strongtype!=nil){//strong type is not nil choose the symbol of corresponding strong type
        UIImage* stsym;
        if([_card.strongtype isEqualToString:@"Grass"]){
            stsym = [UIImage imageNamed: @"pokeGrass.png"];
        }else if([_card.strongtype isEqualToString:@"Fire"]){
            stsym = [UIImage imageNamed: @"pokeFire.png"];
        }else if([_card.strongtype isEqualToString:@"Water"]){
            stsym = [UIImage imageNamed: @"pokeWater.png"];
        }else if([_card.strongtype isEqualToString:@"Psychic"]){
            stsym = [UIImage imageNamed: @"pokePsy.png"];
        }else if([_card.strongtype isEqualToString:@"Lightning"]){
            stsym = [UIImage imageNamed: @"pokeLightning.png"];
        }else if([_card.strongtype isEqualToString:@"Metal"]){
            stsym = [UIImage imageNamed: @"pokeSteel.png"];
        }else if([_card.strongtype isEqualToString:@"Colorless"]){
            stsym = [UIImage imageNamed: @"pokeNorm.png"];
        }else if([_card.strongtype isEqualToString:@"Darkness"]){
            stsym = [UIImage imageNamed: @"PokeDark.png"];
        }else if([_card.strongtype isEqualToString:@"Fighting"]){
            stsym = [UIImage imageNamed: @"pokeFight.png"];
        }
        UIImageView* st = [[UIImageView alloc] initWithFrame:CGRectMake(100, 265, 8, 8)];
        st.image = stsym;
        [self.cardImage addSubview:st];//display selected symbol
        
        
        UILabel* stval = [[UILabel alloc] initWithFrame:CGRectMake(109,257, 15, 20)];//display how weak
        stval.adjustsFontSizeToFitWidth=YES;
        stval.minimumScaleFactor=.25;
        if(self.card.strongamt==NULL||self.card.strongamt==0){//default
            stval.text= @"-10";
        }else{
            stval.text= self.card.strongamt;
        }
        stval.font = [UIFont fontWithName:@"Futura-Heavy" size:10];
        [self.cardImage addSubview:stval];
    }
    
    UILabel* flavor = [[UILabel alloc] initWithFrame:CGRectMake(100,272, 95, 30)];//display up to 2 lines of flavor text
    flavor.adjustsFontSizeToFitWidth=YES;
    flavor.minimumScaleFactor=.25;
    flavor.lineBreakMode =  NSLineBreakByWordWrapping;
    flavor.numberOfLines=3;
    flavor.text= self.card.flavor;
    flavor.font = [UIFont fontWithName:@"GillSans-Italic" size:8];
    [self.cardImage addSubview:flavor];
    
    
    
    UILabel* author = [[UILabel alloc] initWithFrame:CGRectMake(15,265, 60, 30)];//enter the illustartor names right next to illus. on card
    author.adjustsFontSizeToFitWidth=YES;
    author.minimumScaleFactor=.25;
    author.lineBreakMode =  NSLineBreakByWordWrapping;
    author.numberOfLines=1;
    author.text= [NSString stringWithFormat:@"Illus.%@", self.card.author];
    author.font = [UIFont fontWithName:@"GillSans-SemiBoldItalic" size:8];
    [self.cardImage addSubview:author];
    
    // add the image to the card
    UIImageView* cardImageView = [[UIImageView alloc] initWithFrame:CGRectMake(18, 29, 180, 116)];
    cardImageView.image = self.card.image;
    [self.cardImage addSubview:cardImageView];

    
}
- (IBAction)backButtonPressed:(id)sender {//go back to pokemon card final :)
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"pokeBack" ofType:@"wav" ];
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    [self.audioPlayer play];
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(UIImage*) renderImage//render the completed card and save it as a screenshot
{
    // get the card image
    UIImageView* captureView = self.cardImage;
    
    // capture the screenshot at native resolution
    UIGraphicsBeginImageContextWithOptions(captureView.bounds.size, captureView.opaque, 0.0);
    [captureView.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage * screenshot = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    // render the screenshot at custom resolution
    CGRect cropRect = CGRectMake(0 ,0 ,captureView.bounds.size.width ,captureView.bounds.size.height);
    UIGraphicsBeginImageContextWithOptions(cropRect.size, captureView.opaque, 10.0f);
    [screenshot drawInRect:cropRect];
    UIImage * customScreenShot = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return customScreenShot;
}

- (IBAction)save:(id)sender {//save the completed card to photo album
    // save to the photo album
    UIImageWriteToSavedPhotosAlbum([self renderImage] , nil, nil, nil);
}

- (IBAction)iMessage:(id)sender {//send card over imessage
    NSData *attachment = UIImageJPEGRepresentation([self renderImage],.5);
    NSString *attachmentType = @"image";
    MFMessageComposeViewController* messageComposer = [MFMessageComposeViewController new];
    messageComposer.messageComposeDelegate = self;
    if (attachment && attachmentType) {
        [messageComposer addAttachmentData:attachment typeIdentifier:@"image/jpeg" filename:@"shotnote.jpg"];
    }
    if (MFMessageComposeViewController.canSendText) [self presentViewController:messageComposer animated:YES completion:nil];
}

// delegate method for when message is sent or the user hits cancel
-(void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [controller dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)shareOnSocialMedia:(id)sender {// Call an alert that lets you share on Facebook/Twitter or cancel
    UIAlertController * alert = [UIAlertController
                                 alertControllerWithTitle:@"Share on Social Media"
                                 message:@"Select from the options below"
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    // sharing on facebook
    UIAlertAction* facebook = [UIAlertAction
                               actionWithTitle:@"Facebook"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction * action) {
                                   SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
                                   [controller setInitialText:@"Check out the custom card I made with #TCGBrainstorm!"];
                                   [controller addImage:[self renderImage]];
                                   [self presentViewController:controller animated:YES completion:Nil];
                               }];
    
    // sharing on twitter
    UIAlertAction* twitter = [UIAlertAction
                              actionWithTitle:@"Twitter"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action) {
                                  SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
                                  [controller setInitialText:@"Check out the custom card I made with #TCGBrainstorm!"];
                                  [controller addImage:[self renderImage]];
                                  [self presentViewController:controller animated:YES completion:Nil];
                              }];
    
    UIAlertAction* cancel = [UIAlertAction
                             actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action) {
                             }];
    
    [alert addAction:facebook];
    [alert addAction:twitter];
    [alert addAction:cancel];
    
    [self presentViewController:alert animated:YES completion:nil];
}


@end 
