//
//  MagicExporterVC.m
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/5/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "MagicExporterVC.h"
#import <Social/Social.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <MessageUI/MessageUI.h>
#import <AVFoundation/AVFoundation.h>

@interface MagicExporterVC () <MFMessageComposeViewControllerDelegate>
@property (strong,nonatomic) AVAudioPlayer *audioPlayer;
@property (weak, nonatomic) IBOutlet UIButton *saveToCameraRollButton;
@property (weak, nonatomic) IBOutlet UIButton *iMessageButton;
@property (weak, nonatomic) IBOutlet UIButton *shareOnSocialMedia;
@property (weak, nonatomic) IBOutlet UIButton *home;
-(void) formatButton:(UIButton*) button;
@end

@implementation MagicExporterVC

-(NSString*) getCardTemplate
{
    NSLog(@"%@",self.card.color);
    if ([self.card.color isEqualToString:@"WHITE"])
        return @"white_mtg_template.jpeg";
    else if ([self.card.color isEqualToString:@"GREEN"])
        return @"green_mtg_template.jpeg";
    else if ([self.card.color isEqualToString:@"BLUE"])
        return @"blue_mtg_template.jpeg";
    else if ([self.card.color isEqualToString:@"BLACK"])
        return @"black_mtg_template.jpeg";
    else
        return @"red_mtg_template.jpeg";
}

-(void) formatButton:(UIButton*) button
{
    button.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:18];
    button.layer.cornerRadius = 15;
    button.clipsToBounds = true;
    button.layer.borderWidth = 1.0;
    button.layer.borderColor = [[UIColor blackColor] CGColor];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // format the buttons properly
    [self formatButton:self.saveToCameraRollButton];
    [self formatButton:self.iMessageButton];
    [self formatButton:self.shareOnSocialMedia];
    [self formatButton:self.home];

    // going to need to create the image in the image view here
    NSString* color = [self getCardTemplate];
    UIImage* finishedCard = [UIImage imageNamed:color];
    NSLog(@"Color template: %@",color);
    self.imageView.image = finishedCard;
    
    // add the name to the card
    UILabel* name = [[UILabel alloc] initWithFrame:CGRectMake(18, 16, 100, 20)];
    name.text = self.card.name;
    name.font = [UIFont fontWithName:@"Matrix-Bold" size:14];
    [self.imageView addSubview:name];
    
    // add the casting cost to the card
    float xValue = 185;
    for (NSInteger i = 0; i < self.card.castingCost.length; i++)
    {
        char c = [self.card.castingCost characterAtIndex:i];
        if (c == '/')
            continue;
        else
        {
            UIImage* castImage = [UIImage imageNamed:[NSString stringWithFormat:@"%c.png",c]];
            UIImageView* cast = [[UIImageView alloc] initWithFrame:CGRectMake(xValue, 20, 10, 10)];
            cast.image = castImage;
            [self.imageView addSubview:cast];
            xValue -= 11;
        }
            
    }
    
    // add the image to the card
    UIImageView* cardImageView = [[UIImageView alloc] initWithFrame:CGRectMake(19.5, 37.5, 175, 135)];
    cardImageView.image = self.card.image;
    [self.imageView addSubview:cardImageView];
    
    // need to adjust the sizes of these things accordingly
    // add the type to the card
    UILabel* type = [[UILabel alloc] initWithFrame:CGRectMake(20, 172, 150, 20)];
    type.text = self.card.type;
    type.font = [UIFont fontWithName:@"Matrix-Bold" size:9];
    [self.imageView addSubview:type];
    
    // if the subtype's length is greater than 0, meaning it was entered
    if (self.card.subtype.length > 0)
    {
        // add the subtype to the card
        UILabel* subtype = [[UILabel alloc] initWithFrame:CGRectMake(20, 172, 150, 20)];
        
        // construct the subtype in relation to the length of the type
        NSMutableString* buildSubtype = [NSMutableString string];
        for (int i = 0; i < self.card.type.length; i++)
        {
            if (i % 2 == 0)
                [buildSubtype appendString:@"  "];
            else
                [buildSubtype appendString:@" "];
        }
        [buildSubtype appendString:@"      - "];
        [buildSubtype appendString:self.card.subtype];
        subtype.text = buildSubtype;
        subtype.font = [UIFont fontWithName:@"Matrix-Bold" size:9];
        [self.imageView addSubview:subtype];
    }
    
    // add ability to the card
    // if there is no card ability and no ability cost...
    if (self.card.ability==nil &&[self.card.abilityCost isEqualToString:@""] ){
        
    }
    
    // if the user entered no ability cost at all, format everything accordingly...
    else if ([self.card.abilityCost isEqualToString:@""])
    {
        UILabel* ability = [[UILabel alloc] initWithFrame:CGRectMake(19, 190, 150, 50)];
        NSMutableAttributedString *attributed = [[NSMutableAttributedString alloc]initWithString:self.card.ability];
        ability.attributedText=attributed;
        ability.numberOfLines=5;
        ability.font =  [UIFont fontWithName:@"MPlantin" size:10.5];
        [self.imageView addSubview:ability];
    }
    // if there is an ability cost and an ability entered...
    else
    {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc]init];
        for (NSInteger i = 0; i < self.card.abilityCost.length; i++)
        {
            // get the current character
            char c = [self.card.abilityCost characterAtIndex:i];
            if (c == '/')
                continue;
            else
            {
                NSTextAttachment *textAttachment = [[NSTextAttachment alloc] init];
                textAttachment.image =  [UIImage imageNamed:[NSString stringWithFormat:@"%c.png",c]];
                NSAttributedString *attrStringWithImage = [NSAttributedString attributedStringWithAttachment:textAttachment];
                textAttachment.bounds=CGRectMake(0, 0,10,10);
                [attributedString appendAttributedString:attrStringWithImage];
            }
            
        }
        if(self.card.ability!=nil){
            NSMutableAttributedString *attributed = [[NSMutableAttributedString alloc]initWithString:self.card.ability];
            [attributedString appendAttributedString:attributed];
        }
        UILabel* ability = [[UILabel alloc] initWithFrame:CGRectMake(19, 190, 175, 60)];
        ability.numberOfLines=4;
        ability.lineBreakMode =  NSLineBreakByWordWrapping;
        ability.attributedText= attributedString;
        ability.font =  [UIFont fontWithName:@"MPlantin" size:10.5];
        [self.imageView addSubview:ability];
    }
    
    // add the flavor text to the card
    UILabel* flavor = [[UILabel alloc] initWithFrame:CGRectMake(19, 250, 200, 20)];
    flavor.text = self.card.flavorText;
    flavor.numberOfLines=2;
    flavor.font = [UIFont fontWithName:@"TimesNewRomanPS-ItalicMT" size:8];
    [self.imageView addSubview:flavor];
    
    // add the artist text to the card
    UILabel* artist = [[UILabel alloc] initWithFrame:CGRectMake(35, 275, 200, 20)];
    artist.text = self.card.artistName;
    artist.font = [UIFont fontWithName:@"TimesNewRomanPS-ItalicMT" size:6.5];
    if ([self.card.color isEqualToString:@"BLACK"]) artist.textColor = [UIColor whiteColor];
    [self.imageView addSubview:artist];
    
    // add rarity to the care
    NSString* rarityString;
    if (self.card.rarity == 0)
        rarityString = @"common";
    else if (self.card.rarity == 1)
        rarityString = @"uncommon";
    else if (self.card.rarity == 2)
        rarityString = @"rare";
    else
        rarityString = @"mythic";
    
    // display the image
    UIImage* rarityImage = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",rarityString]];
    UIImageView* rarityImageView = [[UIImageView alloc] initWithFrame:CGRectMake(185, 176, 10, 10)];
    rarityImageView.image = rarityImage;
    [self.imageView addSubview:rarityImageView];
    
    // add power and toughness
    if ([self.card.power isEqualToString:@""] || [self.card.toughness isEqualToString:@""])
    {
        // do nothing, as we do not want to display the box
    }
    else
    {
        // get the power and toughness box image
        NSString* ptString;
        if ([self.card.color isEqualToString:@"GREEN"])
            ptString = @"green_pt";
        else if ([self.card.color isEqualToString:@"BLUE"])
            ptString = @"blue_pt";
        else if ([self.card.color isEqualToString:@"BLACK"])
            ptString = @"black_pt";
        else if ([self.card.color isEqualToString:@"RED"])
            ptString = @"red_pt";
        else
            ptString = @"white_pt";
        
        // display the image
        UIImage* ptImage = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",ptString]];
        UIImageView* ptImageView = [[UIImageView alloc] initWithFrame:CGRectMake(150, 265, 50, 25)];
        ptImageView.image = ptImage;
        [self.imageView addSubview:ptImageView];
        
        // add text on top of power and toughness box
        UILabel* powerText = [[UILabel alloc] initWithFrame:CGRectMake(160, 268, 20, 20)];
        if (self.card.power.length < 2)
            powerText.text = [NSString stringWithFormat:@"  %@",self.card.power];
        else
            powerText.text = self.card.power;
        powerText.font = [UIFont fontWithName:@"TrebuchetMS-Bold" size:10];
        [self.imageView addSubview:powerText];
        
        UILabel* slash = [[UILabel alloc] initWithFrame:CGRectMake(171, 268, 20, 20)];
        slash.text = @" /";
        slash.font = [UIFont fontWithName:@"TrebuchetMS-Bold" size:10];
        [self.imageView addSubview:slash];
        
        UILabel* toughText = [[UILabel alloc] initWithFrame:CGRectMake(180, 268, 20, 20)];
        toughText.text = self.card.toughness;
        toughText.font = [UIFont fontWithName:@"TrebuchetMS-Bold" size:10];
        [self.imageView addSubview:toughText];
    }
}

// if the back button was pressed, dismiss the view controller
- (IBAction)backButtonPressed:(id)sender {
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"OOT_Cancel" ofType:@"wav" ];
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    [self.audioPlayer play];

    [self dismissViewControllerAnimated:YES completion:nil];
}

// if the save to camera roll button was pressed
- (IBAction)saveToCameraRoll:(id)sender
{
    /* Save to the photo album */
    UIImageWriteToSavedPhotosAlbum([self renderImage] , nil, nil, nil);
}


- (IBAction)addToNewDeck:(id)sender {
    //UIImage *image = [UIImage imageWithData:[chart getImage]];
    CGRect rect = [self.imageView bounds];
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    [self.imageView.layer renderInContext:context];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    NSArray *activityItems = @[image];
    UIActivityViewController *activityViewControntroller = [[UIActivityViewController alloc] initWithActivityItems:activityItems applicationActivities:nil];
    activityViewControntroller.excludedActivityTypes = @[];
    [self presentViewController:activityViewControntroller animated:true completion:nil];
}

// for rendering the image from the context
-(UIImage*) renderImage
{
    UIImageView* captureView = self.imageView;
    
    /* Capture the screen shoot at native resolution */
    UIGraphicsBeginImageContextWithOptions(captureView.bounds.size, captureView.opaque, 0.0);
    [captureView.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage * screenshot = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    /* Render the screen shot at custom resolution */
    CGRect cropRect = CGRectMake(0 ,0 ,captureView.bounds.size.width ,captureView.bounds.size.height);
    UIGraphicsBeginImageContextWithOptions(cropRect.size, captureView.opaque, 10.0f);
    [screenshot drawInRect:cropRect];
    UIImage * customScreenShot = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return customScreenShot;
}
- (IBAction)addToExistingDeck:(id)sender {
}

// when someone wants to send the message via imessage
- (IBAction)iMessage:(id)sender {
    NSData *attachment = UIImageJPEGRepresentation([self renderImage],.5);
    NSString *attachmentType = @"image";
    MFMessageComposeViewController* messageComposer = [MFMessageComposeViewController new];
    messageComposer.messageComposeDelegate = self;
    if (attachment && attachmentType) {
       [messageComposer addAttachmentData:attachment typeIdentifier:@"image/jpeg" filename:@"shotnote.jpg"];
    }
    if (MFMessageComposeViewController.canSendText) [self presentViewController:messageComposer animated:YES completion:nil];
}

// delegate method for when message is sent or the user hits cancel
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [controller dismissViewControllerAnimated:YES completion:nil];
}

// when someone clicks to share on social media
- (IBAction)shareOnSocialMedia:(id)sender {
    UIAlertController * alert = [UIAlertController
                                 alertControllerWithTitle:@"Share on Social Media"
                                 message:@"Select from the options below"
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    // sharing on facebook
    UIAlertAction* facebook = [UIAlertAction
                                    actionWithTitle:@"Facebook"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {
                                        SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
                                        [controller setInitialText:@"Check out the custom card I made with #TCGBrainstorm!"];
                                        [controller addImage:[self renderImage]];
                                        [self presentViewController:controller animated:YES completion:Nil];
                                    }];
    
    // sharing on twitter
    UIAlertAction* twitter = [UIAlertAction
                                    actionWithTitle:@"Twitter"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {
                                        SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
                                        [controller setInitialText:@"Check out the custom card I made with #TCGBrainstorm!"];
                                        [controller addImage:[self renderImage]];
                                        [self presentViewController:controller animated:YES completion:Nil];
                                    }];

    UIAlertAction* cancel = [UIAlertAction
                                   actionWithTitle:@"Cancel"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction * action) {
                                   }];
    
    [alert addAction:facebook];
    [alert addAction:twitter];
    [alert addAction:cancel];
    
    [self presentViewController:alert animated:YES completion:nil];
}

@end
