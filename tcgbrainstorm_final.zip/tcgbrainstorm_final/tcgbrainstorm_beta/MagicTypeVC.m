//
//  MagicTypeVC.m
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/5/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "MagicTypeVC.h"
#import <AVFoundation/AVFoundation.h>

@interface MagicTypeVC ()
@property (weak, nonatomic) IBOutlet UILabel *rarityHeader;
@property (weak, nonatomic) IBOutlet UILabel *castingCostHeader;
@property (weak, nonatomic) IBOutlet UILabel *castingCostDescription;
@property (weak, nonatomic) IBOutlet UILabel *typeHeader;
@property (weak, nonatomic) IBOutlet UILabel *typeDescription;
@property (weak, nonatomic) IBOutlet UILabel *subtypeDescription;
@property (strong, nonatomic) NSArray* types;
@property (strong,nonatomic) AVAudioPlayer *audioPlayer;
@end

// index to keep track of where we are in the slider
int currentType = 0;

@implementation MagicTypeVC

// Do setup after loading the view
- (void)viewDidLoad
{
    // call the super's viewDidLoad method
    [super viewDidLoad];
    
    // if the casting cost has not been set yet, make it equal to the empty string
    if (self.card.castingCost == NULL) self.card.castingCost = @"";
    
    // set the values for the types array, will be used with the slider
    self.types = [NSArray arrayWithObjects:@"Legendary Creature",@"Artifact",@"Artifact Creature",@"Conspiracy",@"Creature", @"Enchantment",@"Enchantment Creature",@"Enchant Artifact",@"Enchant Equipment",@"Enchant Permanent",@"Instant",@"Interrupt",@"Land Creature",@"Legendary Artifact Creature",@"Legendary Artifact",@"Legendary Enchantment",@"Legenadary Enchantment Artifact",@"Legendary Enchantment Creature",@"Legendary Instant",@"Legendary Land Creature",@"Legendary Sorcery",@"Legendary Tribal Artifact", @"Legendary Tribal Enchantment",@"Legendary Tribal Insant",@"Legendary Tribal Sorcery",@"Sorcery",@"Tribal Instant",@"Tribal Sorcery",@"Tribal Artifact",@"Tribal Enchantment",nil];
    
    // if a user set the information of these fields before, make sure to keep them loaded
    self.castingCost.text = self.card.castingCost;
    self.subtypeField.text = self.card.subtype;
    self.typeLabel.text = self.card.type;
    // get the current index of the object that is equal to the card type
    int indexOfObject = (int) [self.types indexOfObject:self.card.type];
    // set the slider's value to the current index
    self.typeSlider.value = indexOfObject;
    // set the segment value equal to the card's rarity
    self.rarityPicker.selectedSegmentIndex = self.card.rarity;
    
    // set the fonts
    self.castingCost.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    self.castingCostHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:23];
    self.castingCostDescription.font = [UIFont fontWithName:@"Matrix-Bold" size:13];
    self.typeHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:23];
    self.typeDescription.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    self.subtypeDescription.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    self.subtypeField.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    self.clearMana.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    self.castingCost.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    self.rarityHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:23];
    self.typeLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:23];
    
    // format the next button
    self.nextButton.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:18];
    self.nextButton.layer.cornerRadius = 15;
    self.nextButton.clipsToBounds = true;
    self.nextButton.layer.borderWidth = 1.0;
    self.nextButton.layer.borderColor = [[UIColor blackColor] CGColor];
}

// Function that updates the casting cost of the card once a user changes it
// Input: id, but will be a UIButton*
// Output: IBAction
- (IBAction)castingCostChanged:(id)sender {
    // set the limit on how many characters the casting cost can be
    if ([self.card.castingCost length] < 16)
    {
        // cast the sender to a button
        UIButton* button = (UIButton*) sender;
        // get the button tag, it will be used to determine the casting cost code
        int tag = (int) button.tag;

        // determine the value of newText depending on button clicked
        NSString* newText;
        // if the tag is 0, 1, 2, 3, 4, 5, 6, 7, 8, or 9, set the text equal to the tag
        if (tag <= 9)
            newText = [NSString stringWithFormat:@"/%d",tag];
        // otherwise, map it to the corresponding letter it is associated with
        else
        {
            if (tag == 10)
                newText = @"/X";
            else if (tag == 11)
                newText = @"/W";
            else if (tag == 12)
                newText = @"/U";
            else if (tag == 13)
                newText = @"/R";
            else if (tag == 14)
                newText = @"/G";
            else if (tag == 15)
                newText = @"/B";
        }
        // set the casting cost label text
        self.castingCost.text = [NSString stringWithFormat:@"%@%@",self.card.castingCost,newText];
        // update the card's casting cost
        self.card.castingCost = self.castingCost.text;
    }
}

// Function to clear the casting cost
// Input: id, which is always a UIButton*
// Output: IBAction
- (IBAction)clearManaPressed:(id)sender {
    // set the casting cost text field label to the empty string
    self.castingCost.text = @"";
    // set the card casting cost to the empty string
    self.card.castingCost = @"";
}

// Function that sets the subtype once a user enters one
// Input: id, which is always a UITextField*
// Output: IBAction
- (IBAction)subtypeEntered:(id)sender {
    // cast the sender to a UITextField* object
    UITextField* subtype = (UITextField*) sender;
    // set the subtype of the card to the UITextField's entry
    self.card.subtype = subtype.text;
    // the text field finished editing
    [self textFieldDidEndEditing:_subtypeField];
}

// Function that moves the screen up once the subtype field is being entered
// Input: id, which is the UITextField*
// Output: IBAction
- (IBAction)subtypeBegan:(id)sender {
    // the text field began editing, make sure to move the screen up
     [self textFieldDidBeginEditing:_subtypeField];
}

// Function that dismisses the view controller and plays a sound once it is dismissed
// Input: id, which will be UIButton*
// Output: IBAction
- (IBAction)backButtonPressed:(id)sender {
    // construct the path of the audio file
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"OOT_Cancel" ofType:@"wav" ];
    // construct the URL with the path to the audio file
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    // declare the error
    NSError *error;
    // instantiate the audioPlayer with the URL and error
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    // play the sound
    [self.audioPlayer play];
    // dismiss the view controller since we hit the back button
    [self dismissViewControllerAnimated:YES
                             completion:nil];
}

// Function to display the chosen type and save type in the card object
// Input: int, which is the index in the array/slider that was chosen by the user
// Output: void
- (void) showDisplayAtIndex:(int) index
{
    // set the type label on the screen equal to the object at the index chosen
    self.typeLabel.text = [self.types objectAtIndex:index];
    // set the type of the card by setting it equal to the label's text
    self.card.type = self.typeLabel.text;
}

// Function to save the information when the slider changed
// Input: id, which is UISlider*
// Output: IBAction
- (IBAction)sliderChanged:(id)sender
{
    // cast the sender into a UISlider object
    UISlider *mySlider = (UISlider *) sender;
    // get the index for the array by getting the value of the slider
    int recordToDisplay = (int) mySlider.value;
    // display the record
    [self showDisplayAtIndex:recordToDisplay];
    // save the current index in the global index variable
    currentType = recordToDisplay;
}

// Function that will set the rarity of the card when it changes
// Input: id, which will be the UISegmentedControl*
// Output: IBAction
- (IBAction)segmentChanged:(id)sender {
    // Common equals 0 (first segment)
    if (self.rarityPicker.selectedSegmentIndex == 0)
        self.card.rarity = 0;
    // Uncommon equals 1 (second segment)
    else if (self.rarityPicker.selectedSegmentIndex == 1)
        self.card.rarity = 1;
    // Rare equals 2 (third segment)
    else if (self.rarityPicker.selectedSegmentIndex == 2)
        self.card.rarity = 2;
    // Mythic rare equals 3 (fourth segment)
    else
        self.card.rarity = 3;
}

// Setup before segue happens
// Input: UIStoryboardSegue*, id, which is the button clicked to cause the segue
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // get the destination view controller
    MagicAbilityVC* dest = [segue destinationViewController];
    // set the destination view controller's card to this view controller's card
    dest.card = self.card;
}

// Function to animate the text field when editing begins
// Input: UITextField*
// Output: void
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    // move the text field up when editing begins
    [self animateTextField:textField up:YES];
}

// Function to animate the text field when editing ends
// Input: UITextField*
// Output: void
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    // move the text field down when editing ends
    [self animateTextField:textField up:NO];
}

// Animate the text field movement
// Input: UITextField*, BOOL
// Output: void
-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    // movement distance
    const int movementDistance = -200;
    // movement duration
    const float movementDuration = 0.3f; 
    
    // if up, go the movement distance, else go the negative of the movement distance
    int movement = (up ? movementDistance : -movementDistance);
    
    // begin the animation
    [UIView beginAnimations: @"animateTextField" context: nil];
    // animation begins from current state
    [UIView setAnimationBeginsFromCurrentState: YES];
    // animate for the specified duration
    [UIView setAnimationDuration: movementDuration];
    // set the frame of the animation
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    // commit the animation
    [UIView commitAnimations];
}

// Function to play a sound when the nextButton was pressed
// Input: id, which is the UIButton object when pressed
// Output: IBAction
- (IBAction)nextPressed:(id)sender
{
    // construct the path to the audio file
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"OOT_MainMenu_Select" ofType:@"wav" ];
    // construct the URL to the audio file
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    // declare the error variable
    NSError *error;
    // instantiate the audioPlayer object with the URL and the error variable
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    // play the sound
    [self.audioPlayer play];
}



@end
