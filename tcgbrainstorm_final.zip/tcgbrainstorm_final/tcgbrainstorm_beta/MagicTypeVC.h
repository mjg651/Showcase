//
//  MagicTypeVC.h
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/5/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomMagicCard.h"
#import "MagicAbilityVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface MagicTypeVC : UIViewController
@property (strong, nonatomic) CustomMagicCard* card;
@property (weak, nonatomic) IBOutlet UILabel *castingCost;
@property (weak, nonatomic) IBOutlet UIButton *nextButton;
@property (weak, nonatomic) IBOutlet UITextField *subtypeField;
@property (weak, nonatomic) IBOutlet UIButton *clearMana;
@property (weak, nonatomic) IBOutlet UISlider *typeSlider;
@property (weak, nonatomic) IBOutlet UILabel *typeLabel;
@property (weak, nonatomic) IBOutlet UISegmentedControl *rarityPicker;
- (void) showDisplayAtIndex:(int) index;
@end

NS_ASSUME_NONNULL_END
