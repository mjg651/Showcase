//
//  MagicCardInfoVC.m
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/5/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "MagicCardInfoVC.h"
#import <AVFoundation/AVFoundation.h>

@interface MagicCardInfoVC ()
@property (weak, nonatomic) IBOutlet UILabel *uploadAPhoto;
@property (weak, nonatomic) IBOutlet UIButton *wColor;
@property (weak, nonatomic) IBOutlet UIButton *uColor;
@property (weak, nonatomic) IBOutlet UIButton *bColor;
@property (weak, nonatomic) IBOutlet UIButton *rColor;
@property (weak, nonatomic) IBOutlet UIButton *gColor;
@property (weak, nonatomic) IBOutlet UIButton *cameraRoll;
@property (weak, nonatomic) IBOutlet UIButton *takeAPhoto;
@property (weak, nonatomic) IBOutlet UILabel *cardInformation;
@property (weak, nonatomic) IBOutlet UILabel *cardName;
@property (weak, nonatomic) IBOutlet UILabel *cardColor;
@property (strong,nonatomic) AVAudioPlayer *audioPlayer;
-(void)formatButton:(UIButton*) button withBorderColor:(UIColor*) color withFontSize:(CGFloat) size withBackgroundColor:(UIColor*) bgColor;
@end

@implementation MagicCardInfoVC

// Format the buttons for this view
-(void)formatButton:(UIButton*) button      // button object
          withBorderColor:(UIColor*) color  // border color
       withFontSize:(CGFloat) size          // font size
withBackgroundColor:(UIColor*) bgColor      // background color
{
    // format the button properly
    button.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:size];
    // make it a rounded button
    button.layer.cornerRadius = 15;
    // clip it to the bounds
    button.clipsToBounds = true;
    // set the border width
    button.layer.borderWidth = 1.0;
    // set the border color
    button.layer.borderColor = [color CGColor];
    // set the background color
    if (bgColor != nil)
        button.backgroundColor = bgColor;
}

// Do things when the view loads
- (void)viewDidLoad
{
    // call the superclass' viewDidLoad function
    [super viewDidLoad];
    
    // lazy instantiation of the custom card object
    if (self.card == nil) self.card = [[CustomMagicCard alloc] init];
    
    // set the default card color as white
    self.card.color = @"WHITE";
    // set the text field equal to the card name, on startup this will be an empty string
    self.nameTextField.text = self.card.name;
    // hide the error, as nobody has entered anything yet
    self.nameTextFieldError.hidden = YES;
    
    // format the next button
    [self formatButton:self.nextButton withBorderColor:[UIColor blackColor] withFontSize:18 withBackgroundColor:nil];
    // format the take a photo button
    [self formatButton:self.takeAPhoto withBorderColor:[UIColor blackColor] withFontSize:18 withBackgroundColor:nil];
    // format the select from camera roll button
    [self formatButton:self.cameraRoll withBorderColor:[UIColor blackColor] withFontSize:18 withBackgroundColor:nil];
    // format the white color button
    [self formatButton:self.wColor withBorderColor:[UIColor blackColor] withFontSize:15 withBackgroundColor:[UIColor whiteColor]];
    // format the blue color button
    [self formatButton:self.uColor withBorderColor:[UIColor blackColor] withFontSize:15 withBackgroundColor:[UIColor blueColor]];
    // format the green color button
    [self formatButton:self.gColor withBorderColor:[UIColor blackColor] withFontSize:15 withBackgroundColor:[UIColor greenColor]];
    // format the black color button
    [self formatButton:self.bColor withBorderColor:[UIColor blackColor] withFontSize:15 withBackgroundColor:[UIColor blackColor]];
    // format the red color button
    [self formatButton:self.rColor withBorderColor:[UIColor blackColor] withFontSize:15 withBackgroundColor:[UIColor redColor]];
    
    // format the upload a photo header
    self.uploadAPhoto.font = [UIFont fontWithName:@"Matrix-Bold" size:23];
    
    // format the card information header
    self.cardInformation.font = [UIFont fontWithName:@"Matrix-Bold" size:23];
    
    // format the card name sub-header
    self.cardName.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    
    // format the card color sub-header
    self.cardColor.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    
    // format the card name label text
    self.nameTextField.font = [UIFont fontWithName:@"Matrix-Bold" size:14];
}

// Function that is called when the card name text field is changed
// Input: UITextField*
// Output: IBAction
- (IBAction)cardNameEntered:(id)sender
{
    // cast the sender to a UITextField*
    UITextField* cardName = (UITextField*) sender;
    
    // if the card name's length is more than 18 characters long
    if (cardName.text.length > 18)
    {
        // Throw an error and disable the next button, we do not want anyone advancing in the card creation process
        self.nameTextFieldError.hidden = NO;
        self.nextButton.enabled = NO;
    }
    // otherwise, the card name is good to go
    else
    {
        // hide the error if it previously existed
        self.nameTextFieldError.hidden = YES;
        // enable the next button
        self.nextButton.enabled = YES;
        // set the card name
        self.card.name = cardName.text;
    }
    // move the view in its normal position
    [self textFieldDidEndEditing:cardName];
}

// Function that moves the text field into sight when typing on a phone with a keyboard
- (IBAction)cardNameBegan:(id)sender {
     [self textFieldDidBeginEditing:_nameTextField];
}

// Function that sets the card color based on what was chosen
// Input: id, but always is a UIButton*
// Output: IBAction
- (IBAction)cardColorChosen:(id)sender
{
    // cast the sender to a UIButton object
    UIButton* button = (UIButton*) sender;
    // set the card color
    self.card.color = [NSString stringWithFormat:@"%@",button.titleLabel.text];
}

// Function that dismisses the current view controller and plays a sound when the button is pressed
- (IBAction)backButtonPressed:(id)sender {
    // get the audio file's path
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"OOT_Cancel" ofType:@"wav" ];
    // construct a URL from the path
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    // declare an error object
    NSError *error;
    // set the audioPlayer object
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    // play the sound
    [self.audioPlayer play];
    // dismiss the view controller
    [self dismissViewControllerAnimated:YES
                             completion:nil];
}

// Function that allows the user to take their own photo
// Input: Button press
// Output: IBAction
- (IBAction)takePhoto:(id)sender {
    // allocate a UIImagePickerController object
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    // set the current view controller to the picker's delegate
    picker.delegate = self;
    // allow editing of the photo
    picker.allowsEditing = YES;
    // set the source to be from the camera
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    // present the UIImagePickerController
    [self presentViewController:picker animated:YES completion:NULL];
}

// Function that allows the user to select photo from their camera roll
// Input: Button press
// Output: IBAction
- (IBAction)selectPhoto:(id)sender {
    // allocate a UIImagePickerController object
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    // set the current view controller to the picker's delegate
    picker.delegate = self;
    // allow editing of the photo
    picker.allowsEditing = YES;
    // set the source to be from the photo library
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    // present the view controller
    [self presentViewController:picker animated:YES completion:NULL];
}

// Function that is called once the image is picked
// Input: UIImagePickerController*, NSDictionary*
// Output: void
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    // get the chosen image from the NSDictionary* that holds the information about the media
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    // set the imageView's image to the chosen image
    self.imageView.image = chosenImage;
    // set the card image to the chosen image
    self.card.image = chosenImage;
    // dismiss the UIImagePickerController*
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

// Function that allows the user to cancel picking a photo in case they changed their mind
// Input: UIImagePickerController*
// Output: void
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    // dismiss the UIImagePickerController*
    [picker dismissViewControllerAnimated:YES completion:NULL];
}


// In a storyboard-based application, you will often want to do a little preparation before navigation
// Input: UIStoryboardSegue*, id
// Output: void
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // get the destination view controller
    MagicTypeVC* dest = [segue destinationViewController];
    // set the destination's card object to this view controller's card object
    dest.card = self.card;
}

// Function to animate the text field when editing begins
// Input: UITextField*
// Output: void
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    // move the text field up when editing begins
    [self animateTextField:textField up:YES];
}

// Function to animate the text field when editing ends
// Input: UITextField*
// Output: void
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    // move the text field down when editing ends
    [self animateTextField:textField up:NO];
}

// Animate the text field movement
// Input: UITextField*, BOOL
// Output: void
-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    // movement distance
    const int movementDistance = -170;
    // movement duration
    const float movementDuration = 0.3f;
    
    // if up, go the movement distance, otherwise go negative of the movement distance
    int movement = (up ? movementDistance : -movementDistance);
    
    // begin animating the text field
    [UIView beginAnimations: @"animateTextField" context: nil];
    // animation begins from the current state
    [UIView setAnimationBeginsFromCurrentState: YES];
    // set the animation duration
    [UIView setAnimationDuration: movementDuration];
    // set the frame of the animation
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    // commit the animation
    [UIView commitAnimations];
}

// Function that plays a sound when the next button is pressed
// Input: id, which will be a UIButton*
// Output: IBAction
- (IBAction)nextPressed:(id)sender {
    // get the audioPath
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"OOT_MainMenu_Select" ofType:@"wav" ];
    // construct the audioURL
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    // declare the error
    NSError *error;
    // instantiate the audioPlayer object
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    // play the sound
    [self.audioPlayer play];
}
@end
