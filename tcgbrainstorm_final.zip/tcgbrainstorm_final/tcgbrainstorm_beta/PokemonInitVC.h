//
//  ViewController.h
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/4/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomPokeCard.h"

@interface PokemonInitVC : UIViewController<UIImagePickerControllerDelegate, UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UITextField *typeBox;
@property (strong,nonatomic) CustomPokeCard *card;
@property (weak, nonatomic) IBOutlet UITextField *cardNameTextField;
@property (weak, nonatomic) IBOutlet UILabel *warningBox;
@property (weak, nonatomic) IBOutlet UIButton *nextBox;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

