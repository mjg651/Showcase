//
//  CustomMagicCard.m
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/5/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "CustomMagicCard.h"

@implementation CustomMagicCard

// Print function to help with debugging when needed
// Input: void
// Output: void
-(void) print
{
    NSLog(@"Name: %@\n",self.name);
    NSLog(@"Color: %@\n",self.color);
    NSLog(@"Type: %@\n", self.type);
    NSLog(@"Subtype: %@\n",self.subtype);
    NSLog(@"Casting cost: %@\n",self.castingCost);
    NSLog(@"Ability cost: %@\n",self.abilityCost);
    NSLog(@"Ability: %@\n",self.ability);
    NSLog(@"Power: %@\n",self.power);
    NSLog(@"Toughness: %@\n",self.toughness);
    NSLog(@"Flavor text: %@\n",self.flavorText);
    NSLog(@"Artist name: %@\n",self.artistName);
}

@end
