//
//  ViewController.m
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/4/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "PokemonInitVC.h"
#import "CustomPokeCard.h"
#import "PokemonAtkVC.h"
#import <AVFoundation/AVFoundation.h>


@interface PokemonInitVC ()
@property (weak, nonatomic) IBOutlet UITextField *hpBox;//Display hp
@property (weak, nonatomic) IBOutlet UIButton *cam;//Button for camera
@property (weak, nonatomic) IBOutlet UIButton *photo;//Button for photo gallery
@property (weak, nonatomic) IBOutlet UIButton *nextButton;//Button for next
@property (strong,nonatomic) AVAudioPlayer *audioPlayer;//Used to play sounds
@end


@implementation PokemonInitVC


-(void)viewDidLoad{
    if(_card == nil){//lazy instantiate the card
    _card = [CustomPokeCard new];
    _card.type=@"Colorless";//set default type to colorless
    }

    self.cardNameTextField.text=self.card.name;//Set fields to that of card object to keep track of input
    self.hpBox.text=self.card.hp;
    self.typeBox.text=self.card.type;
    //shape and color buttons
    self.nextButton.layer.cornerRadius = 15;
    self.nextButton.clipsToBounds = true;
    self.nextButton.layer.borderWidth = 1.0;
    self.nextButton.layer.borderColor = [[UIColor blackColor] CGColor];
    
    self.photo.layer.cornerRadius = 15;
    self.photo.clipsToBounds = true;
    self.photo.layer.borderWidth = 1.0;
    self.photo.layer.borderColor = [[UIColor blackColor] CGColor];
    
    self.cam.layer.cornerRadius = 15;
    self.cam.clipsToBounds = true;
    self.cam.layer.borderWidth = 1.0;
    self.cam.layer.borderColor = [[UIColor blackColor] CGColor];
    
}

- (IBAction)backButtonPressed:(id)sender {
    //plays cancel sound and dismisses current VC
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"pokeBack" ofType:@"wav" ];
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    [self.audioPlayer play];
     [self dismissViewControllerAnimated:YES completion:nil];
}

// These functions are connected  to each button sorrounding the card type.
//They display the type in the typebox and set the card objects type
- (IBAction)lightPress:(id)sender {
    _typeBox.text=@"LIGHTNING";
    _card.type=@"Lightning";
}
- (IBAction)waterPress:(id)sender {
     _typeBox.text=@"WATER";
     _card.type=@"Water";
}
- (IBAction)firePress:(id)sender {
     _typeBox.text=@"FIRE";
     _card.type=@"Fire";
}
- (IBAction)grassPress:(id)sender {
    _typeBox.text=@"GRASS";
    _card.type=@"Grass";
}
- (IBAction)normPress:(id)sender {
     _typeBox.text=@"COLORLESS";
     _card.type=@"Colorless";
}
- (IBAction)psyPress:(id)sender {
    _typeBox.text=@"PSYCHIC";
    _card.type=@"Psychic";
}
- (IBAction)fightPress:(id)sender {
     _typeBox.text=@"FIGHTING";
     _card.type=@"Fighting";
}
- (IBAction)steelPress:(id)sender {
     _typeBox.text=@"METAL";
     _card.type=@"Metal";
}
- (IBAction)darkPress:(id)sender {
    _typeBox.text=@"DARKNESS";
    _card.type=@"Darkness";
}
- (IBAction)dragPress:(id)sender {
     _typeBox.text=@"DRAGON";
     _card.type=@"Dragon";
}
- (IBAction)fairyPress:(id)sender {
     _typeBox.text=@"FAIRY";
     _card.type=@"Fairy";
}
//Set card object of next VC to that of this VC
- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    PokemonAtkVC* dest = [segue destinationViewController];
    dest.card = self.card;
}
//Name did begin editing; scroll up screen; disable other box to prevnt infinite scrollin
- (IBAction)startName:(id)sender {
    _hpBox.enabled=NO;
    [self textFieldDidBeginEditing: _cardNameTextField];
    
}
//enable other textbox; set card name if under limit-->  else lock next button
- (IBAction)returnName:(id)sender {
    _hpBox.enabled=YES;
    UITextField* cardName = (UITextField*) sender;
    self.card.name = cardName.text;
    if(cardName.text.length>11){
        _warningBox.text=@"Exceeded limit for name!(12 chars)";
        _nextBox.enabled=NO;
    }else{
        _nextBox.enabled=YES;
        _warningBox.text=@"";
    }
    [self textFieldDidEndEditing: _cardNameTextField];
    
}
//Start hp; same as start name just reverse
- (IBAction)returnHP:(id)sender {
    [self textFieldDidBeginEditing: _hpBox];
    _cardNameTextField.enabled=NO;
    //UITextField* cardHP = (UITextField*) sender;
    //self.card.hp = cardHP.text;
    //if(cardHP.text.length>3){
    //_warningBox.text=@"Exceeded limit for HP!(3 chars)";
    //   _nextBox.enabled=NO;
    //}else{
    //  _nextBox.enabled=YES;
    //_warningBox.text=@"";
    // }
    
}
//Same as end name just reverse the boxes
- (IBAction)endHP:(id)sender {
     _cardNameTextField.enabled=YES;
    UITextField* cardHP = (UITextField*) sender;
    self.card.hp = cardHP.text;
    if(cardHP.text.length>3){
        _warningBox.text=@"Exceeded limit for HP!(3 chars)";
        _nextBox.enabled=NO;
    }else{
        _nextBox.enabled=YES;
        _warningBox.text=@"";
    }
    [self textFieldDidEndEditing: _hpBox];
    
}
//Called when photo pressed
- (IBAction)takePhoto:(id)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    
    [self presentViewController:picker animated:YES completion:NULL];
}
//called when cam pressed
- (IBAction)cameraRoll:(id)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:picker animated:YES completion:NULL];
}
// stes imageview to the selected image
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    self.imageView.image = chosenImage;
    self.card.image = chosenImage;
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
}
//cancel
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
}
//Begin editing text
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self animateTextField:textField up:YES];
}
//End editing txt
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField:textField up:NO];
}

//scroll screen up/down depening on wheter editing beagin
-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    const int movementDistance = -130; // tweak as needed
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? movementDistance : -movementDistance);
    
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}


- (IBAction)nextPressd:(id)sender {
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"pokeBeep" ofType:@"wav" ];
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    [self.audioPlayer play];
}


@end
