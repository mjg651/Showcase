//
//  MTGRulesVC.m
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/18/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "MTGRulesVC.h"

@interface MTGRulesVC () <UIScrollViewDelegate>
{
    UIScrollView* scrollView;
}
@property (weak, nonatomic) IBOutlet UINavigationBar *navigationBar;
@property (weak, nonatomic) IBOutlet UIButton *scrollToTop;
@property (weak, nonatomic) IBOutlet UIButton *zonesTOC;
@property (weak, nonatomic) IBOutlet UIButton *gameTOC;
@property (weak, nonatomic) IBOutlet UIButton *tapTOC;
@property (weak, nonatomic) IBOutlet UIButton *typeTOC;
@property (weak, nonatomic) IBOutlet UIButton *partsTOC;
@property (weak, nonatomic) IBOutlet UIButton *timingTOC;
@property (weak, nonatomic) IBOutlet UIButton *keywordTOC;

-(void) tableOfContentsSetup: (UIButton*) toc withX:(CGFloat) x withY:(CGFloat) y;
@end

@implementation MTGRulesVC

// Function to set up the table of contents buttons
// Input: UIButton*, CGFloat (x), CGFloat (y)
// Output: void
-(void) tableOfContentsSetup: (UIButton*) toc withX:(CGFloat) x withY:(CGFloat) y
{
    // get the frame of the button
    CGRect frame = toc.frame;
    // set the x origin
    frame.origin.x = x;
    // set the y origin
    frame.origin.y = y;
    // set the button frame equal to modified frame
    toc.frame = frame;
    // display the button
    toc.hidden = NO;
    // set the corner radius
    toc.layer.cornerRadius = 10;
    // clip to bounds
    toc.clipsToBounds = true;
    // set the border width
    toc.layer.borderWidth = 2.0;
    // set the font of the label
    toc.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:15];
    // set the border color
    toc.layer.borderColor = [[UIColor blackColor] CGColor];
}

// Do additional setup after loading the view
- (void)viewDidLoad {
    // call the UIViewController viewDidLoad function
    [super viewDidLoad];
    
    // hide the buttons and the navigation bar for now
    self.zonesTOC.hidden = YES;
    self.gameTOC.hidden = YES;
    self.tapTOC.hidden = YES;
    self.typeTOC.hidden = YES;
    self.partsTOC.hidden = YES;
    self.timingTOC.hidden = YES;
    self.keywordTOC.hidden = YES;
    self.scrollToTop.hidden = YES;
    self.navigationBar.hidden = YES;
    
    // get the phone width of the device we're using
    CGFloat phoneWidth = [UIScreen mainScreen].bounds.size.width;
    
    // initialize the scroll view
    scrollView = [[UIScrollView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    scrollView.bouncesZoom = YES;
    
    // add the scroll view as a subview to the main view
    [self.view addSubview:scrollView];
    
    // create a container view where all of the content will end up going
    UIView* containerView = [[UIView alloc] initWithFrame:CGRectZero];
    [scrollView addSubview:containerView];
    
    // add the navigation bar as a subview of the container view
    [containerView addSubview:self.navigationBar];
    // do not hide the navigation bar
    self.navigationBar.hidden = NO;
    
    // instantiate the image view that will hold the logo
    UIImageView* logoView = [[UIImageView alloc] initWithFrame:CGRectMake(phoneWidth/4-25, 50, 230, 80)];
    // set the image of the logo
    logoView.image = [UIImage imageNamed:@"mtg_logo.png"];
    // add the logo as a subview of the container
    [containerView addSubview:logoView];
    
    // instantiate the rules header
    UILabel* rulesHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 135, phoneWidth,20)];
    // set the text as rules
    rulesHeader.text = @"Rules";
    // set the font
    rulesHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:30];
    // add the header as a subview to the container
    [containerView addSubview:rulesHeader];
    
    // declare the rules subtext
    UILabel* rulesText = [[UILabel alloc] initWithFrame:CGRectMake(0, 135, phoneWidth, 190)];
    // set the text
    rulesText.text = @"Magic: The Gathering is a collectable card game with extremely detailed, and at times, complex rules.\n\nHowever, only a basic understanding of the rules is necessary to play the game. The most important rule is that if the text on a card contradicts a game rule, the card text always takes precedence. Magic: The Gathering is thus constantly breaking its own rules, making it a challenging and intricate game.";
    // set the font
    rulesText.font = [UIFont fontWithName:@"MPlantin" size:15];
    // set the number of lines
    rulesText.numberOfLines = 10;
    // as a subview of the container view
    [containerView addSubview:rulesText];
    
    // table of contents header
    UILabel* TOC = [[UILabel alloc] initWithFrame:CGRectMake(0, 310, phoneWidth,30)];
    // table of contents text
    TOC.text = @"Table of Contents";
    // table of contents font
    TOC.font = [UIFont fontWithName:@"Matrix-Bold" size:30];
    // add the table of contents header as a subview of the container
    [containerView addSubview:TOC];
    
    // format table of contents
    [self tableOfContentsSetup:self.zonesTOC withX:0 withY:345];
    [containerView addSubview:self.zonesTOC];
    
    [self tableOfContentsSetup:self.gameTOC withX:0 withY:385];
    [containerView addSubview:self.gameTOC];
    
    [self tableOfContentsSetup:self.tapTOC withX:0 withY:425];
    [containerView addSubview:self.tapTOC];

    [self tableOfContentsSetup:self.typeTOC withX:0 withY:465];
    [containerView addSubview:self.typeTOC];

    [self tableOfContentsSetup:self.partsTOC withX:0 withY:505];
    [containerView addSubview:self.partsTOC];
    
    [self tableOfContentsSetup:self.timingTOC withX:0 withY:545];
    [containerView addSubview:self.timingTOC];
    
    [self tableOfContentsSetup:self.keywordTOC withX:0 withY:585];
    [containerView addSubview:self.keywordTOC];
    
    // format the zones header
    UILabel* zonesHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 675, phoneWidth,50)];
    zonesHeader.text = @"Zones: Areas of Play";
    zonesHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:30];
    // add as subview of container
    [containerView addSubview:zonesHeader];
    
    // format the zones intro
    UILabel* zonesIntro = [[UILabel alloc] initWithFrame:CGRectMake(0, 720, phoneWidth, 30)];
    zonesIntro.text = @"At any given time, every card is located in one of the following zones:";
    zonesIntro.font = [UIFont fontWithName:@"MPlantin" size:15];
    zonesIntro.numberOfLines = 2;
    // add as subview of container
    [containerView addSubview:zonesIntro];
    
    // format the library header
    UILabel* libraryHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 755, phoneWidth, 20)];
    libraryHeader.text = @"Library";
    libraryHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:libraryHeader];
    
    // format the library text
    UILabel* libraryText = [[UILabel alloc] initWithFrame:CGRectMake(0, 725, phoneWidth, 200)];
    libraryText.text = @"A player's deck. These cards are kept face down and should be randomly ordered (which means, shuffled at the beginning of the game). It must contain at least 60 cards in Constructed play, or at least 40 cards in Limited play. There is no maximum deck size, although there may only be 4 of any nonbasic land card.";
    libraryText.font = [UIFont fontWithName:@"MPlantin" size:15];
    libraryText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:libraryText];
    
    // format the graveyard header
    UILabel* graveyardHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 875, phoneWidth, 20)];
    graveyardHeader.text = @"Graveyard";
    graveyardHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:graveyardHeader];
    
    // format the graveyard text
    UILabel* graveyardText = [[UILabel alloc] initWithFrame:CGRectMake(0, 850, phoneWidth, 200)];
    graveyardText.text = @"A player's discard pile. When a card in play is destroyed, or an instant or sorcery is taken off the stack, it is put in its owner's graveyard. These cards are face up, and can be examined by any player at any time. Several cards, like Disentomb or Rise from the Grave, allow you to take cards from a graveyard and return them to your hand, on the battlefield, or somewhere in your library.";
    graveyardText.font = [UIFont fontWithName:@"MPlantin" size:15];
    graveyardText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:graveyardText];
    
    // format the hand header
    UILabel* handHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 1010, phoneWidth, 20)];
    handHeader.text = @"Hand";
    handHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:handHeader];
    
    // format the hand text
    UILabel* handText = [[UILabel alloc] initWithFrame:CGRectMake(0, 1000, phoneWidth, 200)];
    handText.text = @"A player's hand of cards. They are normally kept hidden from other players; however, cards like Telepathy and a number of 'discard' spells can allow players to look at some or all of the cards in other players' hands. The number of cards each player has is public. If you have more than 7 cards in your hand at the end of your turn, you must discard until you have only 7 cards in your hand; as always, cards like the Artifact Spellbook can override this.";
    handText.font = [UIFont fontWithName:@"MPlantin" size:15];
    handText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:handText];
    
    // format the stack header
    UILabel* stackHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 1175, phoneWidth, 20)];
    stackHeader.text = @"Stack";
    stackHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:stackHeader];
    
    // format the stack text
    UILabel* stackText = [[UILabel alloc] initWithFrame:CGRectMake(0, 1130, phoneWidth, 200)];
    stackText.text = @"This is the place for cards that have been cast but not yet resolved. Activated abilities and triggered abilities also go on the stack until they resolve. This zone is shared by all players.";
    stackText.font = [UIFont fontWithName:@"MPlantin" size:15];
    stackText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:stackText];
    
    // format the battlefield header
    UILabel* battlefieldHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 1270, phoneWidth, 20)];
    battlefieldHeader.text = @"Battlefield";
    battlefieldHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:battlefieldHeader];
    
    // format the battlefield text
    UILabel* battlefieldText = [[UILabel alloc] initWithFrame:CGRectMake(0, 1225, phoneWidth, 200)];
    battlefieldText.text = @"Most cards need to enter the battlefield before they can affect the game. All players share a single battlefield. All permanents stay on the battlefield unless effects or the rules instruct players to remove them.";
    battlefieldText.font = [UIFont fontWithName:@"MPlantin" size:15];
    battlefieldText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:battlefieldText];
    
    // format the exile header
    UILabel* exileHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 1360, phoneWidth, 20)];
    exileHeader.text = @"Exile";
    exileHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:exileHeader];
    
    // format the exile text
    UILabel* exileText = [[UILabel alloc] initWithFrame:CGRectMake(0, 1355, phoneWidth, 200)];
    exileText.text = @"This is where cards that have been exiled are placed: to exile a card means to take it from its current zone and place it in this zone. The text of a card may specify that a card is exiled face-down; if it does not, the card is exiled face-up. Some examples of cards that exile other cards are Iona's Judgement and Celestial Purge. Some cards, Journey to Nowhere and Oblivion Ring being two examples, exile cards, but later return them to the battlefield.";
    exileText.font = [UIFont fontWithName:@"MPlantin" size:15];
    exileText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:exileText];
    
    // format the command header
    UILabel* commandHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 1525, phoneWidth, 20)];
    commandHeader.text = @"Command Zone";
    commandHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:commandHeader];
    
    // format the command text
    UILabel* commandText = [[UILabel alloc] initWithFrame:CGRectMake(0, 1485, phoneWidth, 200)];
    commandText.text = @"The command zone is a game area reserved for certain specialized objects that can affect the game, but are not permanents or cards in exile.  This includes schemes, planes, emblems and Commanders.";
    commandText.font = [UIFont fontWithName:@"MPlantin" size:15];
    commandText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:commandText];
    
    // format the begin header
    UILabel* beginHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 1610, phoneWidth,50)];
    beginHeader.text = @"Beginning and Ending the Game";
    beginHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:29];
    // add as subview of container
    [containerView addSubview:beginHeader];
    
    // format the begin text
    UILabel* beginText = [[UILabel alloc] initWithFrame:CGRectMake(0, 1655, phoneWidth, 350)];
    beginText.text = @"At the beginning of a game, each player shuffles his or her deck. A randomly selected player decides which player will take the first turn. The players then draw seven cards each to form their starting hand. Each player may then decide to mulligan; that player shuffles his or her hand and library together and draws a new hand, but with one less card than before (six). A player can do this as many times as he or she wishes, drawing one less card each time (five, four, etc).\n\nIn two-player games, the player who takes the first turn does not draw a card for that turn, but the others do. In multiplayer games, everyone draws on their first turn.\n\nA player wins the game by eliminating all opponents. Players begin the game with 20 life; if a player's life total is reduced to zero or less, he or she loses the game. Additionally, if a player is required to draw a card but has no cards left in his or her library, he or she loses. If a player has 10 or more poison counters, he or she loses the game. Specific cards, like Felidar Sovereign or Door to Nothingness, may dictate other ways of winning or losing.";
    beginText.font = [UIFont fontWithName:@"MPlantin" size:15];
    beginText.numberOfLines = 25;
    // add as subview of container
    [containerView addSubview:beginText];
    
    // format the tap header
    UILabel* tapHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 2000, phoneWidth,50)];
    tapHeader.text = @"Tapping, Untapping and Mana";
    tapHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:30];
    // add as subview of container
    [containerView addSubview:tapHeader];
    
    // format the tap subheader
    UILabel* tapSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 2050, phoneWidth, 20)];
    tapSubheader.text = @"Tapping and Untapping";
    tapSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:tapSubheader];
    
    // format the tap text
    UILabel* tapText = [[UILabel alloc] initWithFrame:CGRectMake(0, 2075, phoneWidth, 350)];
    tapText.text = @"At the beginning of a game, each player shuffles his or her deck. A randomly selected player decides which player will take the first turn. The players then draw seven cards each to form their starting hand. Each player may then decide to mulligan; that player shuffles his or her hand and library together and draws a new hand, but with one less card than before (six). A player can do this as many times as he or she wishes, drawing one less card each time (five, four, etc).\n\nIn two-player games, the player who takes the first turn does not draw a card for that turn, but the others do. In multiplayer games, everyone draws on their first turn.\n\nA player wins the game by eliminating all opponents. Players begin the game with 20 life; if a player's life total is reduced to zero or less, he or she loses the game. Additionally, if a player is required to draw a card but has no cards left in his or her library, he or she loses. If a player has 10 or more poison counters, he or she loses the game. Specific cards, like Felidar Sovereign or Door to Nothingness, may dictate other ways of winning or losing.";
    tapText.font = [UIFont fontWithName:@"MPlantin" size:15];
    tapText.numberOfLines = 25;
    // add as subview of container
    [containerView addSubview:tapText];

    // format the mana subheader
    UILabel* manaSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 2435, phoneWidth, 20)];
    manaSubheader.text = @"Mana Cost and Colors";
    manaSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:manaSubheader];
    
    // format the mana text
    UILabel* manaText = [[UILabel alloc] initWithFrame:CGRectMake(0, 2455, phoneWidth, 800)];
    manaText.text = @"The vast majority of nonland cards have a mana cost. This is the amount of mana that must be spent to pay for the card. Each mana symbol in the top right corner of the card represents one mana of that color that must be paid. There may be a number in a gray circle next to the mana symbols. This represents how much additional mana must be paid; this additional mana can be of any color or colorless.\n\nFor example, the cards below all cost 3 mana. However, the card on the left requires three black mana, while the card on the right can be paid for with three mana of any color or combination of colors. The middle two cards require, respectively, 2 mana and 1 mana that must be black; the remainder can be any color. Note that the first three cards are black, but Disrupting Scepter is colorless.\n\nSome cards may require their owner to pay mana of two or more colors. These cards have multiple colors, and they are called multi-colored. Some cards also use hybrid mana symbols: a hybrid mana symbol looks like one kind of mana symbol in its top-left and another kind of mana symbol in its bottom-left half. A cost represented by a hybrid mana symbol can be satisfied by paying whatever is normally required of either half of the symbol. For example, the card Deathrite Shaman can be played by spending either one black mana, or one green mana. Cards with hybrid mana symbols in their mana costs, like traditional 'gold' (so-called because of the color of their border on the card) multi-colour cards, are always all of the colors that appear in their mana symbols: so Deathrite Shaman is always green and black regardless of what was spent to cast it.\n\nSome nonland cards have a mana cost of zero, indicated by a number 0 in a grey circle - these have a mana cost that requires no mana to cast.\n\nFinally there are seven nonland cards with a blank mana cost. Examples are:\n\n\t  - Evermind\n\t  - Living End\n\t  - Ancestral Vision\n\t  - Hypergenesis\n\t  - Lotus Bloom\n\t  - Wheel of Fate\n\t  - Restore Balance\n\nA blank mana cost represents an unpayable cost, and cannot be cast without using an alternate cost (such as the one offered by the Suspend ability). These cards are given colors by the Color Indicator on the card.";
    manaText.font = [UIFont fontWithName:@"MPlantin" size:15];
    manaText.numberOfLines = 75;
    // add as subview of container
    [containerView addSubview:manaText];
    
    // format the ability subheader
    UILabel* abSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 3265, phoneWidth, 20)];
    abSubheader.text = @"Abilities";
    abSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:abSubheader];
    
    // format the ability text
    UILabel* abText = [[UILabel alloc] initWithFrame:CGRectMake(0, 3225, phoneWidth, 950)];
    abText.text = @"There are four main types of abilities:\n\n\t  - Activated Ability\n\t  - Triggered Ability\n\t  - Spell Ability\n\t  - Static Ability\n\nActivated Abilities are abilities of a card that the controller of the card must pay to activate. These abilities are always written in the form '{Cost}: {Effect}'. Paying the cost allows a player to cause the effect to happen. Costs may include paying mana, tapping the card, discarding cards, or other things. These abilities can typically be activated any time a player has priority (see timing and the stack).\n\nTriggered Abilities are not used by any player, but simply look for a particular event, time, or game state, and then produce an effect when that event/time/state occurs. These abilities contain a trigger condition (which will use one of the words 'when, 'whenever', or 'at'), usually at the start of the ability, and then an effect. Whenever the trigger condition is met, the card produces the effect. The card may also lay out additional conditions that must be met for the effect to occur (using the word 'if').\n\nTriggered Abilities automatically happen whenever their condition is met. They go on the stack and resolve like other spells and abilities. If multiple triggered abilities' conditions are met at the same time, those controlled by the active player (the player whose turn it is) are put on the stack first, in whatever order he or she chooses; then all of the other players place, in turn order, the triggered abilities they control on the stack also in whatever order the controller chooses.\n\nSpell Abilities are the texts of instants and sorceries that describe the effect of the spell. For example, the ability on Lightning Shock ('Lightning Shock deals 3 damage to target creature or player') is a spell ability.\n\nStatic Abilities are general effects that alter cards in play or the rules of the game. If an ability is not a spell ability, activated or triggered, it is a static ability. Static abilities only work while the card is on the battlefield, unless the ability says otherwise or the ability only makes sense if it applies from a different zone. For example, a card that refers to playing itself from the graveyard will still work from the graveyard; one that refers to playing any other card from the graveyard will not. A static ability takes effect as soon as the card is in play. Once the card leaves play, the ability stops working. Static abilities never use the stack, although they may change the game state and cause triggered abilities to trigger.";
    abText.font = [UIFont fontWithName:@"MPlantin" size:15];
    abText.numberOfLines = 85;
    // add as subview of container
    [containerView addSubview:abText];
    
    // format the types of cards header
    UILabel* typesHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 4105, phoneWidth,50)];
    typesHeader.text = @"Types of Cards";
    typesHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:30];
    // add as subview of container
    [containerView addSubview:typesHeader];
    
    // format the land subheader
    UILabel* landSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 4150, phoneWidth, 20)];
    landSubheader.text = @"Lands";
    landSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:landSubheader];
    
    // format the land text
    UILabel* landText = [[UILabel alloc] initWithFrame:CGRectMake(0, 4165, phoneWidth, 200)];
    landText.text = @"Land cards often have an activated ability that allows their controller to tap them for mana. They cost no mana to play; however, a player may typically play no more than one land on each of his or her turns. There are five types of basic lands, one for each colour. Each basic land has a basic land type. Any land which has a basic land type can be tapped to produce one mana of the color associated with that basic land type. You may have as many basic lands in your deck as you desire. A land which isn't basic is referred to as a  'non-basic land' and may produce other combinations or amounts of mana, or may have other abilities.";
    landText.font = [UIFont fontWithName:@"MPlantin" size:15];
    landText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:landText];
    
    // format the creature subheader
    UILabel* creatureSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 4370, phoneWidth, 20)];
    creatureSubheader.text = @"Creatures";
    creatureSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:creatureSubheader];
    
    // format the creature text
    UILabel* creatureText = [[UILabel alloc] initWithFrame:CGRectMake(0, 4395, phoneWidth, 200)];
    creatureText.text = @"Creatures represent people or beasts that are summoned to attack opposing players and defend their controller from the attacks of enemy creatures. They are summoned by casting them as a spell that then becomes a permanent on the battlefield. Creatures have two numbers associated with them that represent their strength in combat: power and toughness. These values are printed on the lower right-hand corner of the card, with a slash separating them. The first number is the creature's power; it represents the amount of damage it deals in combat. The second number is its toughness; if it receives that much damage in a single turn, it is destroyed and placed in the graveyard.";
    creatureText.font = [UIFont fontWithName:@"MPlantin" size:15];
    creatureText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:creatureText];
    
    // format the enchantment subheader
    UILabel* enchantmentSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 4600, phoneWidth, 20)];
    enchantmentSubheader.text = @"Enchantments";
    enchantmentSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:enchantmentSubheader];
    
    // format the enchantment text
    UILabel* enchantmentText = [[UILabel alloc] initWithFrame:CGRectMake(0, 4630, phoneWidth, 200)];
    enchantmentText.text = @"Enchantments represent persistent magical or mystical effects; they are spells that remain on the battlefield and alter some aspect of the game.\n\nSome enchantments are attached to other cards on the battlefield (often creatures); these are known as Auras. If the card have an Aura is attached to leaves the battlefield, the Aura goes to the graveyard.\n\nEnchantments auras can also effect multiple creatures at once such as Echoing Courage this card gives +2/+2 to a creature you choose and every other creature with the same name.";
    enchantmentText.font = [UIFont fontWithName:@"MPlantin" size:15];
    enchantmentText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:enchantmentText];
    
    // format the artifact subheader
    UILabel* artifactSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 4835, phoneWidth, 20)];
    artifactSubheader.text = @"Artifacts";
    artifactSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:artifactSubheader];
    
    // format the artifact text
    UILabel* artifactText = [[UILabel alloc] initWithFrame:CGRectMake(0, 4860, phoneWidth, 250)];
    artifactText.text = @"Artifacts represent magical items, animated constructs, pieces of equipment, or other objects and devices. Like other permanents, artifacts remain on the battlefield until something removes them. Artifacts are distinct from other cards in that they are colorless, and can be cast using any color or colors of mana.\n\nMany artifacts are also creatures; they may attack and defend as other creatures, and are affected by anything that affects either artifacts or creatures. Some artifacts are Equipment. Equipment cards enter the battlefield just like any other artifact, but may be attached to creatures using their Equip ability. Unlike Auras, however, if an Equipment is attached to a creature and the creature leaves the battlefield, the Equipment stays on the battlefield.";
    artifactText.font = [UIFont fontWithName:@"MPlantin" size:15];
    artifactText.numberOfLines = 20;
    // add as subview of container
    [containerView addSubview:artifactText];
    
    // format the sorceries and instants subheader
    UILabel* sorcerySubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 5110, phoneWidth, 20)];
    sorcerySubheader.text = @"Sorceries and Instants";
    sorcerySubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:sorcerySubheader];
    
    // format the sorcery text
    UILabel* sorceryText = [[UILabel alloc] initWithFrame:CGRectMake(0, 5135, phoneWidth, 200)];
    sorceryText.text = @"Sorceries and instants both represent one-shot or short-term magical spells. They never enter the battlefield. Instead they are cast as a spell, have their effect when they resolve, and then are immediately put into the player's graveyard.\n\nSorceries and instants differ only in when they can be cast. Sorceries can be cast during the player's main phase, and only when nothing else is on the stack. Instants, on the other hand, can be cast any time a player has priority, including during other player's turns and while another spell or ability is waiting to resolve (see timing and the stack).";
    sorceryText.font = [UIFont fontWithName:@"MPlantin" size:15];
    sorceryText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:sorceryText];
    
    // format the parts of a turn header
    UILabel* partsHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 5335, phoneWidth,50)];
    partsHeader.text = @"The Parts of a Turn";
    partsHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:30];
    // add as subview of container
    [containerView addSubview:partsHeader];
    
    // format the beginning phase subheader
    UILabel* beginningSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 5380, phoneWidth, 20)];
    beginningSubheader.text = @"Beginning Phase";
    beginningSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:beginningSubheader];
    
    // format the beginning text
    UILabel* beginningText = [[UILabel alloc] initWithFrame:CGRectMake(0, 5365, phoneWidth, 300)];
    beginningText.text = @"The beginning phase is composed of three parts.*\n\n\t1.  Untap all cards he or she controls.\n\n\t2.  Any abilities that trigger on the 'upkeep step' happen. These often include cards that require mana payments every turn.\n\n\t3.  The player draws a card.\n\n * Note: If there are two people playing, the player who takes the first turn does not draw a card on the first turn as a balancing factor. If there are more than two, this rule does not apply.";
    beginningText.font = [UIFont fontWithName:@"MPlantin" size:15];
    beginningText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:beginningText];
    
    // format the main phase subheader
    UILabel* mainSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 5630, phoneWidth, 20)];
    mainSubheader.text = @"Main Phase";
    mainSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:mainSubheader];
    
    // format the main phase text
    UILabel* mainText = [[UILabel alloc] initWithFrame:CGRectMake(0, 5590, phoneWidth, 200)];
    mainText.text = @"Most of the game's actions happen during the main phase. With the exception of Instants, cards can only be played during a player's main phase. There are two main phases each turn: one before and one after the combat phase.";
    mainText.font = [UIFont fontWithName:@"MPlantin" size:15];
    mainText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:mainText];
    
    // format the combat phase subheader
    UILabel* combatSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 5740, phoneWidth, 20)];
    combatSubheader.text = @"Combat Phase";
    combatSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:combatSubheader];
    
    // format the combat phase text
    UILabel* combatText = [[UILabel alloc] initWithFrame:CGRectMake(0, 5695, phoneWidth, 200)];
    combatText.text = @"The combat phase is split up into steps. Except for instants, players may not play cards during combat. However, instants may be cast and abilities may be activated before and after each step.";
    combatText.font = [UIFont fontWithName:@"MPlantin" size:15];
    combatText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:combatText];
    
    // format the attacking phase subheader
    UILabel* attackingSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 5830, phoneWidth, 20)];
    attackingSubheader.text = @"Attacking";
    attackingSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:16];
    // add as subview of container
    [containerView addSubview:attackingSubheader];
    
    // format the attacking phase text
    UILabel* attackText = [[UILabel alloc] initWithFrame:CGRectMake(0, 5800, phoneWidth, 200)];
    attackText.text = @"The player whose turn it is may attack another player with creatures he or she controls. Creatures that are tapped or that were played this turn may not attack. Attacking causes a creature to become tapped. A player can attack with as many creatures as he or she wants; they all tap and attack at the same time.";
    attackText.font = [UIFont fontWithName:@"MPlantin" size:15];
    attackText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:attackText];
    
    // format the blocking phase subheader
    UILabel* blockingSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 5950, phoneWidth, 20)];
    blockingSubheader.text = @"Blocking";
    blockingSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:16];
    // add as subview of container
    [containerView addSubview:blockingSubheader];
    
    // format the blocking text
    UILabel* blockingText = [[UILabel alloc] initWithFrame:CGRectMake(0, 5930, phoneWidth, 200)];
    blockingText.text = @"The player being attacked may block the attacking creatures with his or her own creatures, but is not required to do so. Tapped creatures cannot block, but blocking doesn't tap a creature. Each creature may only block one attacking creature, but multiple creatures may all block the same attacker. As with attacking creatures, blocking creatures all block at the same time.";
    blockingText.font = [UIFont fontWithName:@"MPlantin" size:15];
    blockingText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:blockingText];
    
    // format the damage subheader
    UILabel* damageSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 6090, phoneWidth, 20)];
    damageSubheader.text = @"Damage";
    damageSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:16];
    // add as subview of container
    [containerView addSubview:damageSubheader];
    
    // format the damage text
    UILabel* damageText = [[UILabel alloc] initWithFrame:CGRectMake(0, 6060, phoneWidth, 450)];
    damageText.text = @"Attacking creatures that weren't blocked deal damage equal to their power to the player they attacked; the amount of damage caused is deducted from the player's life total. (Or added to the players poison counter total, in the case of infect.) Attacking creatures that were blocked deal damage equal to their power to the creature or creatures that blocked them, and blocking creatures deal damage equal to their power to the attacking creature they blocked. If a creature could deal damage to several creatures that blocked it, the player that controls the attacking creature chooses how to distribute the damage. The attacking player must assign lethal damage (that is, damage equal to the blocker's toughness) to the one blocker before he/she can assign more damage to another blocker; this continues for each blocker (1 point of damage from a creature with deathtouch is considered lethal damage). An attacker that is blocked, but whose blocker is removed from combat before this time deals no damage at all. If a creature is dealt as much or more damage than its toughness, it is destroyed and must be put in its controller's graveyard.\n\nCombat damage does not use the stack.";
    damageText.font = [UIFont fontWithName:@"MPlantin" size:15];
    damageText.numberOfLines = 25;
    // add as subview of container
    [containerView addSubview:damageText];
    
    // format the second main phase subheader
    UILabel* secondSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 6465, phoneWidth, 20)];
    secondSubheader.text = @"Second Main Phase";
    secondSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:secondSubheader];
    
    // format the second main phase text
    UILabel* secondText = [[UILabel alloc] initWithFrame:CGRectMake(0, 6395, phoneWidth, 200)];
    secondText.text = @"Same rules apply as your first main phase.";
    secondText.font = [UIFont fontWithName:@"MPlantin" size:15];
    // add as subview of container
    [containerView addSubview:secondText];
    
    // format the end phase subheader
    UILabel* endSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 6520, phoneWidth, 20)];
    endSubheader.text = @"End Phase";
    endSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:endSubheader];
    
    // format the end phase text
    UILabel* endText = [[UILabel alloc] initWithFrame:CGRectMake(0, 6510, phoneWidth, 200)];
    endText.text = @"The end phase has two steps: 'Endstep' and 'Cleanup'. During the first, abilities that trigger 'at end of turn' take place. Then, during the cleanup step, the player whose turn it is discards down to 7 cards. Effects that last 'until end of turn' or 'this turn' wear off, and non-lethal damage is removed from creatures. Players may play instants or abilities during the end step, but not during the cleanup step.";
    endText.font = [UIFont fontWithName:@"MPlantin" size:15];
    endText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:endText];
    
    // format the timing and the stack header
    UILabel* timingHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 6675, phoneWidth,50)];
    timingHeader.text = @"Timing and the Stack";
    timingHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:30];
    // add as subview of container
    [containerView addSubview:timingHeader];
    
    // format the priority subheader
    UILabel* prioritySubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 6720, phoneWidth, 20)];
    prioritySubheader.text = @"Priority";
    prioritySubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:prioritySubheader];
    
    // format the priority text
    UILabel* priorityText = [[UILabel alloc] initWithFrame:CGRectMake(0, 6725, phoneWidth, 350)];
    priorityText.text = @"Priority in Magic is essentially the ability to act: nearly every action a player may want to take in a game can only be taken when that player 'has priority'. In a turn, the active player is always the first to receive priority and he or she retains priority until he or she explicitly passes it. Then the player who succeeds him or her in turn order receives priority until that player passes it and so on until every player has received priority. If all players have passed in succession without performing any game actions, the top object of the stack resolves or, if the stack is empty, the current phase or step of the turn ends and the game passes to the next one.\n\nPriority is also used to describe the two kinds of times at which players may take actions. Actions that are described as allowable 'when a player could cast a sorcery' mean that action can only be taken when that player has priority during a main phase of his or her turn and while the stack is empty. Game actions that don't use that description can be taken whenever a player merely has priority.";
    priorityText.font = [UIFont fontWithName:@"MPlantin" size:15];
    priorityText.numberOfLines = 30;
    // add as subview of container
    [containerView addSubview:priorityText];
    
    // format the stack subheader
    UILabel* stackSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 7070, phoneWidth, 20)];
    stackSubheader.text = @"The Stack";
    stackSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:stackSubheader];
    
    // format the stack mechanic text
    UILabel* stackMechanicText = [[UILabel alloc] initWithFrame:CGRectMake(0, 7080, phoneWidth, 300)];
    stackMechanicText.text = @"This mechanic is nearly identical to the concept of a stack in computer science.\n\nWhen a player casts a spell, it does not immediately take effect. Instead, it is placed on the stack, and each player has a chance to respond to it with Instant spells or activated abilities. Each new spell or ability is put on top of the stack in turn, with the newest on top and the oldest at the bottom. Once each player finishes adding objects to the stack, he or she passes priority to the next player. If every player has passed priority once without performing an action or adding a object to the stack, the top object of the stack resolves. If it was a sorcery, instant, or ability, the player carries out the instructions; if it was a creature, enchantment, or artifact, it is put onto the battlefield. Every time a spell or ability resolves, players once again receive priority and can add more objects to the stack, if they wish.";
    stackMechanicText.font = [UIFont fontWithName:@"MPlantin" size:15];
    stackMechanicText.numberOfLines = 25;
    // add as subview of container
    [containerView addSubview:stackMechanicText];
    
    // format the stack example subheader
    UILabel* stackExampleSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 7370, phoneWidth, 20)];
    stackExampleSubheader.text = @"Example";
    stackExampleSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:16];
    // add as subview of container
    [containerView addSubview:stackExampleSubheader];
    
    // format the stack example text
    UILabel* stackExampleText = [[UILabel alloc] initWithFrame:CGRectMake(0, 7350, phoneWidth, 900)];
    stackExampleText.text = @"Alice is attacking Bob with a Hill Giant, a 3/3 creature (meaning it has 3 power and 3 toughness). Bob chooses to block with his Grizzly Bears, a weaker 2/2 creature. If nothing else happened, the Hill Giant would deal 3 damage to the Grizzly Bears and kill them, while the Bears would deal 2 damage to the Giant, which would survive.\n\nHowever, Bob decides to play his Giant Growth spell on his Grizzly Bears before combat damage is dealt. He taps a forest to pay for the spell, and puts it on the stack. Alice, who does not want to give the Grizzly Bears a chance to grow to 5/5 and kill her Hill Giant, responds by playing Shock. She taps one mountain, casts Shock, tells Bob she is targeting the Grizzly Bears, and puts Shock on the stack on top of Giant Growth.\n\nIf Bob had no other spells, then Alice's Shock would resolve first and deal 2 damage to the Grizzly Bears, killing them. His Giant Growth would then go to the graveyard with no effect because the Bears would no longer be in play and would thus be an illegal target. Fortunately for Bob, he has another spell to play. He taps a plains and plays Mending Hands on his Grizzly Bears. Now Mending Hands is on top of the stack, with Shock and then Giant Growth beneath it.\n\nSince both players are out of spells to cast, they both pass priority without doing anything. Mending Hands is the top object of the stack so it resolves: its effect creates a 'damage shield' that can prevent up to 4 points of damage dealt to the Grizzly Bears, the card is then put into Bob's graveyard. Both players pass priority again, so the new top object Shock resolves. It attempts to deal 2 damage to Grizzly Bears, but Mending Hands' damage shield prevents the damage, and Shock is put into Alice's graveyard. Finally, both players pass priority one more time and the final object Giant Growth resolves and makes Grizzly Bears a 5/5 creature until end of turn. Giant Growth is put into Bob's graveyard.\n\nOnce combat damage is dealt, the now 5/5 Grizzly Bears will deal 5 damage to the Hill Giant and destroy it. Hill Giant will attempt to deal 3 damage to the Grizzly Bears, but the remainder of Mending Hands' damage shield will prevent a further 2 damage (totaling 4 damage) and Grizzly Bears will only take 1 damage.\n\nWhen the turn ends, the single point of damage is removed from the Grizzly Bears, and the Giant Growth effect wears off at the same time. When Bob's turn comes around again, he'll find his Grizzly Bears undamaged and 2/2.";
    stackExampleText.font = [UIFont fontWithName:@"MPlantin" size:15];
    stackExampleText.numberOfLines = 95;
    // add as subview of container
    [containerView addSubview:stackExampleText];
    
    // format the countering subheader
    UILabel* counteringSubheader = [[UILabel alloc] initWithFrame:CGRectMake(0, 8200, phoneWidth, 20)];
    counteringSubheader.text = @"Countering";
    counteringSubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:20];
    // add as subview of container
    [containerView addSubview:counteringSubheader];
    
    // format the countering text
    UILabel* counteringText = [[UILabel alloc] initWithFrame:CGRectMake(0, 8205, phoneWidth, 500)];
    counteringText.text = @"Certain spells allow a player to counter other spells. These spells target the spell they are to counter, and must be played while the first spell is on the stack. If a spell is countered, it is moved from the stack to its owner's graveyard. It does not resolve, and has no effect. If the spell was a permanent, it never comes into play. Some spells state that they cannot be countered. However, the ability 'cannot be the target of spells or abilities' only applies while in play, and so a card with such an ability can still be countered.\n\nThere is one other way for a spell to be countered. If the spell targets something (such as Giant Growth or Shock), then the target must be legal both when the spell is played and when it resolves. If it is illegal when played, the player cannot play the spell. If it is illegal when the spell resolves, most commonly because the target is no longer in play, then the spell is countered. If a spell is countered this way, then no part of the spell - even an untargeted effect of the spell - takes place. This form of spell countering is also known as fizzling.\n\nIf a spell has multiple targets, then all of them must be illegal for the spell to be countered. For example, the card Swelter deals 2 damage to two target creatures. If one creature becomes an illegal target before Swelter resolves, the other will still be damaged. But if they are both illegal, then the entire spell is countered. Note that a spell must have all targets available for it to be played. If there is only one legal target for Swelter, then Swelter can't be played.";
    counteringText.font = [UIFont fontWithName:@"MPlantin" size:15];
    counteringText.numberOfLines = 65;
    // add as subview of container
    [containerView addSubview:counteringText];
    
    // format the keyword abilities header
    UILabel* keywordHeader = [[UILabel alloc] initWithFrame:CGRectMake(0, 8690, phoneWidth,50)];
    keywordHeader.text = @"Keyword Abilities";
    keywordHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:30];
    // add as subview of container
    [containerView addSubview:keywordHeader];
    
    // format the keyword text
    UILabel* keywordText = [[UILabel alloc] initWithFrame:CGRectMake(0, 8680, phoneWidth, 200)];
    keywordText.text = @"Some cards have abilities that are not fully explained on the card. These are known as 'keyword' abilities, and consist of a word or phrase whose meaning is defined by the rules. Keyword abilities are usually given reminder text in the set in which they are introduced.";
    keywordText.font = [UIFont fontWithName:@"MPlantin" size:15];
    keywordText.numberOfLines = 15;
    // add as subview of container
    [containerView addSubview:keywordText];
    
    // set the container views's frame size
    containerView.frame = CGRectMake(0, 0, phoneWidth, 8880);
    // set the content size of the scroll view
    scrollView.contentSize = containerView.frame.size;
    
    // add the scroll to top button to the main view
    [self.view addSubview:self.scrollToTop];
    
    // set the scroll view delegate to self
    scrollView.delegate = self;
}

// Function to scroll to the Zones: Areas of Play section
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)zonesTOCPicker:(id)sender
{
    // set the content offset of the scroll view animated
    [scrollView setContentOffset:CGPointMake(0, 675) animated:YES];
}

// Function to scroll to Beginning and Ending the Game section
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)beginningTOCPicker:(id)sender
{
    // set the content offset of the scroll view animated
    [scrollView setContentOffset:CGPointMake(0, 1610) animated:YES];
}

// Function to scroll to Tapping, Untapping and Mana section
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)tappingTOCPicker:(id)sender
{
    // set the content offset of the scroll view animated
    [scrollView setContentOffset:CGPointMake(0, 2000) animated:YES];
}

// Function to scroll to Types of Cards section
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)typesTOCPicker:(id)sender
{
    // set the content offset of the scroll view animated
    [scrollView setContentOffset:CGPointMake(0, 4105) animated:YES];
}

// Function to scroll to Parts of a Turn section
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)partsTOCPicker:(id)sender
{
    // set the content offset of the scroll view animated
    [scrollView setContentOffset:CGPointMake(0, 5335) animated:YES];
}

// Function to scroll to Timing and the Stack section
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)timingTOCPicker:(id)sender
{
    // set the content offset of the scroll view animated
    [scrollView setContentOffset:CGPointMake(0, 6675) animated:YES];
}

// Function scroll to Keyword Abilities section
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)keywordTOCPicker:(id)sender
{
    // set the content offset of the scroll view animated
    [scrollView setContentOffset:CGPointMake(0, 8690) animated:YES];
}

// Function to implement scroll to top functionality
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)scrollToTop:(id)sender
{
    // set the content offset of the scroll view animated
    [scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
}

// Function to dismiss the view controller when the back button is pressed
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)backButtonPressed:(id)sender
{
    // dismiss the view controller
    [self dismissViewControllerAnimated:YES completion:nil];
}

// Function to detect when the scroll view is scrolling
// Input: UIScrollView*
// Output: void
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    // if the scroll view is below the table of content section
    if (scrollView.contentOffset.y > [UIScreen mainScreen].bounds.size.height)
    {
        // display the scroll to top button
        self.scrollToTop.hidden = NO;
    }
    // otherwise
    else
    {
        // hide the scroll to top button
        self.scrollToTop.hidden = YES;
    }
}

@end
