//
//  PokeRulesVC.h
//  tcgbrainstorm_beta
//
//  Created by Matt Guarneri on 4/20/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "ViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface PokeRulesVC : ViewController
-(void) tableOfContentsSetup: (UIButton*) toc;
@end

NS_ASSUME_NONNULL_END
