//
//  CustomMagicCard.h
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/5/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomMagicCard : NSObject

@property (strong, nonatomic) NSString* name;
@property (strong, nonatomic) NSString* color;
@property (strong, nonatomic) NSString* type;
@property (strong, nonatomic) NSString* subtype;
@property (strong, nonatomic) NSString* castingCost;
@property (strong, nonatomic) NSString* abilityCost;
@property (strong, nonatomic) NSString* ability;
@property (strong, nonatomic) NSString* power;
@property (strong, nonatomic) NSString* toughness;
@property (strong, nonatomic) UIImage* image;
@property (strong, nonatomic) NSString* flavorText;
@property (strong, nonatomic) NSString* artistName;
@property (nonatomic) NSInteger rarity;

-(void) print;

@end

NS_ASSUME_NONNULL_END
