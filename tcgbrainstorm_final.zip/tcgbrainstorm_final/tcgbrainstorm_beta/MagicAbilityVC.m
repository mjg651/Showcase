//
//  MagicAbilityVC.m
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/5/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "MagicAbilityVC.h"
#import <AVFoundation/AVFoundation.h>

@interface MagicAbilityVC ()
@property (weak, nonatomic) IBOutlet UILabel *powerHeader;
@property (weak, nonatomic) IBOutlet UILabel *abilityHeader;
@property (weak, nonatomic) IBOutlet UILabel *abilityDescription;
@property (weak, nonatomic) IBOutlet UILabel *abilitySubheader;
@property (weak, nonatomic) IBOutlet UILabel *artistHeader;
@property (weak, nonatomic) IBOutlet UIButton *clearAbilityCost;
@property (weak, nonatomic) IBOutlet UILabel *flavorHeader;
@property (weak, nonatomic) IBOutlet UILabel *powerDescription;
@property (strong,nonatomic) AVAudioPlayer *audioPlayer;
@end

NSArray* pt_entries;
BOOL power_good = YES, toughness_good = YES;

@implementation MagicAbilityVC

// Function to perform setup of the view after it loads
- (void)viewDidLoad
{
    // call the superclass's viewDidLoad method
    [super viewDidLoad];
    
    // create the array that holds the power and toughness possibilities
    pt_entries = [[NSArray alloc] initWithObjects:@"*",@"X",@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",nil];
    
    // set default values
    if (self.card.abilityCost == NULL) self.card.abilityCost = @"";
    if (self.card.flavorText == NULL) self.card.flavorText = @"";
    if (self.card.power == NULL) self.card.power = @"";
    if (self.card.toughness == NULL) self.card.toughness = @"";
    
    // set the current text field values if the user has set them previously (we don't want them to lose work)
    self.powerField.text = self.card.power;
    self.toughnessField.text = self.card.toughness;
    self.abilityCost.text = self.card.abilityCost;
    self.abilityField.text = self.card.ability;
    self.flavorTextField.text = self.card.flavorText;
    self.artistNameField.text = self.card.artistName;
    
    // hide the error messages and enable the finish button
    self.ptTextFieldError.hidden = YES;
    self.flavorTextFieldError.hidden = YES;
    self.finishButton.enabled = YES;
    self.artistNameFieldError.hidden = YES;
    
    // put the fonts
    self.abilityHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:23];
    self.abilityDescription.font = [UIFont fontWithName:@"Matrix-Bold" size:13];
    self.clearAbilityCost.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    self.abilityCost.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    self.abilitySubheader.font = [UIFont fontWithName:@"Matrix-Bold" size:13];
    self.abilityField.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    self.powerHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:23];
    self.powerDescription.font = [UIFont fontWithName:@"Matrix-Bold" size:13];
    self.powerField.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    self.toughnessField.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    self.flavorHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:23];
    self.flavorTextField.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    self.artistHeader.font = [UIFont fontWithName:@"Matrix-Bold" size:23];
    self.artistNameField.font = [UIFont fontWithName:@"Matrix-Bold" size:17];
    
    // format the finish button
    self.finishButton.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:18];
    self.finishButton.layer.cornerRadius = 15;
    self.finishButton.clipsToBounds = true;
    self.finishButton.layer.borderWidth = 1.0;
    self.finishButton.layer.borderColor = [[UIColor blackColor] CGColor];
}

// Function that changes the ability cost when a user hits the button
// Input: id, which will always be of type UIButton*
// Output: IBAction
- (IBAction)abilityCost:(id)sender {
    // cast the sender to a button
    UIButton* button = (UIButton*) sender;
    // get the button tag
    int tag = (int) button.tag;
    
    // determine the value of newText depending on button clicked
    NSString* newText;
    // if tag equal to 0, 1, 2, 3, 4, 5, 6, 7, 8 or 9...
    if (tag <= 9)
    {
        // the string will be equal to its number value
        newText = [NSString stringWithFormat:@"/%d",tag];
    }
    // otherwise, the tag will be mapped to another value
    else
    {
        if (tag == 10)
            newText = @"/X";
        else if (tag == 11)
            newText = @"/W";
        else if (tag == 12)
            newText = @"/U";
        else if (tag == 13)
            newText = @"/R";
        else if (tag == 14)
            newText = @"/G";
        else if (tag == 15)
            newText = @"/B";
        else if (tag == 16)
            newText = @"/T";
    }
    
    // set the ability cost label text
    self.abilityCost.text = [NSString stringWithFormat:@"%@%@",self.card.abilityCost,newText];
    // update the card's ability cost
    self.card.abilityCost = self.abilityCost.text;
}

// Function to clear the mana cost when the user hits the button
// Input: id, which will always be UIButton*
// Output: IBAction
- (IBAction)clearManaPressed:(id)sender {
    // set both the ability cost text field to the empty string and the card's ability cost to the empty string
    self.abilityCost.text = @"";
    self.card.abilityCost = @"";
}

// Function that plays a sound when the back button is pressed and then dismisses the view controller
// Input: id, which will always be UIButton*
// Output: IBAction
- (IBAction)backButtonPressed:(id)sender {
    // construct the path to the audio file
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"OOT_Cancel" ofType:@"wav" ];
    // construct the URL to the audio file
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    // declare the error variable
    NSError *error;
    // instantiate the audioPlayer object with the URL and error
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    // play the sound
    [self.audioPlayer play];
    // dismiss the view controller
    [self dismissViewControllerAnimated:YES completion:nil];
}

// Function that sets the ability of the card when the user does so
// Input: id, which will always be of type UITextField*
// Output: IBAction
- (IBAction)abilityEntered:(id)sender {
    // cast the sender to a UITextField object
    UITextField* ability = (UITextField*) sender;
    // set the card's ability to the text on the text field
    self.card.ability = ability.text;
}

// Function to check if the power and/or toughness entry is in the array of allowed values
// Input: NSString*
// Output: BOOL (YES if in, NO if not)
- (BOOL) ptInArray:(NSString*)entry
{
    // return if the array contains the entry
    return [pt_entries containsObject:entry];
}

// Function that sets the power if the user changes the power
// Input: id, which will always be UITextField*
// Output: IBAction
- (IBAction)powerChanged:(id)sender {
    // cast the sender to a UITextField object
    UITextField* power = (UITextField*) sender;
    // if the power value is valid
    if ([self ptInArray:power.text])
    {
        // set the card's power equal to it
        self.card.power = power.text;
        // set power's valid flag
        power_good = YES;
        // if both power and toughness are valid
        if (power_good && toughness_good)
        {
            // hide the error
            self.ptTextFieldError.hidden = YES;
            // enable the finish button
            self.finishButton.enabled = YES;
        }
        // else, both power and toughness are not valid
        else
        {
            // display the error
            self.ptTextFieldError.hidden = NO;
            // disable the finish button
            self.finishButton.enabled = NO;
        }
    }
    // the power value is not valid
    else
    {
        // set the power valid flag to false
        power_good = NO;
        // display the error
        self.ptTextFieldError.hidden = NO;
        // disable the finish button
        self.finishButton.enabled = NO;
    }
    // set the text field to finish editing
    [self textFieldDidEndEditing:_powerField];
    // enable all of the fields
    _abilityField.enabled=YES;
    _toughnessField.enabled=YES;
    _flavorTextField.enabled=YES;
    _artistNameField.enabled=YES;
}

// Function that prompts the screen to be moved up when typing in this field
// Input: id, which is always a UITextField*
// Output: IBAction
- (IBAction)powerBeganEditing:(id)sender {
    // Call the function to handle the text field beginning its edits
    [self textFieldDidBeginEditing:_powerField];
    // disable all of the other fields while the power and toughness fields are being edited
    _abilityField.enabled=NO;
    _toughnessField.enabled=NO;
    _flavorTextField.enabled=NO;
    _artistNameField.enabled=NO;
}

// Function that changes the toughness when the user changes it
// Input: id, which is always a UITextField*
// Output: IBAction
- (IBAction)toughnessChanged:(id)sender {
    // cast the sender to a UITextField object
    UITextField* toughness = (UITextField*) sender;
    // if the toughness value is valid
    if ([self ptInArray:toughness.text])
    {
        // set the card's toughness
        self.card.toughness = toughness.text;
        // set the toughness valid flag
        toughness_good = YES;
        // if both power and toughness are valid
        if (power_good && toughness_good)
        {
            // hide the error
            self.ptTextFieldError.hidden = YES;
            // enable the finish button
            self.finishButton.enabled = YES;
        }
        // both power and toughness are not valid
        else
        {
            // show the error
            self.ptTextFieldError.hidden = NO;
            // disable the finish button
            self.finishButton.enabled = NO;
        }
    }
    // the toughness value is not valid
    else
    {
        // toughness not valid
        toughness_good = NO;
        // display the error
        self.ptTextFieldError.hidden = NO;
        // disable the finish button
        self.finishButton.enabled = NO;
    }
    // call the function to say the toughness field began editing
    [self textFieldDidEndEditing:_toughnessField];
    // enable all of the other fields
    _abilityField.enabled=YES;
    _powerField.enabled=YES;
    _flavorTextField.enabled=YES;
    _artistNameField.enabled=YES;
}

// Function to prompt that the toughness field began editing
// Input: sender, which is always UITextField*
// Output: IBAction
- (IBAction)toughnessBegan:(id)sender {
    // call the text field did begin editing method for the toughness field
    [self textFieldDidBeginEditing:_toughnessField];
    // disable all of the other fields
    _abilityField.enabled=NO;
    _powerField.enabled=NO;
    _flavorTextField.enabled=NO;
    _artistNameField.enabled=NO;
}

// Function to set the flavor text when the user changes it
// Input: id, which is always of type UITextField*
// Output: IBAction
- (IBAction)flavorTextChanged:(id)sender {
    // cast the sender to a UITextField object
    UITextField* cardName = (UITextField*) sender;
    // set the limit on the flavor text field...
    if (cardName.text.length > 96)
    {
        // show the error
        self.flavorTextFieldError.hidden = NO;
        // disable the finish button
        self.finishButton.enabled = NO;
    }
    // if the limit was not reached...
    else
    {
        // hide the error
        self.flavorTextFieldError.hidden = YES;
        // enable the finish button
        self.finishButton.enabled = YES;
        // set the card's flavor text
        self.card.flavorText = cardName.text;
    }
    // call the end editing function for this text field
    [self textFieldDidEndEditing:_flavorTextField];
    // enable all of the other fields
    _abilityField.enabled=YES;
    _powerField.enabled=YES;
    _toughnessField.enabled=YES;
    _artistNameField.enabled=YES;
}

// Function to signify the flavor text field began editing
// Input: id, which is always of type UITextField*
// Output: IBAction
- (IBAction)flavorTextBegan:(id)sender {
    // call the did begin editing method
    [self textFieldDidBeginEditing:_flavorTextField];
    // disable all of the other fields
    _abilityField.enabled=NO;
    _powerField.enabled=NO;
    _toughnessField.enabled=NO;
    _artistNameField.enabled=NO;
}

// Function to set the artist name when the user changes it
// Input: id, which is always a UITextField*
// Output: IBAction
- (IBAction)artistTextChanged:(id)sender {
    // cast the sender to a UITextField object
    UITextField* cardName = (UITextField*) sender;
    // if the artist text is over 40 characters
    if (cardName.text.length > 40)
    {
        // show the error
        self.artistNameFieldError.hidden = NO;
        // disable the finish button
        self.finishButton.enabled = NO;
    }
    // length is fine
    else
    {
        // hide the error
        self.artistNameFieldError.hidden = YES;
        // enable the finish button
        self.finishButton.enabled = YES;
        // set the card's artist name to the text field text
        self.card.artistName = cardName.text;
    }
    // call the did end editing function
    [self textFieldDidEndEditing:_artistNameField];
    // enable all of the other fields
    _abilityField.enabled=YES;
    _powerField.enabled=YES;
    _toughnessField.enabled=YES;
    _flavorTextField.enabled=YES;
}

// Function that calls the begin editing method for the artist text
// Input: id, which is always of type UITextField*
// Output: IBAction
- (IBAction)artistTextBegan:(id)sender {
    // call the did begin edting function for the artist name field
    [self textFieldDidBeginEditing:_artistNameField];
    // disable all of the other fields
    _abilityField.enabled=NO;
    _powerField.enabled=NO;
    _toughnessField.enabled=NO;
    _flavorTextField.enabled=NO;
}

// Function to do some setup before the segue
// Input: id, which is always UIButton*
// Output: void
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // get the destination view controller
    MagicExporterVC* dest = [segue destinationViewController];
    // set the destination's card equal to the current view controller's card
    dest.card = self.card;
}

// Function that moves the view up when the text field begins editing
// Input: UITextField*
// Output: void
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    // move the text field up
    [self animateTextField:textField up:YES];
}

// Function that moves the view down when the text field ends editing
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    // move the text field down
    [self animateTextField:textField up:NO];
}

// Function to animate the text field
// Input: UITextField*, BOOL
// Output: void
-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    // movement distance
    const int movementDistance = -200;
    // movement duration
    const float movementDuration = 0.3f;
    
    // move the view up the movement distance if up, otherwise move the other way for down
    int movement = (up ? movementDistance : -movementDistance);
    // begin the animation
    [UIView beginAnimations: @"animateTextField" context: nil];
    // animation begins from current state
    [UIView setAnimationBeginsFromCurrentState: YES];
    // set the animation duration
    [UIView setAnimationDuration: movementDuration];
    // set the view frame
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    // commit the animation
    [UIView commitAnimations];
}

// Function to play a sound when the finish button is pressed
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)finishPressed:(id)sender {
    // construct the audio path to the audio file
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"OOT_MainMenu_Select" ofType:@"wav" ];
    // construct the URL to the audio file
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    // declare the error object
    NSError *error;
    // instantiate the audioPlayer object with the URL and the error
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    // play the sound
    [self.audioPlayer play];
}

@end
