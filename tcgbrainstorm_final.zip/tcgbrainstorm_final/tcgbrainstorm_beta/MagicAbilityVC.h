//
//  MagicAbilityVC.h
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/5/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomMagicCard.h"
#import "MagicExporterVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface MagicAbilityVC : UIViewController
@property (strong, nonatomic) CustomMagicCard* card;
@property (weak, nonatomic) IBOutlet UITextField *powerField;
@property (weak, nonatomic) IBOutlet UITextField *toughnessField;
@property (weak, nonatomic) IBOutlet UILabel *abilityCost;
@property (weak, nonatomic) IBOutlet UITextField *abilityField;
@property (weak, nonatomic) IBOutlet UITextField *flavorTextField;
@property (weak, nonatomic) IBOutlet UITextField *artistNameField;
@property (weak, nonatomic) IBOutlet UILabel *ptTextFieldError;
@property (weak, nonatomic) IBOutlet UILabel *flavorTextFieldError;
@property (weak, nonatomic) IBOutlet UILabel *artistNameFieldError;
@property (weak, nonatomic) IBOutlet UIButton *finishButton;
- (BOOL) ptInArray:(NSString*)entry;
@end

NS_ASSUME_NONNULL_END
