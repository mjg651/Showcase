//
//  PokeDamageCounter.m
//  tcgbrainstorm_beta
//
//  Created by Matt Guarneri on 4/15/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "PokeDamageCounter.h"

@interface PokeDamageCounter ()

@property (weak, nonatomic) IBOutlet UISegmentedControl *benchP1;
//arrays used to hold the 12 pokemon total; 6 for each player
@property NSMutableArray *Healthp1;
@property NSMutableArray *Healthp2;
//players vies
@property (weak, nonatomic) IBOutlet UIView *redView;
@property (weak, nonatomic) IBOutlet UILabel *hpLabelP1;
@property (weak, nonatomic) IBOutlet UILabel *hpLabelP2;
@property (weak, nonatomic) IBOutlet UILabel *benchHpLabelP1;
//special condition buttons--> click to indicate if special cond active or not
@property (weak, nonatomic) IBOutlet UIButton *burn1;
@property (weak, nonatomic) IBOutlet UIButton *slp1;
@property (weak, nonatomic) IBOutlet UIButton *cnf1;
@property (weak, nonatomic) IBOutlet UIButton *par1;
@property (weak, nonatomic) IBOutlet UIButton *psn1;
@property (weak, nonatomic) IBOutlet UIButton *burn2;
@property (weak, nonatomic) IBOutlet UIButton *psn2;
@property (weak, nonatomic) IBOutlet UIButton *slp2;
@property (weak, nonatomic) IBOutlet UIButton *cnf2;
@property (weak, nonatomic) IBOutlet UIButton *par2;
@property (weak, nonatomic) IBOutlet UISegmentedControl *benchP2;
@property (weak, nonatomic) IBOutlet UILabel *benchHpLabelP2;
//players view
@property (weak, nonatomic) IBOutlet UIView *whiteView;
//our logo;ends game
@property (weak, nonatomic) IBOutlet UIButton *endGameButton;

@end

@implementation PokeDamageCounter

- (BOOL)prefersStatusBarHidden {return YES;}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    
    //round laayers; looks like a pokeball :)
    _redView.layer.cornerRadius= 10;
    _whiteView.layer.cornerRadius=10;
    
    //set opacity to .5 to indicat enot chosen
    _burn1.alpha=0.5;
    _slp1.alpha=.5;
    _cnf1.alpha=.5;
    _par1.alpha=.5;
    _psn1.alpha=.5;
    
    _burn2.alpha=0.5;
    _slp2.alpha=.5;
    _cnf2.alpha=.5;
    _par2.alpha=.5;
    _psn2.alpha=.5;
    
    
    _endGameButton.layer.cornerRadius=15;
     _endGameButton.clipsToBounds = true;
    
    //instantiate arrays to 0 to indicae hp type
    NSMutableArray *P1Health = [NSMutableArray array];
    [P1Health addObject:[NSNumber numberWithInteger:0]];
    [P1Health addObject:[NSNumber numberWithInteger:0]];
    [P1Health addObject:[NSNumber numberWithInteger:0]];
    [P1Health addObject:[NSNumber numberWithInteger:0]];
    [P1Health addObject:[NSNumber numberWithInteger:0]];
    [P1Health addObject:[NSNumber numberWithInteger:0]];
    _Healthp1=P1Health;
    
    NSMutableArray *P2Health = [NSMutableArray array];
    [P2Health addObject:[NSNumber numberWithInteger:0]];
    [P2Health addObject:[NSNumber numberWithInteger:0]];
    [P2Health addObject:[NSNumber numberWithInteger:0]];
    [P2Health addObject:[NSNumber numberWithInteger:0]];
    [P2Health addObject:[NSNumber numberWithInteger:0]];
    [P2Health addObject:[NSNumber numberWithInteger:0]];
    _Healthp2=P2Health;
    
    //flips player view upside down
    _redView.transform=CGAffineTransformMakeRotation(M_PI);
   
    //set active and bench pokemon
    _hpLabelP1.text= [NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:0]];
    _benchHpLabelP1.text = [NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:1]];
    
    _hpLabelP2.text= [NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:0]];
    _benchHpLabelP2.text = [NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:1]];
}

//Bench segment change; display pokemon hp tat selected indext
- (IBAction)benchP1changed:(id)sender {
    if (_benchP1.selectedSegmentIndex==0){
        _benchHpLabelP1.text=[NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:1]];
    }else if (_benchP1.selectedSegmentIndex==1){
        _benchHpLabelP1.text=[NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:2]];
    } else if (_benchP1.selectedSegmentIndex==2){
        _benchHpLabelP1.text=[NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:3]];
    }else if (_benchP1.selectedSegmentIndex==3){
        _benchHpLabelP1.text=[NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:4]];
    }else if (_benchP1.selectedSegmentIndex==4){
        _benchHpLabelP1.text=[NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:5]];
    }
}

- (IBAction)benchP2changed:(id)sender {
    if (_benchP2.selectedSegmentIndex==0){
        _benchHpLabelP2.text=[NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:1]];
    }else if (_benchP2.selectedSegmentIndex==1){
        _benchHpLabelP2.text=[NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:2]];
    } else if (_benchP2.selectedSegmentIndex==2){
        _benchHpLabelP2.text=[NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:3]];
    }else if (_benchP2.selectedSegmentIndex==3){
        _benchHpLabelP2.text=[NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:4]];
    }else if (_benchP2.selectedSegmentIndex==4){
        _benchHpLabelP2.text=[NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:5]];
    }
}

//swap the active pokemon with the selected bench pokemon and reset opacity
- (IBAction)p1SwapPressed:(id)sender {
    [_Healthp1 exchangeObjectAtIndex:0 withObjectAtIndex:_benchP1.selectedSegmentIndex+1];
    _hpLabelP1.text= [NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:0]];
    _benchHpLabelP1.text=[NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:_benchP1.selectedSegmentIndex+1]];
    _burn1.alpha=.5;
    _psn1.alpha=.5;
    _slp1.alpha=.5;
    _cnf1.alpha=.5;
    _par1.alpha=.5;
}

- (IBAction)p2SwapPressed:(id)sender {
    [_Healthp2 exchangeObjectAtIndex:0 withObjectAtIndex:_benchP2.selectedSegmentIndex+1];
    _hpLabelP2.text= [NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:0]];
    _benchHpLabelP2.text=[NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:_benchP2.selectedSegmentIndex+1]];
    _burn2.alpha=.5;
    _psn2.alpha=.5;
    _slp2.alpha=.5;
    _cnf2.alpha=.5;
    _par2.alpha=.5;
}

//Discard your active pokemon and reset special conditions
- (IBAction)discardActiveP1:(id)sender {
    [_Healthp1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithInteger:0]];
    _hpLabelP1.text= [NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:0]];
    _burn1.alpha=0.5;
    _slp1.alpha=.5;
    _cnf1.alpha=.5;
    _par1.alpha=.5;
    _psn1.alpha=.5;
}

- (IBAction)discardActiveP2:(id)sender {
    [_Healthp2 replaceObjectAtIndex:0 withObject:[NSNumber numberWithInteger:0]];
    _hpLabelP2.text= [NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:0]];
    _burn2.alpha=0.5;
    _slp2.alpha=.5;
    _cnf2.alpha=.5;
    _par2.alpha=.5;
    _psn2.alpha=.5;
}

//discard bench pokemon by setting selected segment index of bench to 0
- (IBAction)discardBenchP1:(id)sender {
    [_Healthp1 replaceObjectAtIndex:_benchP1.selectedSegmentIndex+1 withObject:[NSNumber numberWithInteger:0]];
    _benchHpLabelP1.text= [NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:_benchP1.selectedSegmentIndex+1]];
}
- (IBAction)discardBenchP2:(id)sender {
    [_Healthp2 replaceObjectAtIndex:_benchP2.selectedSegmentIndex+1 withObject:[NSNumber numberWithInteger:0]];
    _benchHpLabelP2.text= [NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:_benchP2.selectedSegmentIndex+1]];
}

//These functions indiate the special conditons. When button is pressed opacity is reversed
- (IBAction)burnP1pressed:(id)sender {
    if(_burn1.alpha==0.5){
        _burn1.alpha=1.0;
    }else{
        _burn1.alpha=0.5;
    }
}

- (IBAction)burnP2pressed:(id)sender {
    if(_burn2.alpha==0.5){
        _burn2.alpha=1.0;
    }else{
        _burn2.alpha=0.5;
    }
}

- (IBAction)psnP1pressed:(id)sender {
    if(_psn1.alpha==0.5){
        _psn1.alpha=1.0;
    }else{
        _psn1.alpha=0.5;
    }
}
- (IBAction)psnP2pressed:(id)sender {
    if(_psn2.alpha==0.5){
        _psn2.alpha=1.0;
    }else{
        _psn2.alpha=0.5;
    }
}

- (IBAction)slpP1pressed:(id)sender {
    if(_slp1.alpha==0.5){
        _slp1.alpha=1.0;
    }else{
        _slp1.alpha=0.5;
    }
}

- (IBAction)slpP2pressed:(id)sender {
    if(_slp2.alpha==0.5){
        _slp2.alpha=1.0;
    }else{
        _slp2.alpha=0.5;
    }
}

- (IBAction)cnfP1pressed:(id)sender {
    if(_cnf1.alpha==0.5){
        _cnf1.alpha=1.0;
    }else{
        _cnf1.alpha=0.5;
    }
}

- (IBAction)cnfP2pressed:(id)sender {
    if(_cnf2.alpha==0.5){
        _cnf2.alpha=1.0;
    }else{
        _cnf2.alpha=0.5;
    }
}

- (IBAction)parP1pressed:(id)sender {
    if(_par1.alpha==0.5){
        _par1.alpha=1.0;
    }else{
        _par1.alpha=0.5;
    }
}

- (IBAction)parP2pressed:(id)sender {
    if(_par2.alpha==0.5){
        _par2.alpha=1.0;
    }else{
        _par2.alpha=0.5;
    }
}


//Plus  functions are used to set the pokemons health; the active pokemon can be incremented by 10 50 or 100
- (IBAction)plus10P1:(id)sender {
    int plus10=[[_Healthp1 objectAtIndex:0]intValue]+10;
    [_Healthp1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithInteger:plus10]];
    _hpLabelP1.text= [NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:0]];
}

- (IBAction)plus10P2:(id)sender {
    int plus10=[[_Healthp2 objectAtIndex:0]intValue]+10;
    [_Healthp2 replaceObjectAtIndex:0 withObject:[NSNumber numberWithInteger:plus10]];
    _hpLabelP2.text= [NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:0]];
}

- (IBAction)plus50P1:(id)sender {
    int plus50=[[_Healthp1 objectAtIndex:0]intValue]+50;
    [_Healthp1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithInteger:plus50]];
    _hpLabelP1.text= [NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:0]];
}

- (IBAction)plus50P2:(id)sender {
    int plus50=[[_Healthp2 objectAtIndex:0]intValue]+50;
    [_Healthp2 replaceObjectAtIndex:0 withObject:[NSNumber numberWithInteger:plus50]];
    _hpLabelP2.text= [NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:0]];
}

- (IBAction)plus100P1:(id)sender {
    int plus100=[[_Healthp1 objectAtIndex:0]intValue]+100;
    [_Healthp1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithInteger:plus100]];
    _hpLabelP1.text= [NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:0]];
}

- (IBAction)plus100P2:(id)sender {
    int plus100=[[_Healthp2 objectAtIndex:0]intValue]+100;
    [_Healthp2 replaceObjectAtIndex:0 withObject:[NSNumber numberWithInteger:plus100]];
    _hpLabelP2.text= [NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:0]];
}

//Use the minus buttons to keep track of damage--> used in lieu of damage tokens in game
- (IBAction)minus10P1:(id)sender {
    int plus10=[[_Healthp1 objectAtIndex:0]intValue]-10;
    [_Healthp1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithInteger:plus10]];
    _hpLabelP1.text= [NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:0]];
}

- (IBAction)minus10P2:(id)sender {
    int plus10=[[_Healthp2 objectAtIndex:0]intValue]-10;
    [_Healthp2 replaceObjectAtIndex:0 withObject:[NSNumber numberWithInteger:plus10]];
    _hpLabelP2.text= [NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:0]];
}

- (IBAction)minus50p1:(id)sender {
    int plus50=[[_Healthp1 objectAtIndex:0]intValue]-50;
    [_Healthp1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithInteger:plus50]];
    _hpLabelP1.text= [NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:0]];
}

- (IBAction)minus50P2:(id)sender {
    int plus50=[[_Healthp2 objectAtIndex:0]intValue]-50;
    [_Healthp2 replaceObjectAtIndex:0 withObject:[NSNumber numberWithInteger:plus50]];
    _hpLabelP2.text= [NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:0]];
}

- (IBAction)minus100p1:(id)sender {
    int plus50=[[_Healthp1 objectAtIndex:0]intValue]-100;
    [_Healthp1 replaceObjectAtIndex:0 withObject:[NSNumber numberWithInteger:plus50]];
    _hpLabelP1.text= [NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:0]];
}

- (IBAction)minus100p2:(id)sender {
    int plus50=[[_Healthp2 objectAtIndex:0]intValue]-100;
    [_Healthp2 replaceObjectAtIndex:0 withObject:[NSNumber numberWithInteger:plus50]];
    _hpLabelP2.text= [NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:0]];
}
//can also decrement bench pokemon by 10...
- (IBAction)minusBenchp1:(id)sender {
    int plus10=[[_Healthp1 objectAtIndex:_benchP1.selectedSegmentIndex+1]intValue]-10;
    [_Healthp1 replaceObjectAtIndex:_benchP1.selectedSegmentIndex+1 withObject:[NSNumber numberWithInteger:plus10]];
    _benchHpLabelP1.text= [NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:_benchP1.selectedSegmentIndex+1]];
}

- (IBAction)minusBenchp2:(id)sender {
    int plus10=[[_Healthp2 objectAtIndex:_benchP2.selectedSegmentIndex+1]intValue]-10;
    [_Healthp2 replaceObjectAtIndex:_benchP2.selectedSegmentIndex+1 withObject:[NSNumber numberWithInteger:plus10]];
    _benchHpLabelP2.text= [NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:_benchP2.selectedSegmentIndex+1]];
}
//... and increment benched mons by 10
- (IBAction)plusBenchp1:(id)sender {
    int plus10=[[_Healthp1 objectAtIndex:_benchP1.selectedSegmentIndex+1]intValue]+10;
    [_Healthp1 replaceObjectAtIndex:_benchP1.selectedSegmentIndex+1 withObject:[NSNumber numberWithInteger:plus10]];
    _benchHpLabelP1.text= [NSString stringWithFormat:@"%@",[_Healthp1 objectAtIndex:_benchP1.selectedSegmentIndex+1]];
}

- (IBAction)plusBenchp2:(id)sender {
    int plus10=[[_Healthp2 objectAtIndex:_benchP2.selectedSegmentIndex+1]intValue]+10;
    [_Healthp2 replaceObjectAtIndex:_benchP2.selectedSegmentIndex+1 withObject:[NSNumber numberWithInteger:plus10]];
    _benchHpLabelP2.text= [NSString stringWithFormat:@"%@",[_Healthp2 objectAtIndex:_benchP2.selectedSegmentIndex+1]];
}

//Calls a UIALertController to end the game when the logo is pressed; can be canceled
-(IBAction)finishGame:(id)sender {
    UIAlertController * alert = [UIAlertController
                                 alertControllerWithTitle:@"Main Menu"
                                 message:@"Select from the options below"
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* endGameButton = [UIAlertAction
                                    actionWithTitle:@"End Game"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {
                                        [self dismissViewControllerAnimated:YES completion:nil];
                                    }];
    
    
    UIAlertAction* cancelButton = [UIAlertAction
                                   actionWithTitle:@"Cancel"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction * action) {
                                       //Handle no, thanks button
                                   }];
    
    [alert addAction:endGameButton];

    [alert addAction:cancelButton];
    
    [self presentViewController:alert animated:YES completion:nil];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
