//
//  MTGLifeCounterVC.m
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/12/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "MTGLifeCounterVC.h"
#import <MessageUI/MessageUI.h>
#import "FLAnimatedImage.h"
#include <stdlib.h>

@interface MTGLifeCounterVC ()
// life total variables
@property (strong, nonatomic) UILabel* life1;
@property (strong, nonatomic) UILabel* life2;
@property (strong, nonatomic) UILabel* life3;
@property (strong, nonatomic) UILabel* life4;

// poison counter variables
@property (strong, nonatomic) UILabel* poison1;
@property (strong, nonatomic) UILabel* poison2;
@property (strong, nonatomic) UILabel* poison3;
@property (strong, nonatomic) UILabel* poison4;

// commander damage variables
@property (strong, nonatomic) UILabel* commander1;
@property (strong, nonatomic) UILabel* commander2;
@property (strong, nonatomic) UILabel* commander3;
@property (strong, nonatomic) UILabel* commander4;

// player 1 buttons
@property (weak, nonatomic) IBOutlet UIButton *lifePlus1;
@property (weak, nonatomic) IBOutlet UIButton *poisonPlus1;
@property (weak, nonatomic) IBOutlet UIButton *commanderPlus1;
@property (weak, nonatomic) IBOutlet UIButton *lifeMinus1;
@property (weak, nonatomic) IBOutlet UIButton *poisonMinus1;
@property (weak, nonatomic) IBOutlet UIButton *commanderMinus1;

// player 2 buttons
@property (weak, nonatomic) IBOutlet UIButton *lifePlus2;
@property (weak, nonatomic) IBOutlet UIButton *poisonPlus2;
@property (weak, nonatomic) IBOutlet UIButton *commanderPlus2;
@property (weak, nonatomic) IBOutlet UIButton *lifeMinus2;
@property (weak, nonatomic) IBOutlet UIButton *poisonMinus2;
@property (weak, nonatomic) IBOutlet UIButton *commanderMinus2;

// player 3 buttons
@property (weak, nonatomic) IBOutlet UIButton *lifePlus3;
@property (weak, nonatomic) IBOutlet UIButton *poisonPlus3;
@property (weak, nonatomic) IBOutlet UIButton *commanderPlus3;
@property (weak, nonatomic) IBOutlet UIButton *lifeMinus3;
@property (weak, nonatomic) IBOutlet UIButton *poisonMinus3;
@property (weak, nonatomic) IBOutlet UIButton *commanderMinus3;

// player 4 buttons
@property (weak, nonatomic) IBOutlet UIButton *lifePlus4;
@property (weak, nonatomic) IBOutlet UIButton *poisonPlus4;
@property (weak, nonatomic) IBOutlet UIButton *commanderPlus4;
@property (weak, nonatomic) IBOutlet UIButton *lifeMinus4;
@property (weak, nonatomic) IBOutlet UIButton *poisonMinus4;
@property (weak, nonatomic) IBOutlet UIButton *commanderMinus4;
@property (weak, nonatomic) IBOutlet UIButton *finishGame;

// private reset player methods
-(void) resetPlayer1;
-(void) resetPlayer2;
-(void) resetPlayer3;
-(void) resetPlayer4;

// private show player methods
-(void) showPlayer1;
-(void) showPlayer2;
-(void) showPlayer3;
-(void) showPlayer4;

// private hide player methods
-(void) hidePlayer1;
-(void) hidePlayer2;
-(void) hidePlayer3;
-(void) hidePlayer4;
@end

@implementation MTGLifeCounterVC

// Function to hide the status bar
// Input: void
// Output: BOOL
- (BOOL)prefersStatusBarHidden
{
    // hide the status bar
    return YES;
}
// Function to reset player 1
// Input: void
// Output: void
-(void) resetPlayer1
{
    // set the life text equal to life total
    self.life1.text = [NSString stringWithFormat:@"%d",self.life];
    // set poison counters to 0
    self.poison1.text = @"0";
    // set commander damage to 0
    self.commander1.text = @"0";
    
    // if any labels were red due to lethal damage, change back to white
    self.life1.textColor = [UIColor whiteColor];
    self.poison1.textColor = [UIColor whiteColor];
    self.commander1.textColor = [UIColor whiteColor];
}

// Function to reset player 2
// Input: void
// Output: void
-(void) resetPlayer2
{
    // call player 1's reset method
    [self resetPlayer1];
    // set life total back
    self.life2.text = [NSString stringWithFormat:@"%d",self.life];
    // set poison counter to 0
    self.poison2.text = @"0";
    // set commander damage to 0
    self.commander2.text = @"0";
    
    // if any labels were red due to lethal damage, change back to white
    self.life2.textColor = [UIColor whiteColor];
    self.poison2.textColor = [UIColor whiteColor];
    self.commander2.textColor = [UIColor whiteColor];
}

// Function to reset player 3
// Input: void
// Output: void
-(void) resetPlayer3
{
    // call player 1's reset method
    [self resetPlayer2];
    // set life total back
    self.life3.text = [NSString stringWithFormat:@"%d",self.life];
    // set poison counters to 0
    self.poison3.text = @"0";
    // set commander damage to 0
    self.commander3.text = @"0";
    
    // if any labels were red due to lethal damage, change back to white
    self.life3.textColor = [UIColor whiteColor];
    self.poison3.textColor = [UIColor whiteColor];
    self.commander4.textColor = [UIColor whiteColor];
}

// Function to reset player 4
// Input: void
// Output: void
-(void) resetPlayer4
{
    // call player 3's reset method
    [self resetPlayer3];
    // reset life total
    self.life4.text = [NSString stringWithFormat:@"%d",self.life];
    // set poison counters to 0
    self.poison4.text = @"0";
    // set commander damage to 0
    self.commander4.text = @"0";
    
    // if any labels were red due to lethal damage, change back to white
    self.life4.textColor = [UIColor whiteColor];
    self.poison4.textColor = [UIColor whiteColor];
    self.commander4.textColor = [UIColor whiteColor];
}

// Master reset method that calls individual, private methods
// Input: void
// Output: void
-(void) resetGame
{
    // if 1 player, call player 1 reset method
    if (self.players == 1)
        [self resetPlayer1];
    // if 2 players, call player 2 reset method
    else if (self.players == 2)
        [self resetPlayer2];
    // if 3 players, call player 3 reset method
    else if (self.players == 3)
        [self resetPlayer3];
    // if 4 players, call player 4 reset method
    else
        [self resetPlayer4];
}

// Do additional setup after loading the view
- (void)viewDidLoad
{
    // call superclass viewDidLoad method
    [super viewDidLoad];
    
    // get the phone width and phone height of the device we're using
    CGFloat phoneWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat phoneHeight = [UIScreen mainScreen].bounds.size.height;
    
    // set the default background color to be black
    self.view.backgroundColor = [UIColor blackColor];
    
    // hide the finish game button for now, as it will be placed depending on the layout based on number of players
    self.finishGame.hidden = YES;
    
    // if only one player
    if (self.players == 1)
    {
        // hide player 2 buttons
        self.lifePlus2.hidden = YES;
        self.poisonPlus2.hidden = YES;
        self.commanderPlus2.hidden = YES;
        self.lifeMinus2.hidden = YES;
        self.poisonMinus2.hidden = YES;
        self.commanderMinus2.hidden = YES;
        
        // hide player 3 buttons
        self.lifePlus3.hidden = YES;
        self.poisonPlus3.hidden = YES;
        self.commanderPlus3.hidden = YES;
        self.lifeMinus3.hidden = YES;
        self.poisonMinus3.hidden = YES;
        self.commanderMinus3.hidden = YES;
        
        // hide player 4 buttons
        self.lifePlus4.hidden = YES;
        self.poisonPlus4.hidden = YES;
        self.commanderPlus4.hidden = YES;
        self.lifeMinus4.hidden = YES;
        self.poisonMinus4.hidden = YES;
        self.commanderMinus4.hidden = YES;
        
        // set the background color
        self.view.backgroundColor = [UIColor cyanColor];
        
        // set and format the life label for player 1
        self.life1 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/2-110, phoneHeight/2-115, 225, 225)];
        self.life1.text = [NSString stringWithFormat:@"%d",self.life];
        self.life1.textAlignment = NSTextAlignmentCenter;
        self.life1.textColor = [UIColor whiteColor];
        self.life1.font = [UIFont fontWithName:@"Matrix-Bold" size:150];
        self.life1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [self.view addSubview:self.life1];
        
        // set and format the life image to signify it is the life total
        UIImage* lifeImage = [UIImage imageNamed:@"life_counter.png"];
        UIImageView* lifeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(phoneWidth/2+65, phoneHeight/2-20, 35, 35)];
        lifeImageView.image = lifeImage;
        lifeImageView.transform = CGAffineTransformMakeRotation(M_PI_2);
        [self.view addSubview:lifeImageView];
        
        // set and format the poison counter label for player 1
        self.poison1 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/2-110, phoneHeight/2-290, 225, 225)];
        self.poison1.text = @"0";
        self.poison1.textAlignment = NSTextAlignmentCenter;
        self.poison1.textColor = [UIColor whiteColor];
        self.poison1.font = [UIFont fontWithName:@"Matrix-Bold" size:150];
        self.poison1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [self.view addSubview:self.poison1];
        
        // set and format the poison counter image to signify it is the poison counter total
        UIImage* poisonImage = [UIImage imageNamed:@"poison_counter.png"];
        UIImageView* poisonImageView = [[UIImageView alloc] initWithFrame:CGRectMake(phoneWidth/2+65, phoneHeight/2-223, 35, 35)];
        poisonImageView.image = poisonImage;
        poisonImageView.transform = CGAffineTransformMakeRotation(M_PI_2);
        [self.view addSubview:poisonImageView];
        
        // set and format the commander damage label for player 1
        self.commander1 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/2-110, phoneHeight/2+85, 225, 225)];
        self.commander1.text = @"0";
        self.commander1.textAlignment = NSTextAlignmentCenter;
        self.commander1.textColor = [UIColor whiteColor];
        self.commander1.font = [UIFont fontWithName:@"Matrix-Bold" size:150];
        self.commander1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [self.view addSubview:self.commander1];
        
        // set and format the commander damage image to signify it is the commander damage total
        UIImage* commanderImage = [UIImage imageNamed:@"skull_counter.png"];
        UIImageView* commanderImageView = [[UIImageView alloc] initWithFrame:CGRectMake(phoneWidth/2+65, phoneHeight/2+175, 35, 35)];
        commanderImageView.image = commanderImage;
        commanderImageView.transform = CGAffineTransformMakeRotation(M_PI_2);
        [self.view addSubview:commanderImageView];
        
        // set and format the plus button
        CGRect poisonPlus1Frame = self.poisonPlus1.frame;
        poisonPlus1Frame.origin.x = phoneWidth/2-145;
        poisonPlus1Frame.origin.y = phoneHeight/2-175;
        self.poisonPlus1.frame = poisonPlus1Frame;
        self.poisonPlus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        
        CGRect poisonMinus1Frame = self.poisonMinus1.frame;
        poisonMinus1Frame.origin.x = phoneWidth/2-145;
        poisonMinus1Frame.origin.y = phoneHeight/2-245;
        self.poisonMinus1.frame = poisonMinus1Frame;
        self.poisonMinus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        
        CGRect lifePlus1Frame = self.lifePlus1.frame;
        lifePlus1Frame.origin.x = phoneWidth/2-145;
        lifePlus1Frame.origin.y = phoneHeight/2+5;
        self.lifePlus1.frame = lifePlus1Frame;
        self.lifePlus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        
        CGRect lifeMinus1Frame = self.lifeMinus1.frame;
        lifeMinus1Frame.origin.x = phoneWidth/2-145;
        lifeMinus1Frame.origin.y = phoneHeight/2-65;
        self.lifeMinus1.frame = lifeMinus1Frame;
        self.lifeMinus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        
        CGRect commanderPlus1Frame = self.commanderPlus1.frame;
        commanderPlus1Frame.origin.x = phoneWidth/2-145;
        commanderPlus1Frame.origin.y = phoneHeight/2+210;
        self.commanderPlus1.frame = commanderPlus1Frame;
        self.commanderPlus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        
        CGRect commanderMinus1Frame = self.commanderMinus1.frame;
        commanderMinus1Frame.origin.x = phoneWidth/2-145;
        commanderMinus1Frame.origin.y = phoneHeight/2+140;
        self.commanderMinus1.frame = commanderMinus1Frame;
        self.commanderMinus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        
        // format the finish game button
        self.finishGame.hidden = NO;
        self.finishGame.layer.cornerRadius = 15;
        self.finishGame.clipsToBounds = true;
        CGRect finishGameFrame = self.finishGame.frame;
        finishGameFrame.origin.x = phoneWidth-65;
        finishGameFrame.origin.y = 0;
        finishGameFrame.size = CGSizeMake(60,60);
        self.finishGame.frame = finishGameFrame;
        self.finishGame.transform = CGAffineTransformMakeRotation(M_PI_2);
        [self.view addSubview:self.finishGame];
        
        // make the view rounded and have a border
        self.view.layer.cornerRadius = 15;
        self.view.clipsToBounds = true;
        self.view.layer.borderWidth = 5.0;
        self.view.layer.borderColor = [[UIColor blackColor] CGColor];
    
    }

    // if two players
    else if (self.players == 2)
    {
        // hide the player 3 buttons
        self.lifePlus3.hidden = YES;
        self.poisonPlus3.hidden = YES;
        self.commanderPlus3.hidden = YES;
        self.lifeMinus3.hidden = YES;
        self.poisonMinus3.hidden = YES;
        self.commanderMinus3.hidden = YES;
        
        // hide the player 4 buttons
        self.lifePlus4.hidden = YES;
        self.poisonPlus4.hidden = YES;
        self.commanderPlus4.hidden = YES;
        self.lifeMinus4.hidden = YES;
        self.poisonMinus4.hidden = YES;
        self.commanderMinus4.hidden = YES;
        
        // player 1 view
        UIView* player1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, phoneWidth, phoneHeight/2)];
        player1.backgroundColor = [UIColor cyanColor];
        
        // player 1 life label
        self.life1 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/2-115, phoneHeight/4-105, 225, 225)];
        self.life1.text = [NSString stringWithFormat:@"%d",self.life];
        self.life1.textAlignment = NSTextAlignmentCenter;
        self.life1.textColor = [UIColor whiteColor];
        self.life1.font = [UIFont fontWithName:@"Matrix-Bold" size:75];
        self.life1.transform = CGAffineTransformMakeRotation(M_PI_2*2);
        [player1 addSubview:self.life1];
        
        // player 1 life image
        UIImage* lifeImage = [UIImage imageNamed:@"life_counter.png"];
        UIImageView* lifeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(phoneWidth/2-20, phoneHeight/4+43, 40, 40)];
        lifeImageView.image = lifeImage;
        lifeImageView.transform = CGAffineTransformMakeRotation(M_PI_2*2);
        [player1 addSubview:lifeImageView];
        
        // player 1 poison label
        self.poison1 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/2, phoneHeight/4-105, 225, 225)];
        self.poison1.text = @"0";
        self.poison1.textAlignment = NSTextAlignmentCenter;
        self.poison1.textColor = [UIColor whiteColor];
        self.poison1.font = [UIFont fontWithName:@"Matrix-Bold" size:75];
        self.poison1.transform = CGAffineTransformMakeRotation(M_PI_2*2);
        [player1 addSubview:self.poison1];
        
        // player 1 poison image
        UIImage* poisonImage = [UIImage imageNamed:@"poison_counter.png"];
        UIImageView* poisonImageView = [[UIImageView alloc] initWithFrame:CGRectMake(phoneWidth/2+95, phoneHeight/4+43, 35, 35)];
        poisonImageView.image = poisonImage;
        poisonImageView.transform = CGAffineTransformMakeRotation(M_PI_2*2);
        [player1 addSubview:poisonImageView];
        
        // player 1 commander label
        self.commander1 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/2-220, phoneHeight/4-105, 225, 225)];
        self.commander1.text = @"0";
        self.commander1.textAlignment = NSTextAlignmentCenter;
        self.commander1.textColor = [UIColor whiteColor];
        self.commander1.font = [UIFont fontWithName:@"Matrix-Bold" size:75];
        self.commander1.transform = CGAffineTransformMakeRotation(M_PI_2*2);
        [player1 addSubview:self.commander1];
        
        // player 1 commander image
        UIImage* commanderImage = [UIImage imageNamed:@"skull_counter.png"];
        UIImageView* commanderImageView = [[UIImageView alloc] initWithFrame:CGRectMake(phoneWidth/2-125, phoneHeight/4+43, 35, 35)];
        commanderImageView.image = commanderImage;
        commanderImageView.transform = CGAffineTransformMakeRotation(M_PI_2*2);
        [player1 addSubview:commanderImageView];
        
        // poison + button
        CGRect poisonPlus1Frame = self.poisonPlus1.frame;
        poisonPlus1Frame.origin.x = phoneWidth/4+155;
        poisonPlus1Frame.origin.y = phoneHeight/4-95;
        self.poisonPlus1.frame = poisonPlus1Frame;
        self.poisonPlus1.transform = CGAffineTransformMakeRotation(M_PI_2*2);
        [player1 addSubview:self.poisonPlus1];
        
        // poison - button
        CGRect poisonMinus1Frame = self.poisonMinus1.frame;
        poisonMinus1Frame.origin.x = phoneWidth/4+215;
        poisonMinus1Frame.origin.y = phoneHeight/4-95;
        self.poisonMinus1.frame = poisonMinus1Frame;
        self.poisonMinus1.transform = CGAffineTransformMakeRotation(M_PI_2*2);
        [player1 addSubview:self.poisonMinus1];
        
        // life + button
        CGRect lifePlus1Frame = self.lifePlus1.frame;
        lifePlus1Frame.origin.x = phoneWidth/4+35;
        lifePlus1Frame.origin.y = phoneHeight/4-95;
        self.lifePlus1.frame = lifePlus1Frame;
        self.lifePlus1.transform = CGAffineTransformMakeRotation(M_PI_2*2);
        [player1 addSubview:self.lifePlus1];
        
        // life - button
        CGRect lifeMinus1Frame = self.lifeMinus1.frame;
        lifeMinus1Frame.origin.x = phoneWidth/4+95;
        lifeMinus1Frame.origin.y =phoneHeight/4-95;
        self.lifeMinus1.frame = lifeMinus1Frame;
        self.lifeMinus1.transform = CGAffineTransformMakeRotation(M_PI_2*2);
        [player1 addSubview:self.lifeMinus1];
        
        // commander + button
        CGRect commanderPlus1Frame = self.commanderPlus1.frame;
        commanderPlus1Frame.origin.x = phoneWidth/4-85;
        commanderPlus1Frame.origin.y = phoneHeight/4-95;
        self.commanderPlus1.frame = commanderPlus1Frame;
        self.commanderPlus1.transform = CGAffineTransformMakeRotation(M_PI_2*2);
        [player1 addSubview:self.commanderPlus1];
        
        // commander - button
        CGRect commanderMinus1Frame = self.commanderMinus1.frame;
        commanderMinus1Frame.origin.x = phoneWidth/4-25;
        commanderMinus1Frame.origin.y = phoneHeight/4-95;
        self.commanderMinus1.frame = commanderMinus1Frame;
        self.commanderMinus1.transform = CGAffineTransformMakeRotation(M_PI_2*2);
        [player1 addSubview:self.commanderMinus1];
        
        player1.layer.cornerRadius = 15;
        player1.clipsToBounds = true;
        player1.layer.borderWidth = 5.0;
        player1.layer.borderColor = [[UIColor blackColor] CGColor];
        
        // add the player1 view to the main view
        [self.view addSubview:player1];
        
        // player 2
        UIView* player2 = [[UIView alloc] initWithFrame:CGRectMake(0, phoneHeight/2, phoneWidth, phoneHeight/2)];
        player2.backgroundColor = [UIColor blueColor];
        
        // player 1 life label
        self.life2 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/2-115, phoneHeight/4-105, 225, 225)];
        self.life2.text = [NSString stringWithFormat:@"%d",self.life];
        self.life2.textAlignment = NSTextAlignmentCenter;
        self.life2.textColor = [UIColor whiteColor];
        self.life2.font = [UIFont fontWithName:@"Matrix-Bold" size:75];
        [player2 addSubview:self.life2];
        
        // player 1 life image
        lifeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(phoneWidth/2-20, phoneHeight/4-95, 40, 40)];
        lifeImageView.image = lifeImage;
        lifeImageView.transform = CGAffineTransformMakeRotation(M_PI_2*4);
        [player2 addSubview:lifeImageView];
        
        // player 1 poison label
        self.poison2 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/2, phoneHeight/4-105, 225, 225)];
        self.poison2.text = @"0";
        self.poison2.textAlignment = NSTextAlignmentCenter;
        self.poison2.textColor = [UIColor whiteColor];
        self.poison2.font = [UIFont fontWithName:@"Matrix-Bold" size:75];
        [player2 addSubview:self.poison2];
        
        // player 1 poison image
        poisonImageView = [[UIImageView alloc] initWithFrame:CGRectMake(phoneWidth/2+95, phoneHeight/4-93, 35, 35)];
        poisonImageView.image = poisonImage;
        poisonImageView.transform = CGAffineTransformMakeRotation(M_PI_2*4);
        [player2 addSubview:poisonImageView];
        
        // player 1 commander label
        self.commander2 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/2-220, phoneHeight/4-105, 225, 225)];
        self.commander2.text = @"0";
        self.commander2.textAlignment = NSTextAlignmentCenter;
        self.commander2.textColor = [UIColor whiteColor];
        self.commander2.font = [UIFont fontWithName:@"Matrix-Bold" size:75];
        [player2 addSubview:self.commander2];
        
        // player 1 commander image
        commanderImageView = [[UIImageView alloc] initWithFrame:CGRectMake(phoneWidth/2-125, phoneHeight/4-93, 35, 35)];
        commanderImageView.image = commanderImage;
        commanderImageView.transform = CGAffineTransformMakeRotation(M_PI_2*4);
        [player2 addSubview:commanderImageView];
        
        // poison + button
        CGRect poisonPlus2Frame = self.poisonPlus2.frame;
        poisonPlus2Frame.origin.x = phoneWidth/4+215;
        poisonPlus2Frame.origin.y = phoneHeight/4+50;
        self.poisonPlus2.frame = poisonPlus2Frame;
        [player2 addSubview:self.poisonPlus2];
        
        // poison - button
        CGRect poisonMinus2Frame = self.poisonMinus2.frame;
        poisonMinus2Frame.origin.x = phoneWidth/4+155;
        poisonMinus2Frame.origin.y = phoneHeight/4+50;
        self.poisonMinus2.frame = poisonMinus2Frame;
        [player2 addSubview:self.poisonMinus2];
        
        // life + button
        CGRect lifePlus2Frame = self.lifePlus2.frame;
        lifePlus2Frame.origin.x = phoneWidth/4+95;
        lifePlus2Frame.origin.y = phoneHeight/4+50;
        self.lifePlus2.frame = lifePlus2Frame;
        [player2 addSubview:self.lifePlus2];
        
        // life - button
        CGRect lifeMinus2Frame = self.lifeMinus2.frame;
        lifeMinus2Frame.origin.x = phoneWidth/4+35;
        lifeMinus2Frame.origin.y = phoneHeight/4+50;
        self.lifeMinus2.frame = lifeMinus2Frame;
        [player2 addSubview:self.lifeMinus2];
        
        // commander + button
        CGRect commanderPlus2Frame = self.commanderPlus2.frame;
        commanderPlus2Frame.origin.x = phoneWidth/4-25;
        commanderPlus2Frame.origin.y = phoneHeight/4+50;
        self.commanderPlus2.frame = commanderPlus2Frame;
        [player2 addSubview:self.commanderPlus2];
        
        // commander - button
        CGRect commanderMinus2Frame = self.commanderMinus2.frame;
        commanderMinus2Frame.origin.x = phoneWidth/4-85;
        commanderMinus2Frame.origin.y = phoneHeight/4+50;
        self.commanderMinus2.frame = commanderMinus2Frame;
        [player2 addSubview:self.commanderMinus2];
        
        player2.layer.cornerRadius = 15;
        player2.clipsToBounds = true;
        player2.layer.borderWidth = 5.0;
        player2.layer.borderColor = [[UIColor blackColor] CGColor];
        
        // add the player 2 view as the subview
        [self.view addSubview:player2];
        
        // format the finish game button
        self.finishGame.hidden = NO;
        self.finishGame.layer.cornerRadius = 15;
        self.finishGame.clipsToBounds = true;
        CGRect finishGameFrame = self.finishGame.frame;
        finishGameFrame.origin.x = phoneWidth/2-30;
        finishGameFrame.origin.y = phoneHeight/2-35;
        finishGameFrame.size = CGSizeMake(65,65);
        self.finishGame.frame = finishGameFrame;
        [self.view addSubview:self.finishGame];
        
    }
    // if three players
    else if (self.players == 3)
    {
        self.lifePlus4.hidden = YES;
        self.poisonPlus4.hidden = YES;
        self.commanderPlus4.hidden = YES;
        self.lifeMinus4.hidden = YES;
        self.poisonMinus4.hidden = YES;
        self.commanderMinus4.hidden = YES;
        
        // player 1 setup
        UIView* player1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, phoneWidth/2, phoneHeight/2+60)];
        player1.backgroundColor = [UIColor cyanColor];
        
        // player 1 life label
        self.life1 = [[UILabel alloc] initWithFrame:CGRectMake(40, 140, 120, 120)];
        self.life1.text = [NSString stringWithFormat:@"%d",self.life];
        self.life1.textAlignment = NSTextAlignmentCenter;
        self.life1.textColor = [UIColor whiteColor];
        self.life1.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
        self.life1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.life1];
        
        // player 1 life image
        UIImage* lifeImage = [UIImage imageNamed:@"life_counter.png"];
        UIImageView* lifeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(140, 190, 22, 22)];
        lifeImageView.image = lifeImage;
        lifeImageView.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:lifeImageView];
        
        // player 1 poison label
        self.poison1 = [[UILabel alloc] initWithFrame:CGRectMake(40, 10, 120, 120)];
        self.poison1.text = @"0";
        self.poison1.textAlignment = NSTextAlignmentCenter;
        self.poison1.textColor = [UIColor whiteColor];
        self.poison1.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
        self.poison1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.poison1];
        
        // player 1 poison image
        UIImage* poisonImage = [UIImage imageNamed:@"poison_counter.png"];
        UIImageView* poisonImageView = [[UIImageView alloc] initWithFrame:CGRectMake(140, 60, 22, 22)];
        poisonImageView.image = poisonImage;
        poisonImageView.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:poisonImageView];
        
        // player 1 commander label
        self.commander1 = [[UILabel alloc] initWithFrame:CGRectMake(40,270,120,120)];
        self.commander1.text = @"0";
        self.commander1.textAlignment = NSTextAlignmentCenter;
        self.commander1.textColor = [UIColor whiteColor];
        self.commander1.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
        self.commander1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.commander1];
        
        // player 1 commander image
        UIImage* commanderImage = [UIImage imageNamed:@"skull_counter.png"];
        UIImageView* commanderImageView = [[UIImageView alloc] initWithFrame:CGRectMake(140, 320, 22, 22)];
        commanderImageView.image = commanderImage;
        commanderImageView.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:commanderImageView];
        
        // poison + button
        CGRect poisonPlus1Frame = self.poisonPlus1.frame;
        poisonPlus1Frame.origin.x = 23;
        poisonPlus1Frame.origin.y = 75;
        poisonPlus1Frame.size = CGSizeMake(30,30);
        self.poisonPlus1.frame = poisonPlus1Frame;
        self.poisonPlus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.poisonPlus1];
        
        // poison - button
        CGRect poisonMinus1Frame = self.poisonMinus1.frame;
        poisonMinus1Frame.origin.x = 23;
        poisonMinus1Frame.origin.y = 35;
        poisonMinus1Frame.size = CGSizeMake(30,30);
        self.poisonMinus1.frame = poisonMinus1Frame;
        self.poisonMinus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.poisonMinus1];
        
        // life + button
        CGRect lifePlus1Frame = self.lifePlus1.frame;
        lifePlus1Frame.origin.x = 23;
        lifePlus1Frame.origin.y = 205;
        lifePlus1Frame.size = CGSizeMake(30,30);
        self.lifePlus1.frame = lifePlus1Frame;
        self.lifePlus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.lifePlus1];
        
        // life - button
        CGRect lifeMinus1Frame = self.lifeMinus1.frame;
        lifeMinus1Frame.origin.x = 23;
        lifeMinus1Frame.origin.y = 165;
        lifeMinus1Frame.size = CGSizeMake(30,30);
        self.lifeMinus1.frame = lifeMinus1Frame;
        self.lifeMinus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.lifeMinus1];
        
        // commander + button
        CGRect commanderPlus1Frame = self.commanderPlus1.frame;
        commanderPlus1Frame.origin.x = 23;
        commanderPlus1Frame.origin.y = 335;
        commanderPlus1Frame.size = CGSizeMake(30,30);
        self.commanderPlus1.frame = commanderPlus1Frame;
        self.commanderPlus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.commanderPlus1];
        
        // commander - button
        CGRect commanderMinus1Frame = self.commanderMinus1.frame;
        commanderMinus1Frame.origin.x = 23;
        commanderMinus1Frame.origin.y = 295;
        commanderMinus1Frame.size = CGSizeMake(30,30);
        self.commanderMinus1.frame = commanderMinus1Frame;
        self.commanderMinus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.commanderMinus1];
        
        player1.layer.cornerRadius = 15;
        player1.clipsToBounds = true;
        player1.layer.borderWidth = 5.0;
        player1.layer.borderColor = [[UIColor blackColor] CGColor];
        
        // add the player1 view to the main view
        [self.view addSubview:player1];
        
        // player 2 setup
        UIView* player2 = [[UIView alloc] initWithFrame:CGRectMake(phoneWidth/2, 0, phoneWidth/2, phoneHeight/2+60)];
        player2.backgroundColor = [UIColor greenColor];
        
        // player 1 life label
        self.life2 = [[UILabel alloc] initWithFrame:CGRectMake(33, 140, 120, 120)];
        self.life2.text = [NSString stringWithFormat:@"%d",self.life];
        self.life2.textAlignment = NSTextAlignmentCenter;
        self.life2.textColor = [UIColor whiteColor];
        self.life2.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
        self.life2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.life2];
        
        // player 1 life image
        //lifeImage = [UIImage imageNamed:@"life_counter.png"];
        lifeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(27, 190, 22, 22)];
        lifeImageView.image = lifeImage;
        lifeImageView.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:lifeImageView];
        
        // player 1 poison label
        self.poison2 = [[UILabel alloc] initWithFrame:CGRectMake(33, 10, 120, 120)];
        self.poison2.text = @"0";
        self.poison2.textAlignment = NSTextAlignmentCenter;
        self.poison2.textColor = [UIColor whiteColor];
        self.poison2.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
        self.poison2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.poison2];
        
        // player 1 poison image
        //UIImage* poisonImage = [UIImage imageNamed:@"poison_counter.png"];
        poisonImageView = [[UIImageView alloc] initWithFrame:CGRectMake(27, 60, 22, 22)];
        poisonImageView.image = poisonImage;
        poisonImageView.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:poisonImageView];
        
        // player 1 commander label
        self.commander2 = [[UILabel alloc] initWithFrame:CGRectMake(33,270,120,120)];
        self.commander2.text = @"0";
        self.commander2.textAlignment = NSTextAlignmentCenter;
        self.commander2.textColor = [UIColor whiteColor];
        self.commander2.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
        self.commander2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.commander2];
        
        // player 1 commander image
        //UIImage* commanderImage = [UIImage imageNamed:@"skull_counter.png"];
        commanderImageView = [[UIImageView alloc] initWithFrame:CGRectMake(27, 320, 22, 22)];
        commanderImageView.image = commanderImage;
        commanderImageView.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:commanderImageView];
        
        // poison + button
        CGRect poisonPlus2Frame = self.poisonPlus2.frame;
        poisonPlus2Frame.origin.x = 135;
        poisonPlus2Frame.origin.y = 35;
        poisonPlus2Frame.size = CGSizeMake(30,30);
        self.poisonPlus2.frame = poisonPlus2Frame;
        self.poisonPlus2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.poisonPlus2];
        
        // poison - button
        CGRect poisonMinus2Frame = self.poisonMinus2.frame;
        poisonMinus2Frame.origin.x = 135;
        poisonMinus2Frame.origin.y = 75;
        poisonMinus2Frame.size = CGSizeMake(30,30);
        self.poisonMinus2.frame = poisonMinus2Frame;
        self.poisonMinus2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.poisonMinus2];
        
        // life + button
        CGRect lifePlus2Frame = self.lifePlus2.frame;
        lifePlus2Frame.origin.x = 135;
        lifePlus2Frame.origin.y = 165;
        lifePlus2Frame.size = CGSizeMake(30,30);
        self.lifePlus2.frame = lifePlus2Frame;
        self.lifePlus2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.lifePlus2];
        
        // life - button
        CGRect lifeMinus2Frame = self.lifeMinus2.frame;
        lifeMinus2Frame.origin.x = 135;
        lifeMinus2Frame.origin.y = 205;
        lifeMinus2Frame.size = CGSizeMake(30,30);
        self.lifeMinus2.frame = lifeMinus2Frame;
        self.lifeMinus2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.lifeMinus2];
        
        // commander + button
        CGRect commanderPlus2Frame = self.commanderPlus2.frame;
        commanderPlus2Frame.origin.x = 135;
        commanderPlus2Frame.origin.y = 295;
        commanderPlus2Frame.size = CGSizeMake(30,30);
        self.commanderPlus2.frame = commanderPlus2Frame;
        self.commanderPlus2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.commanderPlus2];
        
        // commander - button
        CGRect commanderMinus2Frame = self.commanderMinus2.frame;
        commanderMinus2Frame.origin.x = 135;
        commanderMinus2Frame.origin.y = 335;
        commanderMinus2Frame.size = CGSizeMake(30,30);
        self.commanderMinus2.frame = commanderMinus2Frame;
        self.commanderMinus2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.commanderMinus2];
        
        player2.layer.cornerRadius = 15;
        player2.clipsToBounds = true;
        player2.layer.borderWidth = 5.0;
        player2.layer.borderColor = [[UIColor blackColor] CGColor];
        
        // add the player1 view to the main view
        [self.view addSubview:player2];
        
        // player 3 setup
        UIView* player3 = [[UIView alloc] initWithFrame:CGRectMake(0, phoneHeight/2+60, phoneWidth, phoneHeight/2-60)];
        player3.backgroundColor = [UIColor yellowColor];
        
        // player 1 life label
        self.life3 = [[UILabel alloc] initWithFrame:CGRectMake(127, 70, 120, 120)];
        self.life3.text = [NSString stringWithFormat:@"%d",self.life];
        self.life3.textAlignment = NSTextAlignmentCenter;
        self.life3.textColor = [UIColor whiteColor];
        self.life3.font = [UIFont fontWithName:@"Matrix-Bold" size:60];
        [player3 addSubview:self.life3];
        
        // player 1 life image
        lifeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(175, 55, 26, 26)];
        lifeImageView.image = lifeImage;
        [player3 addSubview:lifeImageView];
        
        // player 1 poison label
        self.poison3 = [[UILabel alloc] initWithFrame:CGRectMake(2, 70, 120, 120)];
        self.poison3.text = @"0";
        self.poison3.textAlignment = NSTextAlignmentCenter;
        self.poison3.textColor = [UIColor whiteColor];
        self.poison3.font = [UIFont fontWithName:@"Matrix-Bold" size:60];
        [player3 addSubview:self.poison3];
        
        // player 1 poison image
        //UIImage* poisonImage = [UIImage imageNamed:@"poison_counter.png"];
        poisonImageView = [[UIImageView alloc] initWithFrame:CGRectMake(48, 55, 26, 26)];
        poisonImageView.image = poisonImage;
        [player3 addSubview:poisonImageView];
        
        // player 1 commander label
        self.commander3 = [[UILabel alloc] initWithFrame:CGRectMake(252,70,120,120)];
        self.commander3.text = @"0";
        self.commander3.textAlignment = NSTextAlignmentCenter;
        self.commander3.textColor = [UIColor whiteColor];
        self.commander3.font = [UIFont fontWithName:@"Matrix-Bold" size:60];
        [player3 addSubview:self.commander3];
        
        // player 1 commander image
        commanderImageView = [[UIImageView alloc] initWithFrame:CGRectMake(299, 55, 26, 26)];
        commanderImageView.image = commanderImage;
        [player3 addSubview:commanderImageView];
        
        // poison + button
        CGRect poisonPlus3Frame = self.poisonPlus3.frame;
        poisonPlus3Frame.origin.x = 70;
        poisonPlus3Frame.origin.y = 175;
        poisonPlus3Frame.size = CGSizeMake(35,35);
        self.poisonPlus3.frame = poisonPlus3Frame;
        [player3 addSubview:self.poisonPlus3];
        
        // poison - button
        CGRect poisonMinus3Frame = self.poisonMinus3.frame;
        poisonMinus3Frame.origin.x = 20;
        poisonMinus3Frame.origin.y = 175;
        poisonMinus3Frame.size = CGSizeMake(35,35);
        self.poisonMinus3.frame = poisonMinus3Frame;
        [player3 addSubview:self.poisonMinus3];
        
        // life + button
        CGRect lifePlus3Frame = self.lifePlus3.frame;
        lifePlus3Frame.origin.x = 200;
        lifePlus3Frame.origin.y = 175;
        lifePlus3Frame.size = CGSizeMake(35,35);
        self.lifePlus3.frame = lifePlus3Frame;
        [player3 addSubview:self.lifePlus3];
        
        // life - button
        CGRect lifeMinus3Frame = self.lifeMinus3.frame;
        lifeMinus3Frame.origin.x = 145;
        lifeMinus3Frame.origin.y = 175;
        lifeMinus3Frame.size = CGSizeMake(35,35);
        self.lifeMinus3.frame = lifeMinus3Frame;
        [player3 addSubview:self.lifeMinus3];
        
        // commander + button
        CGRect commanderPlus3Frame = self.commanderPlus3.frame;
        commanderPlus3Frame.origin.x = 325;
        commanderPlus3Frame.origin.y = 175;
        commanderPlus3Frame.size = CGSizeMake(35,35);
        self.commanderPlus3.frame = commanderPlus3Frame;
        [player3 addSubview:self.commanderPlus3];
        
        // commander - button
        CGRect commanderMinus3Frame = self.commanderMinus3.frame;
        commanderMinus3Frame.origin.x = 270;
        commanderMinus3Frame.origin.y = 175;
        commanderMinus3Frame.size = CGSizeMake(35,35);
        self.commanderMinus3.frame = commanderMinus3Frame;
        [player3 addSubview:self.commanderMinus3];
        
        player3.layer.cornerRadius = 15;
        player3.clipsToBounds = true;
        player3.layer.borderWidth = 5.0;
        player3.layer.borderColor = [[UIColor blackColor] CGColor];
        
        [self.view addSubview:player3];
        
        // format the finish game button
        self.finishGame.hidden = NO;
        self.finishGame.layer.cornerRadius = 15;
        self.finishGame.clipsToBounds = true;
        CGRect finishGameFrame = self.finishGame.frame;
        finishGameFrame.origin.x = phoneWidth/2-25;
        finishGameFrame.origin.y = phoneHeight/2+28;
        finishGameFrame.size = CGSizeMake(50,50);
        self.finishGame.frame = finishGameFrame;
        [self.view addSubview:self.finishGame];
        
    }
    // if four players
    else
    {
        // player 1 view
        UIView* player1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, phoneWidth/2, phoneHeight/2)];
        player1.backgroundColor = [UIColor cyanColor];
        
        // player 1 life label
        self.life1 = [[UILabel alloc] initWithFrame:CGRectMake(50, 115, 100, 100)];
        self.life1.text = [NSString stringWithFormat:@"%d",self.life];
        self.life1.textAlignment = NSTextAlignmentCenter;
        self.life1.textColor = [UIColor whiteColor];
        self.life1.font = [UIFont fontWithName:@"Matrix-Bold" size:45];
        self.life1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.life1];
        
        // player 1 life image
        UIImage* lifeImage = [UIImage imageNamed:@"life_counter.png"];
        UIImageView* lifeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(125, 156.5, 15, 15)];
        lifeImageView.image = lifeImage;
        lifeImageView.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:lifeImageView];
        
        // player 1 poison label
        self.poison1 = [[UILabel alloc] initWithFrame:CGRectMake(50, 30, 100, 100)];
        self.poison1.text = @"0";
        self.poison1.textAlignment = NSTextAlignmentCenter;
        self.poison1.textColor = [UIColor whiteColor];
        self.poison1.font = [UIFont fontWithName:@"Matrix-Bold" size:45];
        self.poison1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.poison1];
        
        // player 1 poison image
        UIImage* poisonImage = [UIImage imageNamed:@"poison_counter.png"];
        UIImageView* poisonImageView = [[UIImageView alloc] initWithFrame:CGRectMake(125, 71.5, 15, 15)];
        poisonImageView.image = poisonImage;
        poisonImageView.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:poisonImageView];
        
        // player 1 commander label
        self.commander1 = [[UILabel alloc] initWithFrame:CGRectMake(50,200,100,100)];
        self.commander1.text = @"0";
        self.commander1.textAlignment = NSTextAlignmentCenter;
        self.commander1.textColor = [UIColor whiteColor];
        self.commander1.font = [UIFont fontWithName:@"Matrix-Bold" size:45];
        self.commander1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.commander1];
        
        // player 1 commander image
        UIImage* commanderImage = [UIImage imageNamed:@"skull_counter.png"];
        UIImageView* commanderImageView = [[UIImageView alloc] initWithFrame:CGRectMake(125, 241.5, 15, 15)];
        commanderImageView.image = commanderImage;
        commanderImageView.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:commanderImageView];
        
        // poison + button
        CGRect poisonPlus1Frame = self.poisonPlus1.frame;
        poisonPlus1Frame.origin.x = 37;
        poisonPlus1Frame.origin.y = 85;
        poisonPlus1Frame.size = CGSizeMake(30,30);
        self.poisonPlus1.frame = poisonPlus1Frame;
        self.poisonPlus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.poisonPlus1];
        
        // poison - button
        CGRect poisonMinus1Frame = self.poisonMinus1.frame;
        poisonMinus1Frame.origin.x = 37;
        poisonMinus1Frame.origin.y = 50;
        poisonMinus1Frame.size = CGSizeMake(30,30);
        self.poisonMinus1.frame = poisonMinus1Frame;
        self.poisonMinus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.poisonMinus1];
        
        // life + button
        CGRect lifePlus1Frame = self.lifePlus1.frame;
        lifePlus1Frame.origin.x = 37;
        lifePlus1Frame.origin.y = 165;
        lifePlus1Frame.size = CGSizeMake(30,30);
        self.lifePlus1.frame = lifePlus1Frame;
        self.lifePlus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.lifePlus1];
        
        // life - button
        CGRect lifeMinus1Frame = self.lifeMinus1.frame;
        lifeMinus1Frame.origin.x = 37;
        lifeMinus1Frame.origin.y = 130;
        lifeMinus1Frame.size = CGSizeMake(30,30);
        self.lifeMinus1.frame = lifeMinus1Frame;
        self.lifeMinus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.lifeMinus1];
        
        // commander + button
        CGRect commanderPlus1Frame = self.commanderPlus1.frame;
        commanderPlus1Frame.origin.x = 37;
        commanderPlus1Frame.origin.y = 255;
        commanderPlus1Frame.size = CGSizeMake(30,30);
        self.commanderPlus1.frame = commanderPlus1Frame;
        self.commanderPlus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.commanderPlus1];
        
        // commander - button
        CGRect commanderMinus1Frame = self.commanderMinus1.frame;
        commanderMinus1Frame.origin.x = 37;
        commanderMinus1Frame.origin.y = 220;
        commanderMinus1Frame.size = CGSizeMake(30,30);
        self.commanderMinus1.frame = commanderMinus1Frame;
        self.commanderMinus1.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player1 addSubview:self.commanderMinus1];
        
        player1.layer.cornerRadius = 15;
        player1.clipsToBounds = true;
        player1.layer.borderWidth = 5.0;
        player1.layer.borderColor = [[UIColor blackColor] CGColor];
        
        // add the player1 view to the main view
        [self.view addSubview:player1];
        
        UIView* player2 = [[UIView alloc] initWithFrame:CGRectMake(phoneWidth/2, 0, phoneWidth/2, phoneHeight/2)];
        player2.backgroundColor = [UIColor greenColor];
        
        // player 2 life label
        self.life2 = [[UILabel alloc] initWithFrame:CGRectMake(50, 115, 100, 100)];
        self.life2.text = [NSString stringWithFormat:@"%d",self.life];
        self.life2.textAlignment = NSTextAlignmentCenter;
        self.life2.textColor = [UIColor whiteColor];
        self.life2.font = [UIFont fontWithName:@"Matrix-Bold" size:45];
        self.life2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.life2];
        
        // player 2 life image
        lifeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(50, 156.5, 15, 15)];
        lifeImageView.image = lifeImage;
        lifeImageView.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:lifeImageView];
        
        // player 1 poison label
        self.poison2 = [[UILabel alloc] initWithFrame:CGRectMake(50, 30, 100, 100)];
        self.poison2.text = @"0";
        self.poison2.textAlignment = NSTextAlignmentCenter;
        self.poison2.textColor = [UIColor whiteColor];
        self.poison2.font = [UIFont fontWithName:@"Matrix-Bold" size:45];
        self.poison2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.poison2];
        
        // player 1 poison image
        poisonImageView = [[UIImageView alloc] initWithFrame:CGRectMake(50, 71.5, 15, 15)];
        poisonImageView.image = poisonImage;
        poisonImageView.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:poisonImageView];
        
        // player 1 commander label
        self.commander2 = [[UILabel alloc] initWithFrame:CGRectMake(50,200,100,100)];
        self.commander2.text = @"0";
        self.commander2.textAlignment = NSTextAlignmentCenter;
        self.commander2.textColor = [UIColor whiteColor];
        self.commander2.font = [UIFont fontWithName:@"Matrix-Bold" size:45];
        self.commander2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.commander2];
        
        // player 1 commander image
        commanderImageView = [[UIImageView alloc] initWithFrame:CGRectMake(50, 241.5, 15, 15)];
        commanderImageView.image = commanderImage;
        commanderImageView.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:commanderImageView];
        
        // poison + button
        CGRect poisonPlus2Frame = self.poisonPlus2.frame;
        poisonPlus2Frame.origin.x = 120;
        poisonPlus2Frame.origin.y = 50;
        poisonPlus2Frame.size = CGSizeMake(30,30);
        self.poisonPlus2.frame = poisonPlus2Frame;
        self.poisonPlus2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.poisonPlus2];
        
        // poison - button
        CGRect poisonMinus2Frame = self.poisonMinus2.frame;
        poisonMinus2Frame.origin.x = 120;
        poisonMinus2Frame.origin.y = 85;
        poisonMinus2Frame.size = CGSizeMake(30,30);
        self.poisonMinus2.frame = poisonMinus2Frame;
        self.poisonMinus2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.poisonMinus2];
        
        // life + button
        CGRect lifePlus2Frame = self.lifePlus2.frame;
        lifePlus2Frame.origin.x = 120;
        lifePlus2Frame.origin.y = 130;
        lifePlus2Frame.size = CGSizeMake(30,30);
        self.lifePlus2.frame = lifePlus2Frame;
        self.lifePlus2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.lifePlus2];
        
        // life - button
        CGRect lifeMinus2Frame = self.lifeMinus2.frame;
        lifeMinus2Frame.origin.x = 120;
        lifeMinus2Frame.origin.y = 165;
        lifeMinus2Frame.size = CGSizeMake(30,30);
        self.lifeMinus2.frame = lifeMinus2Frame;
        self.lifeMinus2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.lifeMinus2];
        
        // commander + button
        CGRect commanderPlus2Frame = self.commanderPlus2.frame;
        commanderPlus2Frame.origin.x = 120;
        commanderPlus2Frame.origin.y = 220;
        commanderPlus2Frame.size = CGSizeMake(30,30);
        self.commanderPlus2.frame = commanderPlus2Frame;
        self.commanderPlus2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.commanderPlus2];
        
        // commander - button
        CGRect commanderMinus2Frame = self.commanderMinus2.frame;
        commanderMinus2Frame.origin.x = 120;
        commanderMinus2Frame.origin.y = 255;
        commanderMinus2Frame.size = CGSizeMake(30,30);
        self.commanderMinus2.frame = commanderMinus2Frame;
        self.commanderMinus2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player2 addSubview:self.commanderMinus2];
        
        player2.layer.cornerRadius = 15;
        player2.clipsToBounds = true;
        player2.layer.borderWidth = 5.0;
        player2.layer.borderColor = [[UIColor blackColor] CGColor];
        
        [self.view addSubview:player2];
        
        UIView* player3 = [[UIView alloc] initWithFrame:CGRectMake(0, phoneHeight/2, phoneWidth/2, phoneHeight/2)];
        player3.backgroundColor = [UIColor purpleColor];
        
        // player 1 life label
        self.life3 = [[UILabel alloc] initWithFrame:CGRectMake(50, 115, 100, 100)];
        self.life3.text = [NSString stringWithFormat:@"%d",self.life];
        self.life3.textAlignment = NSTextAlignmentCenter;
        self.life3.textColor = [UIColor whiteColor];
        self.life3.font = [UIFont fontWithName:@"Matrix-Bold" size:45];
        self.life3.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player3 addSubview:self.life3];
        
        // player 1 life image
        //lifeImage = [UIImage imageNamed:@"life_counter.png"];
        lifeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(125, 156.5, 15, 15)];
        lifeImageView.image = lifeImage;
        lifeImageView.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player3 addSubview:lifeImageView];
        
        // player 1 poison label
        self.poison3 = [[UILabel alloc] initWithFrame:CGRectMake(50, 30, 100, 100)];
        self.poison3.text = @"0";
        self.poison3.textAlignment = NSTextAlignmentCenter;
        self.poison3.textColor = [UIColor whiteColor];
        self.poison3.font = [UIFont fontWithName:@"Matrix-Bold" size:45];
        self.poison3.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player3 addSubview:self.poison3];
        
        // player 1 poison image
        poisonImageView = [[UIImageView alloc] initWithFrame:CGRectMake(125, 71.5, 15, 15)];
        poisonImageView.image = poisonImage;
        poisonImageView.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player3 addSubview:poisonImageView];
        
        // player 1 commander label
        self.commander3 = [[UILabel alloc] initWithFrame:CGRectMake(50,200,100,100)];
        self.commander3.text = @"0";
        self.commander3.textAlignment = NSTextAlignmentCenter;
        self.commander3.textColor = [UIColor whiteColor];
        self.commander3.font = [UIFont fontWithName:@"Matrix-Bold" size:45];
        self.commander3.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player3 addSubview:self.commander3];
        
        // player 1 commander image
        commanderImageView = [[UIImageView alloc] initWithFrame:CGRectMake(125, 241.5, 15, 15)];
        commanderImageView.image = commanderImage;
        commanderImageView.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player3 addSubview:commanderImageView];
        
        // poison + button
        CGRect poisonPlus3Frame = self.poisonPlus3.frame;
        poisonPlus3Frame.origin.x = 37;
        poisonPlus3Frame.origin.y = 85;
        poisonPlus3Frame.size = CGSizeMake(30,30);
        self.poisonPlus3.frame = poisonPlus3Frame;
        self.poisonPlus3.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player3 addSubview:self.poisonPlus3];
        
        // poison - button
        CGRect poisonMinus3Frame = self.poisonMinus3.frame;
        poisonMinus3Frame.origin.x = 37;
        poisonMinus3Frame.origin.y = 50;
        poisonMinus3Frame.size = CGSizeMake(30,30);
        self.poisonMinus3.frame = poisonMinus3Frame;
        self.poisonMinus3.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player3 addSubview:self.poisonMinus3];
        
        // life + button
        CGRect lifePlus3Frame = self.lifePlus3.frame;
        lifePlus3Frame.origin.x = 37;
        lifePlus3Frame.origin.y = 165;
        lifePlus3Frame.size = CGSizeMake(30,30);
        self.lifePlus3.frame = lifePlus3Frame;
        self.lifePlus3.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player3 addSubview:self.lifePlus3];
        
        // life - button
        CGRect lifeMinus3Frame = self.lifeMinus3.frame;
        lifeMinus3Frame.origin.x = 37;
        lifeMinus3Frame.origin.y = 130;
        lifeMinus3Frame.size = CGSizeMake(30,30);
        self.lifeMinus3.frame = lifeMinus3Frame;
        self.lifeMinus3.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player3 addSubview:self.lifeMinus3];
        
        // commander + button
        CGRect commmanderPlus3Frame = self.commanderPlus3.frame;
        commmanderPlus3Frame.origin.x = 37;
        commmanderPlus3Frame.origin.y = 255;
        commmanderPlus3Frame.size = CGSizeMake(30,30);
        self.commanderPlus3.frame = commmanderPlus3Frame;
        self.commanderPlus3.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player3 addSubview:self.commanderPlus3];
        
        // commander - button
        CGRect commanderMinus3Frame = self.commanderMinus3.frame;
        commanderMinus3Frame.origin.x = 37;
        commanderMinus3Frame.origin.y = 220;
        commanderMinus3Frame.size = CGSizeMake(30,30);
        self.commanderMinus3.frame = commanderMinus3Frame;
        self.commanderMinus3.transform = CGAffineTransformMakeRotation(M_PI_2);
        [player3 addSubview:self.commanderMinus3];
        
        player3.layer.cornerRadius = 15;
        player3.clipsToBounds = true;
        player3.layer.borderWidth = 5.0;
        player3.layer.borderColor = [[UIColor blackColor] CGColor];
        
        [self.view addSubview:player3];
        
        UIView* player4 = [[UIView alloc] initWithFrame:CGRectMake(phoneWidth/2, phoneHeight/2, phoneWidth/2, phoneHeight/2)];
        player4.backgroundColor = [UIColor grayColor];
        
        // player 1 life label
        self.life4 = [[UILabel alloc] initWithFrame:CGRectMake(50, 115, 100, 100)];
        self.life4.text = [NSString stringWithFormat:@"%d",self.life];
        self.life4.textAlignment = NSTextAlignmentCenter;
        self.life4.textColor = [UIColor whiteColor];
        self.life4.font = [UIFont fontWithName:@"Matrix-Bold" size:45];
        self.life4.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player4 addSubview:self.life4];
        
        // player 1 life image
        lifeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(50, 156.5, 15, 15)];
        lifeImageView.image = lifeImage;
        lifeImageView.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player4 addSubview:lifeImageView];
        
        // player 1 poison label
        self.poison4 = [[UILabel alloc] initWithFrame:CGRectMake(50, 30, 100, 100)];
        self.poison4.text = @"0";
        self.poison4.textAlignment = NSTextAlignmentCenter;
        self.poison4.textColor = [UIColor whiteColor];
        self.poison4.font = [UIFont fontWithName:@"Matrix-Bold" size:45];
        self.poison4.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player4 addSubview:self.poison4];
        
        // player 1 poison image
        poisonImageView = [[UIImageView alloc] initWithFrame:CGRectMake(50, 71.5, 15, 15)];
        poisonImageView.image = poisonImage;
        poisonImageView.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player4 addSubview:poisonImageView];
        
        // player 1 commander label
        self.commander4 = [[UILabel alloc] initWithFrame:CGRectMake(50,200,100,100)];
        self.commander4.text = @"0";
        self.commander4.textAlignment = NSTextAlignmentCenter;
        self.commander4.textColor = [UIColor whiteColor];
        self.commander4.font = [UIFont fontWithName:@"Matrix-Bold" size:45];
        self.commander4.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player4 addSubview:self.commander4];
        
        // player 1 commander image
        commanderImageView = [[UIImageView alloc] initWithFrame:CGRectMake(50, 241.5, 15, 15)];
        commanderImageView.image = commanderImage;
        commanderImageView.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player4 addSubview:commanderImageView];
        
        // poison + button
        CGRect poisonPlus4Frame = self.poisonPlus4.frame;
        poisonPlus4Frame.origin.x = 120;
        poisonPlus4Frame.origin.y = 50;
        poisonPlus4Frame.size = CGSizeMake(30,30);
        self.poisonPlus4.frame = poisonPlus4Frame;
        self.poisonPlus4.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player4 addSubview:self.poisonPlus4];
        
        // poison - button
        CGRect poisonMinus4Frame = self.poisonMinus4.frame;
        poisonMinus4Frame.origin.x = 120;
        poisonMinus4Frame.origin.y = 85;
        poisonMinus4Frame.size = CGSizeMake(30,30);
        self.poisonMinus4.frame = poisonMinus4Frame;
        self.poisonMinus4.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player4 addSubview:self.poisonMinus4];
        
        // life + button
        CGRect lifePlus4Frame = self.lifePlus4.frame;
        lifePlus4Frame.origin.x = 120;
        lifePlus4Frame.origin.y = 130;
        lifePlus4Frame.size = CGSizeMake(30,30);
        self.lifePlus4.frame = lifePlus4Frame;
        self.lifePlus4.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player4 addSubview:self.lifePlus4];
        
        // life - button
        CGRect lifeMinus4Frame = self.lifeMinus4.frame;
        lifeMinus4Frame.origin.x = 120;
        lifeMinus4Frame.origin.y = 165;
        lifeMinus4Frame.size = CGSizeMake(30,30);
        self.lifeMinus4.frame = lifeMinus4Frame;
        self.lifeMinus4.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player4 addSubview:self.lifeMinus4];
        
        // commander + button
        CGRect commanderPlus4Frame = self.commanderPlus4.frame;
        commanderPlus4Frame.origin.x = 120;
        commanderPlus4Frame.origin.y = 220;
        commanderPlus4Frame.size = CGSizeMake(30,30);
        self.commanderPlus4.frame = commanderPlus4Frame;
        self.commanderPlus4.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player4 addSubview:self.commanderPlus4];
        
        // commander - button
        CGRect commanderMinus4Frame = self.commanderMinus4.frame;
        commanderMinus4Frame.origin.x = 120;
        commanderMinus4Frame.origin.y = 255;
        commanderMinus4Frame.size = CGSizeMake(30,30);
        self.commanderMinus4.frame = commanderMinus4Frame;
        self.commanderMinus4.transform = CGAffineTransformMakeRotation(M_PI_2*3);
        [player4 addSubview:self.commanderMinus4];
        
        player4.layer.cornerRadius = 15;
        player4.clipsToBounds = true;
        player4.layer.borderWidth = 5.0;
        player4.layer.borderColor = [[UIColor blackColor] CGColor];
        
        [self.view addSubview:player4];
        
        // format the finish game button
        self.finishGame.hidden = NO;
        self.finishGame.layer.cornerRadius = 15;
        self.finishGame.clipsToBounds = true;
        CGRect finishGameFrame = self.finishGame.frame;
        finishGameFrame.origin.x = phoneWidth/2-25;
        finishGameFrame.origin.y = phoneHeight/2-25;
        finishGameFrame.size = CGSizeMake(50,50);
        self.finishGame.frame = finishGameFrame;
        self.finishGame.transform = CGAffineTransformMakeRotation(M_PI_2);
        [self.view addSubview:self.finishGame];
    }
}

// 1st player actions
- (IBAction)lifePlus1Clicked:(id)sender {
    int life = [self.life1.text intValue];
    if (life == 0)
        self.life1.textColor = [UIColor whiteColor];
    life += 1;
    self.life1.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)poisonPlus1Clicked:(id)sender {
    int life = [self.poison1.text intValue];
    if (life == 9)
        self.poison1.textColor = [UIColor redColor];
    life += 1;
    self.poison1.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)commanderPlus1Clicked:(id)sender {
    int life = [self.commander1.text intValue];
    if (life == 20)
        self.commander1.textColor = [UIColor redColor];
    life += 1;
    self.commander1.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)lifeMinus1Clicked:(id)sender {
    int life = [self.life1.text intValue];
    if (life == 1)
        self.life1.textColor = [UIColor redColor];
    life -= 1;
    self.life1.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)poisonMinus1Clicked:(id)sender {
    int life = [self.poison1.text intValue];
    if (life == 10)
        self.poison1.textColor = [UIColor whiteColor];
    life -= 1;
    self.poison1.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)commanderMinus1Clicked:(id)sender {
    int life = [self.commander1.text intValue];
    if (life == 21)
        self.commander1.textColor = [UIColor whiteColor];
    life -= 1;
    self.commander1.text = [NSString stringWithFormat:@"%d",life];
}

// 2nd player actions
- (IBAction)lifePlus2Clicked:(id)sender {
    int life = [self.life2.text intValue];
    if (life == 0)
        self.life2.textColor = [UIColor whiteColor];
    life += 1;
    self.life2.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)poisonPlus2Clicked:(id)sender {
    int life = [self.poison2.text intValue];
    if (life == 9)
        self.poison2.textColor = [UIColor redColor];
    life += 1;
    self.poison2.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)commanderPlus2Clicked:(id)sender {
    int life = [self.commander2.text intValue];
    if (life == 20)
        self.commander2.textColor = [UIColor redColor];
    life += 1;
    self.commander2.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)lifeMinus2Clicked:(id)sender {
    int life = [self.life2.text intValue];
    if (life == 1)
        self.life2.textColor = [UIColor redColor];
    life -= 1;
    self.life2.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)poisonMinus2Clicked:(id)sender {
    int life = [self.poison2.text intValue];
    if (life == 10)
        self.poison2.textColor = [UIColor whiteColor];
    life -= 1;
    self.poison2.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)commanderMinus2Clicked:(id)sender {
    int life = [self.commander2.text intValue];
    if (life == 21)
        self.commander2.textColor = [UIColor whiteColor];
    life -= 1;
    self.commander2.text = [NSString stringWithFormat:@"%d",life];
}

// 3rd player actions
- (IBAction)lifePlus3Clicked:(id)sender {
    int life = [self.life3.text intValue];
    if (life == 0)
        self.life3.textColor = [UIColor whiteColor];
    life += 1;
    self.life3.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)poisonPlus3Clicked:(id)sender {
    int life = [self.poison3.text intValue];
    if (life == 9)
        self.poison3.textColor = [UIColor redColor];
    life += 1;
    self.poison3.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)commanderPlus3Clicked:(id)sender {
    int life = [self.commander3.text intValue];
    if (life == 20)
        self.commander3.textColor = [UIColor redColor];
    life += 1;
    self.commander3.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)lifeMinus3Clicked:(id)sender {
    int life = [self.life3.text intValue];
    if (life == 1)
        self.life3.textColor = [UIColor redColor];
    life -= 1;
    self.life3.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)poisonMinus3Clicked:(id)sender {
    int life = [self.poison3.text intValue];
    if (life == 10)
        self.poison3.textColor = [UIColor whiteColor];
    life -= 1;
    self.poison3.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)commanderMinus3Clicked:(id)sender {
    int life = [self.commander3.text intValue];
    if (life == 21)
        self.commander3.textColor = [UIColor whiteColor];
    life -= 1;
    self.commander3.text = [NSString stringWithFormat:@"%d",life];
}

// 4th player actions
- (IBAction)lifePlus4Clicked:(id)sender {
    int life = [self.life4.text intValue];
    if (life == 0)
        self.life4.textColor = [UIColor whiteColor];
    life += 1;
    self.life4.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)poisonPlus4Clicked:(id)sender {
    int life = [self.poison4.text intValue];
    if (life == 9)
        self.poison4.textColor = [UIColor redColor];
    life += 1;
    self.poison4.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)commanderPlus4Clicked:(id)sender {
    int life = [self.commander4.text intValue];
    if (life == 20)
        self.commander4.textColor = [UIColor redColor];
    life += 1;
    self.commander4.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)lifeMinus4Clicked:(id)sender {
    int life = [self.life4.text intValue];
    if (life == 1)
        self.life4.textColor = [UIColor redColor];
    life -= 1;
    self.life4.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)poisonMinus4Clicked:(id)sender {
    int life = [self.poison4.text intValue];
    if (life == 10)
        self.poison4.textColor = [UIColor whiteColor];
    life -= 1;
    self.poison4.text = [NSString stringWithFormat:@"%d",life];
}
- (IBAction)commanderMinus4Clicked:(id)sender {
    int life = [self.commander4.text intValue];
    if (life == 21)
        self.commander4.textColor = [UIColor whiteColor];
    life -= 1;
    self.commander4.text = [NSString stringWithFormat:@"%d",life];
}

-(NSString*) constructMessage
{
    if (self.players == 1)
    {
        return [NSString stringWithFormat:@"PLAYER 1\nLife total: %@\nPoison counters: %@\nCommander damage: %@\n",self.life1.text,self.poison1.text,self.commander1.text];
    }
    else if (self.players == 2)
    {
        return [NSString stringWithFormat:@"PLAYER 1\nLife total: %@\nPoison counters: %@\nCommander damage: %@\n\nPLAYER 2\nLife total: %@\nPoison counters: %@\nCommander damage: %@",self.life1.text,self.poison1.text,self.commander1.text,self.life2.text,self.poison2.text,self.commander2.text];
    }
    else if (self.players == 3)
    {
        return [NSString stringWithFormat:@"PLAYER 1\nLife total: %@\nPoison counters: %@\nCommander damage: %@\n\nPLAYER 2\nLife total: %@\nPoison counters: %@\nCommander damage: %@\nPLAYER 3\n\nLife total: %@\nPoison counters: %@\nCommander damage: %@",self.life1.text,self.poison1.text,self.commander1.text,self.life2.text,self.poison2.text,self.commander2.text,self.life3.text,self.poison3.text,self.commander3.text];
    }
    else
    {
        return [NSString stringWithFormat:@"PLAYER 1\nLife total: %@\nPoison counters: %@\nCommander damage: %@\n\nPLAYER 2\nLife total: %@\nPoison counters: %@\nCommander damage: %@\n\nPLAYER 3\nLife total: %@\nPoison counters: %@\nCommander damage: %@\n\nPLAYER 4\nLife total: %@\nPoison counters: %@\nCommander damage: %@",self.life1.text,self.poison1.text,self.commander1.text,self.life2.text,self.poison2.text,self.commander2.text,self.life3.text,self.poison3.text,self.commander3.text,self.life4.text,self.poison4.text,self.commander4.text];
    }
}

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    [self dismissViewControllerAnimated:YES completion:NULL];
}

-(void) addDie:(CGFloat) x andY:(CGFloat) y
{
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"d20" withExtension:@"gif"];
    NSData *data = [NSData dataWithContentsOfURL:url];
    FLAnimatedImage *image = [FLAnimatedImage animatedImageWithGIFData:data];
    FLAnimatedImageView *imageView = [[FLAnimatedImageView alloc] init];
    imageView.animatedImage = image;
    imageView.frame = CGRectMake(x, y, 100.0, 100.0);
    [self.view addSubview:imageView];
}

-(void) hidePlayer1
{
    self.life1.hidden = YES;
    self.commander1.hidden = YES;
    self.poison1.hidden = YES;
    self.lifePlus1.hidden = YES;
    self.lifeMinus1.hidden = YES;
    self.poisonPlus1.hidden = YES;
    self.poisonMinus1.hidden = YES;
    self.commanderPlus1.hidden = YES;
    self.commanderMinus1.hidden = YES;
}

-(void) hidePlayer2
{
    self.life2.hidden = YES;
    self.commander2.hidden = YES;
    self.poison2.hidden = YES;
    self.lifePlus2.hidden = YES;
    self.lifeMinus2.hidden = YES;
    self.poisonPlus2.hidden = YES;
    self.poisonMinus2.hidden = YES;
    self.commanderPlus2.hidden = YES;
    self.commanderMinus2.hidden = YES;
}

-(void) hidePlayer3
{
    self.life3.hidden = YES;
    self.commander3.hidden = YES;
    self.poison3.hidden = YES;
    self.lifePlus3.hidden = YES;
    self.lifeMinus3.hidden = YES;
    self.poisonPlus3.hidden = YES;
    self.poisonMinus3.hidden = YES;
    self.commanderPlus3.hidden = YES;
    self.commanderMinus3.hidden = YES;
}

-(void) hidePlayer4
{
    self.life4.hidden = YES;
    self.commander4.hidden = YES;
    self.poison4.hidden = YES;
    self.lifePlus4.hidden = YES;
    self.lifeMinus4.hidden = YES;
    self.poisonPlus4.hidden = YES;
    self.poisonMinus4.hidden = YES;
    self.commanderPlus4.hidden = YES;
    self.commanderMinus4.hidden = YES;
}


-(void) showPlayer1
{
    self.life1.hidden = NO;
    self.commander1.hidden = NO;
    self.poison1.hidden = NO;
    self.lifePlus1.hidden = NO;
    self.lifeMinus1.hidden = NO;
    self.poisonPlus1.hidden = NO;
    self.poisonMinus1.hidden = NO;
    self.commanderPlus1.hidden = NO;
    self.commanderMinus1.hidden = NO;
}

-(void) showPlayer2
{
    self.life2.hidden = NO;
    self.commander2.hidden = NO;
    self.poison2.hidden = NO;
    self.lifePlus2.hidden = NO;
    self.lifeMinus2.hidden = NO;
    self.poisonPlus2.hidden = NO;
    self.poisonMinus2.hidden = NO;
    self.commanderPlus2.hidden = NO;
    self.commanderMinus2.hidden = NO;
}

-(void) showPlayer3
{
    self.life3.hidden = NO;
    self.commander3.hidden = NO;
    self.poison3.hidden = NO;
    self.lifePlus3.hidden = NO;
    self.lifeMinus3.hidden = NO;
    self.poisonPlus3.hidden = NO;
    self.poisonMinus3.hidden = NO;
    self.commanderPlus3.hidden = NO;
    self.commanderMinus3.hidden = NO;
}

-(void) showPlayer4
{
    self.life4.hidden = NO;
    self.commander4.hidden = NO;
    self.poison4.hidden = NO;
    self.lifePlus4.hidden = NO;
    self.lifeMinus4.hidden = NO;
    self.poisonPlus4.hidden = NO;
    self.poisonMinus4.hidden = NO;
    self.commanderPlus4.hidden = NO;
    self.commanderMinus4.hidden = NO;
}

-(void) hideEverything
{
    self.finishGame.hidden = YES;
    if (self.players == 2)
    {
        [self hidePlayer1];
        [self hidePlayer2];
    }
    else if (self.players == 3)
    {
        [self hidePlayer1];
        [self hidePlayer2];
        [self hidePlayer3];
    }
    else if (self.players == 4)
    {
        [self hidePlayer1];
        [self hidePlayer2];
        [self hidePlayer3];
        [self hidePlayer4];
    }
}

-(void) showEverything
{
    self.finishGame.hidden = NO;
    if (self.players == 2)
    {
        [self showPlayer1];
        [self showPlayer2];
    }
    else if (self.players == 3)
    {
        [self showPlayer1];
        [self showPlayer2];
        [self showPlayer3];
    }
    else if (self.players == 4)
    {
        [self showPlayer1];
        [self showPlayer2];
        [self showPlayer3];
        [self showPlayer4];
    }
}

-(void) rollDice
{
    // get the phone width and phone height of the device we're using
    CGFloat phoneWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat phoneHeight = [UIScreen mainScreen].bounds.size.height;
    //self.finishGame.enabled = NO;
    [self hideEverything];
    if (self.players == 1)
    {
        // do nothing
    }
    else if (self.players == 2)
    {
        UIView* view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, phoneWidth, phoneHeight/2)];
        view.backgroundColor = [UIColor cyanColor];
        
        view.layer.cornerRadius = 15;
        view.clipsToBounds = true;
        view.layer.borderWidth = 5.0;
        view.layer.borderColor = [[UIColor blackColor] CGColor];
        
        [self.view addSubview:view];
        
        UIView* view2 = [[UIView alloc] initWithFrame:CGRectMake(0, phoneHeight/2, phoneWidth, phoneHeight/2)];
        view2.backgroundColor = [UIColor blueColor];
        
        view2.layer.cornerRadius = 15;
        view2.clipsToBounds = true;
        view2.layer.borderWidth = 5.0;
        view2.layer.borderColor = [[UIColor blackColor] CGColor];
        
        [self.view addSubview:view2];
        
        NSURL *url = [[NSBundle mainBundle] URLForResource:@"d20" withExtension:@"gif"];
        NSData *data = [NSData dataWithContentsOfURL:url];
        FLAnimatedImage *image = [FLAnimatedImage animatedImageWithGIFData:data];
        FLAnimatedImageView *imageView1 = [[FLAnimatedImageView alloc] init];
        imageView1.animatedImage = image;
        imageView1.frame = CGRectMake(phoneWidth/4+45, phoneHeight/4-75, 100.0, 100.0);
        [self.view addSubview:imageView1];
        
        FLAnimatedImageView *imageView2 = [[FLAnimatedImageView alloc] init];
        imageView2.animatedImage = image;
        imageView2.frame = CGRectMake(phoneWidth/4+45, phoneHeight-185, 100.0, 100.0);
        [self.view addSubview:imageView2];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            imageView1.hidden = YES;
            imageView2.hidden = YES;
            int random1 = arc4random_uniform(20);
            int random2 = arc4random_uniform(20);
            int winner = MAX(random1,random2);
            UILabel* winnerLabel;
            UILabel* loserLabel;
            if (random1 == winner)
            {
                winnerLabel = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4-100, phoneHeight/4-200, 400, 400)];
                winnerLabel.text = [NSString stringWithFormat:@"%d\nWINNER!",random1];
                winnerLabel.numberOfLines = 3;
                winnerLabel.textAlignment = NSTextAlignmentCenter;
                winnerLabel.textColor = [UIColor whiteColor];
                winnerLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                winnerLabel.transform = CGAffineTransformMakeRotation(M_PI_2*2);
                [self.view addSubview:winnerLabel];
                
                loserLabel = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4+45, phoneHeight-200, 100, 100)];
                loserLabel.text = [NSString stringWithFormat:@"%d",random2];
                loserLabel.textAlignment = NSTextAlignmentCenter;
                loserLabel.textColor = [UIColor whiteColor];
                loserLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                [self.view addSubview:loserLabel];
                
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                    winnerLabel.hidden = YES;
                    loserLabel.hidden = YES;
                    [view removeFromSuperview];
                    [view2 removeFromSuperview];
                    [self showEverything];
                });
            }
            else
            {
                loserLabel = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4+45, phoneHeight/4-90, 100, 100)];
                loserLabel.text = [NSString stringWithFormat:@"%d",random1];
                loserLabel.textAlignment = NSTextAlignmentCenter;
                loserLabel.textColor = [UIColor whiteColor];
                loserLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel.transform = CGAffineTransformMakeRotation(M_PI_2*2);
                [self.view addSubview:loserLabel];
                
                winnerLabel = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4-105, phoneHeight/4+120, 400, 400)];
                winnerLabel.text = [NSString stringWithFormat:@"%d\nWINNER!",random2];
                winnerLabel.numberOfLines = 3;
                winnerLabel.textAlignment = NSTextAlignmentCenter;
                winnerLabel.textColor = [UIColor whiteColor];
                winnerLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                [self.view addSubview:winnerLabel];
                
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                    winnerLabel.hidden = YES;
                    loserLabel.hidden = YES;
                    [view removeFromSuperview];
                    [view2 removeFromSuperview];
                    [self showEverything];
                });
            }
        });
    }
    else if (self.players == 3)
    {
        // player 1 setup
        UIView* view1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, phoneWidth/2, phoneHeight/2+60)];
        view1.backgroundColor = [UIColor cyanColor];
        view1.layer.cornerRadius = 15;
        view1.clipsToBounds = true;
        view1.layer.borderWidth = 5.0;
        view1.layer.borderColor = [[UIColor blackColor] CGColor];
        
        [self.view addSubview:view1];
        
        // player 2 setup
        UIView* view2 = [[UIView alloc] initWithFrame:CGRectMake(phoneWidth/2, 0, phoneWidth/2, phoneHeight/2+60)];
        view2.backgroundColor = [UIColor greenColor];
        view2.layer.cornerRadius = 15;
        view2.clipsToBounds = true;
        view2.layer.borderWidth = 5.0;
        view2.layer.borderColor = [[UIColor blackColor] CGColor];
        
        [self.view addSubview:view2];
        
        // player 3 setup
        UIView* view3 = [[UIView alloc] initWithFrame:CGRectMake(0, phoneHeight/2+60, phoneWidth, phoneHeight/2-60)];
        view3.backgroundColor = [UIColor yellowColor];
        view3.layer.cornerRadius = 15;
        view3.clipsToBounds = true;
        view3.layer.borderWidth = 5.0;
        view3.layer.borderColor = [[UIColor blackColor] CGColor];
        
        [self.view addSubview:view3];
        
        NSURL *url = [[NSBundle mainBundle] URLForResource:@"d20" withExtension:@"gif"];
        NSData *data = [NSData dataWithContentsOfURL:url];
        FLAnimatedImage *image = [FLAnimatedImage animatedImageWithGIFData:data];
        
        FLAnimatedImageView *imageView1 = [[FLAnimatedImageView alloc] init];
        imageView1.animatedImage = image;
        imageView1.frame = CGRectMake(phoneWidth/4-40, phoneHeight/4-10, 80,80);
        [self.view addSubview:imageView1];
        
        FLAnimatedImageView *imageView2 = [[FLAnimatedImageView alloc] init];
        imageView2.animatedImage = image;
        imageView2.frame = CGRectMake(phoneWidth/4+150, phoneHeight/4-10, 80, 80);
        [self.view addSubview:imageView2];
        
        FLAnimatedImageView *imageView3 = [[FLAnimatedImageView alloc] init];
        imageView3.animatedImage = image;
        imageView3.frame = CGRectMake(phoneWidth/2-40, phoneHeight/2+150, 80, 80);
        [self.view addSubview:imageView3];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            imageView1.hidden = YES;
            imageView2.hidden = YES;
            imageView3.hidden = YES;
            int random1 = arc4random_uniform(20);
            int random2 = arc4random_uniform(20);
            int random3 = arc4random_uniform(20);
            int firstWinner = MAX(random1, random2);
            int winner = MAX(firstWinner,random3);
            UILabel* winnerLabel;
            UILabel* loserLabel1;
            UILabel* loserLabel2;
            
            // player 1 is the winner
            if (random1 == winner)
            {
                // winner label at player 1
                winnerLabel = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4-140, phoneHeight/4-100, 250, 250)];
                winnerLabel.text = [NSString stringWithFormat:@"%d\nWINNER!",random1];
                winnerLabel.numberOfLines = 3;
                winnerLabel.textAlignment = NSTextAlignmentCenter;
                winnerLabel.textColor = [UIColor whiteColor];
                winnerLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                winnerLabel.transform = CGAffineTransformMakeRotation(M_PI_2);
                [self.view addSubview:winnerLabel];
                
                // loser label at player 2
                loserLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4+135, phoneHeight-535, 100, 100)];
                loserLabel1.text = [NSString stringWithFormat:@"%d",random2];
                loserLabel1.textAlignment = NSTextAlignmentCenter;
                loserLabel1.textColor = [UIColor whiteColor];
                loserLabel1.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel1.transform = CGAffineTransformMakeRotation(M_PI_2*3);
                [self.view addSubview:loserLabel1];
                
                // loser label at player 3
                loserLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/2-50, phoneHeight-200, 100, 100)];
                loserLabel2.text = [NSString stringWithFormat:@"%d",random3];
                loserLabel2.textAlignment = NSTextAlignmentCenter;
                loserLabel2.textColor = [UIColor whiteColor];
                loserLabel2.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                [self.view addSubview:loserLabel2];
                
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                    winnerLabel.hidden = YES;
                    loserLabel1.hidden = YES;
                    loserLabel2.hidden = YES;
                    [view1 removeFromSuperview];
                    [view2 removeFromSuperview];
                    [view3 removeFromSuperview];
                    [self showEverything];
                });
            }
            // player 2 is the winner
            else if (random2 == winner)
            {
                // display loser label at player 1
                loserLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4-50, phoneHeight-540, 100, 100)];
                loserLabel1.text = [NSString stringWithFormat:@"%d",random1];
                loserLabel1.textAlignment = NSTextAlignmentCenter;
                loserLabel1.textColor = [UIColor whiteColor];
                loserLabel1.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel1.transform = CGAffineTransformMakeRotation(M_PI_2);
                [self.view addSubview:loserLabel1];
                
                // display winner label at player 2
                winnerLabel = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4+55, phoneHeight-600, 250, 250)];
                winnerLabel.text = [NSString stringWithFormat:@"%d\nWINNER!",random2];
                winnerLabel.numberOfLines = 3;
                winnerLabel.textAlignment = NSTextAlignmentCenter;
                winnerLabel.textColor = [UIColor whiteColor];
                winnerLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                winnerLabel.transform = CGAffineTransformMakeRotation(M_PI_2*3);
                [self.view addSubview:winnerLabel];
                
                // display loser label at player 3
                loserLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/2-50, phoneHeight-200, 100, 100)];
                loserLabel2.text = [NSString stringWithFormat:@"%d",random3];
                loserLabel2.textAlignment = NSTextAlignmentCenter;
                loserLabel2.textColor = [UIColor whiteColor];
                loserLabel2.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                [self.view addSubview:loserLabel2];
                
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                    winnerLabel.hidden = YES;
                    loserLabel1.hidden = YES;
                    loserLabel2.hidden = YES;
                    [view1 removeFromSuperview];
                    [view2 removeFromSuperview];
                    [view3 removeFromSuperview];
                    [self showEverything];
                });
            }
            // player 3 is the winner
            else
            {
                // put the loser label on player 1
                loserLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4-50, phoneHeight-540, 100, 100)];
                loserLabel1.text = [NSString stringWithFormat:@"%d",random1];
                loserLabel1.textAlignment = NSTextAlignmentCenter;
                loserLabel1.textColor = [UIColor whiteColor];
                loserLabel1.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel1.transform = CGAffineTransformMakeRotation(M_PI_2);
                [self.view addSubview:loserLabel1];
                
                // put the loser label on player 2
                loserLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4+135, phoneHeight-535, 100, 100)];
                loserLabel2.text = [NSString stringWithFormat:@"%d",random2];
                loserLabel2.textAlignment = NSTextAlignmentCenter;
                loserLabel2.textColor = [UIColor whiteColor];
                loserLabel2.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
                [self.view addSubview:loserLabel2];
                
                // put the winner label on player 3
                winnerLabel = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/2-125, phoneHeight-280, 250, 250)];
                winnerLabel.text = [NSString stringWithFormat:@"%d\nWINNER!",random3];
                winnerLabel.numberOfLines = 3;
                winnerLabel.textAlignment = NSTextAlignmentCenter;
                winnerLabel.textColor = [UIColor whiteColor];
                winnerLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                [self.view addSubview:winnerLabel];
                
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                    winnerLabel.hidden = YES;
                    loserLabel1.hidden = YES;
                    loserLabel2.hidden = YES;
                    [view1 removeFromSuperview];
                    [view2 removeFromSuperview];
                    [view3 removeFromSuperview];
                    [self showEverything];
                });
            }
        });
    }
    else
    {
        // player 1 view
        UIView* view1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, phoneWidth/2, phoneHeight/2)];
        view1.backgroundColor = [UIColor cyanColor];
        view1.layer.cornerRadius = 15;
        view1.clipsToBounds = true;
        view1.layer.borderWidth = 5.0;
        view1.layer.borderColor = [[UIColor blackColor] CGColor];
        [self.view addSubview:view1];
        
        UIView* view2 = [[UIView alloc] initWithFrame:CGRectMake(phoneWidth/2, 0, phoneWidth/2, phoneHeight/2)];
        view2.backgroundColor = [UIColor greenColor];
        view2.layer.cornerRadius = 15;
        view2.clipsToBounds = true;
        view2.layer.borderWidth = 5.0;
        view2.layer.borderColor = [[UIColor blackColor] CGColor];
        [self.view addSubview:view2];
        
        UIView* view3 = [[UIView alloc] initWithFrame:CGRectMake(0, phoneHeight/2, phoneWidth/2, phoneHeight/2)];
        view3.backgroundColor = [UIColor purpleColor];
        view3.layer.cornerRadius = 15;
        view3.clipsToBounds = true;
        view3.layer.borderWidth = 5.0;
        view3.layer.borderColor = [[UIColor blackColor] CGColor];
        [self.view addSubview:view3];
        
        UIView* view4 = [[UIView alloc] initWithFrame:CGRectMake(phoneWidth/2, phoneHeight/2, phoneWidth/2, phoneHeight/2)];
        view4.backgroundColor = [UIColor grayColor];
        view4.layer.cornerRadius = 15;
        view4.clipsToBounds = true;
        view4.layer.borderWidth = 5.0;
        view4.layer.borderColor = [[UIColor blackColor] CGColor];
        [self.view addSubview:view4];
        
        NSURL *url = [[NSBundle mainBundle] URLForResource:@"d20" withExtension:@"gif"];
        NSData *data = [NSData dataWithContentsOfURL:url];
        FLAnimatedImage *image = [FLAnimatedImage animatedImageWithGIFData:data];
        
        FLAnimatedImageView *imageView1 = [[FLAnimatedImageView alloc] init];
        imageView1.animatedImage = image;
        imageView1.frame = CGRectMake(phoneWidth/4-35, phoneHeight/4-40, 75, 75);
        [self.view addSubview:imageView1];
        
        FLAnimatedImageView *imageView2 = [[FLAnimatedImageView alloc] init];
        imageView2.animatedImage = image;
        imageView2.frame = CGRectMake(phoneWidth/2+55, phoneHeight/4-40, 75, 75);
        [self.view addSubview:imageView2];
        
        FLAnimatedImageView *imageView3 = [[FLAnimatedImageView alloc] init];
        imageView3.animatedImage = image;
        imageView3.frame = CGRectMake(phoneWidth/4-35, phoneHeight-210, 75, 75);
        [self.view addSubview:imageView3];
        
        FLAnimatedImageView *imageView4 = [[FLAnimatedImageView alloc] init];
        imageView4.animatedImage = image;
        imageView4.frame = CGRectMake(phoneWidth/2+55, phoneHeight-210, 75, 75);
        [self.view addSubview:imageView4];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            imageView1.hidden = YES;
            imageView2.hidden = YES;
            imageView3.hidden = YES;
            imageView4.hidden = YES;
            int random1 = arc4random_uniform(20);
            int random2 = arc4random_uniform(20);
            int random3 = arc4random_uniform(20);
            int random4 = arc4random_uniform(20);
            int firstWinner = MAX(random1, random2);
            int secondWinner = MAX(random3,random4);
            int winner = MAX(firstWinner,secondWinner);
            UILabel* winnerLabel;
            UILabel* loserLabel1;
            UILabel* loserLabel2;
            UILabel* loserLabel3;
            
            // player 1 is the winner
            if (random1 == winner)
            {
                winnerLabel = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4-130, phoneHeight/4-125, 250, 250)];
                winnerLabel.text = [NSString stringWithFormat:@"%d\nWINNER!",random1];
                winnerLabel.numberOfLines = 3;
                winnerLabel.textAlignment = NSTextAlignmentCenter;
                winnerLabel.textColor = [UIColor whiteColor];
                winnerLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                winnerLabel.transform = CGAffineTransformMakeRotation(M_PI_2);
                [self.view addSubview:winnerLabel];
                
                loserLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4+135, phoneHeight-540, 100, 100)];
                loserLabel1.text = [NSString stringWithFormat:@"%d",random2];
                loserLabel1.textAlignment = NSTextAlignmentCenter;
                loserLabel1.textColor = [UIColor whiteColor];
                loserLabel1.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel1.transform = CGAffineTransformMakeRotation(M_PI_2*3);
                [self.view addSubview:loserLabel1];
                
                loserLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4-50, phoneHeight-220, 100, 100)];
                loserLabel2.text = [NSString stringWithFormat:@"%d",random3];
                loserLabel2.textAlignment = NSTextAlignmentCenter;
                loserLabel2.textColor = [UIColor whiteColor];
                loserLabel2.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel2.transform = CGAffineTransformMakeRotation(M_PI_2);
                [self.view addSubview:loserLabel2];
                
                loserLabel3 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4+140, phoneHeight-220, 100, 100)];
                loserLabel3.text = [NSString stringWithFormat:@"%d",random4];
                loserLabel3.textAlignment = NSTextAlignmentCenter;
                loserLabel3.textColor = [UIColor whiteColor];
                loserLabel3.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel3.transform = CGAffineTransformMakeRotation(M_PI_2*3);
                [self.view addSubview:loserLabel3];
                
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                    winnerLabel.hidden = YES;
                    loserLabel1.hidden = YES;
                    loserLabel2.hidden = YES;
                    loserLabel3.hidden = YES;
                    [view1 removeFromSuperview];
                    [view2 removeFromSuperview];
                    [view3 removeFromSuperview];
                    [view4 removeFromSuperview];
                    [self showEverything];
                });
            }
            // player 2 is the winner
            else if (random2 == winner)
            {
                loserLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4-50, phoneHeight-540, 100, 100)];
                loserLabel1.text = [NSString stringWithFormat:@"%d",random1];
                loserLabel1.textAlignment = NSTextAlignmentCenter;
                loserLabel1.textColor = [UIColor whiteColor];
                loserLabel1.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel1.transform = CGAffineTransformMakeRotation(M_PI_2);
                [self.view addSubview:loserLabel1];
                
                winnerLabel = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/2-35, phoneHeight/4-125, 250, 250)];
                winnerLabel.text = [NSString stringWithFormat:@"%d\nWINNER!",random2];
                winnerLabel.numberOfLines = 3;
                winnerLabel.textAlignment = NSTextAlignmentCenter;
                winnerLabel.textColor = [UIColor whiteColor];
                winnerLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                winnerLabel.transform = CGAffineTransformMakeRotation(M_PI_2*3);
                [self.view addSubview:winnerLabel];
                
                loserLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4-50, phoneHeight-220, 100, 100)];
                loserLabel2.text = [NSString stringWithFormat:@"%d",random3];
                loserLabel2.textAlignment = NSTextAlignmentCenter;
                loserLabel2.textColor = [UIColor whiteColor];
                loserLabel2.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel2.transform = CGAffineTransformMakeRotation(M_PI_2);
                [self.view addSubview:loserLabel2];
                
                loserLabel3 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4+140, phoneHeight-220, 100, 100)];
                loserLabel3.text = [NSString stringWithFormat:@"%d",random4];
                loserLabel3.textAlignment = NSTextAlignmentCenter;
                loserLabel3.textColor = [UIColor whiteColor];
                loserLabel3.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel3.transform = CGAffineTransformMakeRotation(M_PI_2*3);
                [self.view addSubview:loserLabel3];
                
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                    winnerLabel.hidden = YES;
                    loserLabel1.hidden = YES;
                    loserLabel2.hidden = YES;
                    loserLabel3.hidden = YES;
                    [view1 removeFromSuperview];
                    [view2 removeFromSuperview];
                    [view3 removeFromSuperview];
                    [view4 removeFromSuperview];
                    [self showEverything];
                });
            }
            // player 3 is the winner
            else if (random3 == winner)
            {
                loserLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4-50, phoneHeight-540, 100, 100)];
                loserLabel1.text = [NSString stringWithFormat:@"%d",random1];
                loserLabel1.textAlignment = NSTextAlignmentCenter;
                loserLabel1.textColor = [UIColor whiteColor];
                loserLabel1.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel1.transform = CGAffineTransformMakeRotation(M_PI_2);
                [self.view addSubview:loserLabel1];
                
                loserLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4+135, phoneHeight-540, 100, 100)];
                loserLabel2.text = [NSString stringWithFormat:@"%d",random2];
                loserLabel2.textAlignment = NSTextAlignmentCenter;
                loserLabel2.textColor = [UIColor whiteColor];
                loserLabel2.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
                [self.view addSubview:loserLabel2];
                
                winnerLabel = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4-130, phoneHeight-300, 250, 250)];
                winnerLabel.text = [NSString stringWithFormat:@"%d\nWINNER!",random3];
                winnerLabel.numberOfLines = 3;
                winnerLabel.textAlignment = NSTextAlignmentCenter;
                winnerLabel.textColor = [UIColor whiteColor];
                winnerLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                winnerLabel.transform = CGAffineTransformMakeRotation(M_PI_2);
                [self.view addSubview:winnerLabel];
                
                loserLabel3 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4+140, phoneHeight-220, 100, 100)];
                loserLabel3.text = [NSString stringWithFormat:@"%d",random4];
                loserLabel3.textAlignment = NSTextAlignmentCenter;
                loserLabel3.textColor = [UIColor whiteColor];
                loserLabel3.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel3.transform = CGAffineTransformMakeRotation(M_PI_2*3);
                [self.view addSubview:loserLabel3];
                
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                    winnerLabel.hidden = YES;
                    loserLabel1.hidden = YES;
                    loserLabel2.hidden = YES;
                    loserLabel3.hidden = YES;
                    [view1 removeFromSuperview];
                    [view2 removeFromSuperview];
                    [view3 removeFromSuperview];
                    [view4 removeFromSuperview];
                    [self showEverything];
                });
            }
            else
            {
                loserLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4-50, phoneHeight-540, 100, 100)];
                loserLabel1.text = [NSString stringWithFormat:@"%d",random1];
                loserLabel1.textAlignment = NSTextAlignmentCenter;
                loserLabel1.textColor = [UIColor whiteColor];
                loserLabel1.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel1.transform = CGAffineTransformMakeRotation(M_PI_2);
                [self.view addSubview:loserLabel1];
                
                loserLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4+135, phoneHeight-540, 100, 100)];
                loserLabel2.text = [NSString stringWithFormat:@"%d",random2];
                loserLabel2.textAlignment = NSTextAlignmentCenter;
                loserLabel2.textColor = [UIColor whiteColor];
                loserLabel2.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel2.transform = CGAffineTransformMakeRotation(M_PI_2*3);
                [self.view addSubview:loserLabel2];
                
                loserLabel3 = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/4-50, phoneHeight-220, 100, 100)];
                loserLabel3.text = [NSString stringWithFormat:@"%d",random3];
                loserLabel3.textAlignment = NSTextAlignmentCenter;
                loserLabel3.textColor = [UIColor whiteColor];
                loserLabel3.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                loserLabel3.transform = CGAffineTransformMakeRotation(M_PI_2);
                [self.view addSubview:loserLabel3];
                
                winnerLabel = [[UILabel alloc] initWithFrame:CGRectMake(phoneWidth/2-35, phoneHeight-300, 250, 250)];
                winnerLabel.text = [NSString stringWithFormat:@"%d\nWINNER!",random4];
                winnerLabel.numberOfLines = 3;
                winnerLabel.textAlignment = NSTextAlignmentCenter;
                winnerLabel.textColor = [UIColor whiteColor];
                winnerLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:70];
                winnerLabel.transform = CGAffineTransformMakeRotation(M_PI_2*3);
                [self.view addSubview:winnerLabel];
                
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                    winnerLabel.hidden = YES;
                    loserLabel1.hidden = YES;
                    loserLabel2.hidden = YES;
                    loserLabel3.hidden = YES;
                    [view1 removeFromSuperview];
                    [view2 removeFromSuperview];
                    [view3 removeFromSuperview];
                    [view4 removeFromSuperview];
                    [self showEverything];
                });
            }
        });
    }
}

// functiom called when the game finishes
- (IBAction)finishGame:(id)sender {
    // create the alert
    UIAlertController * alert = [UIAlertController
                                 alertControllerWithTitle:@"Main Menu"
                                 message:@"Select from the options below"
                                 preferredStyle:UIAlertControllerStyleAlert];
    // create an end game action
    UIAlertAction* endGameButton = [UIAlertAction
                                actionWithTitle:@"End Game"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action) {
                                    // create a subalert
                                    UIAlertController * iMessage = [UIAlertController
                                                                 alertControllerWithTitle:@"Thanks for playing!"
                                                                 message:@"You can share the results if you'd like."
                                                                 preferredStyle:UIAlertControllerStyleAlert];
                                    // send via imessage subaction
                                    UIAlertAction* share = [UIAlertAction
                                                                    actionWithTitle:@"Send via iMessage"
                                                                    style:UIAlertActionStyleDefault
                                                                    handler:^(UIAlertAction * action) {
                                                                        if([MFMessageComposeViewController canSendText]) {
                                                                            MFMessageComposeViewController *messageController = [[MFMessageComposeViewController alloc] init]; // Create message VC
                                                                            messageController.messageComposeDelegate = self; // Set delegate to current instance
                                                                            messageController.body = [self constructMessage]; // Set initial text to example message
                                                                            dispatch_async(dispatch_get_main_queue(), ^{ // Present VC when possible
                                                                                [self presentViewController:messageController animated:YES completion:NULL];
                                                                            });
                                                                        }
                                                                    }];
                                    // cancel subaction
                                    UIAlertAction* end = [UIAlertAction
                                                            actionWithTitle:@"Not now"
                                                            style:UIAlertActionStyleDefault
                                                            handler:^(UIAlertAction * action) {
                                                                [self performSegueWithIdentifier:@"unwind" sender:self];
                                                                [self dismissViewControllerAnimated:YES completion:nil];
                                                            }];
                                    // add the actions
                                    [iMessage addAction:share];
                                    [iMessage addAction:end];
                                    [self presentViewController:iMessage animated:YES completion:nil];
                                
                                }];
    // restart game action
    UIAlertAction* restartButton = [UIAlertAction
                               actionWithTitle:@"Reset Game"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction * action) {
                                   [self resetGame];
                               }];
    
    // cancel action
    UIAlertAction* cancelButton = [UIAlertAction
                               actionWithTitle:@"Cancel"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction * action) {
                               }];
    
    // don't offer to roll the dice if you only have one player
    if (self.players > 1)
    {
        UIAlertAction* rollDice = [UIAlertAction
                                   actionWithTitle:@"Roll Dice"
                                   style:UIAlertActionStyleDefault
                                   handler:^(UIAlertAction * action) {
                                       [self rollDice];
                                   }];
        [alert addAction:rollDice];
    }

    // add the actions
    [alert addAction:endGameButton];
    [alert addAction:restartButton];
    [alert addAction:cancelButton];
    [self presentViewController:alert animated:YES completion:nil];
}


@end
