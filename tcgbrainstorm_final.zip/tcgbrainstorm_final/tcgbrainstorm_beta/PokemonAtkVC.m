//
//  PokemonAtkVC.m
//  tcgbrainstorm_beta
//
//  Created by Matt Guarneri on 4/5/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "PokemonAtkVC.h"
#import "PokeFinalVC.h"
#import <AVFoundation/AVFoundation.h>


int attack1cost=-1;
int attack2cost=-1;
@interface PokemonAtkVC ()
@property (weak, nonatomic) IBOutlet UITextField *costBox1;//attack cost
@property (weak, nonatomic) IBOutlet UITextField *costBox2;
@property (weak, nonatomic) IBOutlet UITextField *attack1NameBox;
@property (weak, nonatomic) IBOutlet UITextField *attack1DamageBox;
@property (weak, nonatomic) IBOutlet UITextField *attack1Description;
@property (weak, nonatomic) IBOutlet UITextField *attack2NameBox;
@property (weak, nonatomic) IBOutlet UITextField *attack2DamageBox;
@property (weak, nonatomic) IBOutlet UITextField *attack2DescriptionBox;
@property (weak, nonatomic) IBOutlet UIButton *next;//next button
@property (strong,nonatomic) AVAudioPlayer *audioPlayer;
//display one of these warnings if respective text too long :)
@property (weak, nonatomic) IBOutlet UILabel *namewarning;
@property (weak, nonatomic) IBOutlet UILabel *damagewarning;
@property (weak, nonatomic) IBOutlet UILabel *descriptionwarning;

@end


@implementation PokemonAtkVC
-(void)viewDidLoad{
    //set button size; instantiate fields with card object vars
    self.next.layer.cornerRadius = 15;
    self.next.clipsToBounds = true;
    self.next.layer.borderWidth = 1.0;
    self.next.layer.borderColor = [[UIColor blackColor] CGColor];
    
    self.attack1NameBox.text=self.card.atk1name;
    self.attack1DamageBox.text=self.card.atk1dmg;
    self.attack1Description.text=self.card.atk1desc;
    self.costBox1.text=self.card.atk1type;
    
    self.attack2NameBox.text=self.card.atk2name;
    self.attack2DamageBox.text=self.card.atk2dmg;
    self.attack2DescriptionBox.text=self.card.atk2desc;
    self.costBox2.text=self.card.atk2type;
    //hide warnings
    _namewarning.hidden=YES;
    _damagewarning.hidden=YES;
    _descriptionwarning.hidden=YES;
}
//Checks attakcDamage length and sets damage to it if ok
- (IBAction)attack1DamageChanged:(id)sender {
    if(self.attack1DamageBox.text.length>3){
        self.next.enabled=NO;
        self.damagewarning.hidden=NO;
    }else{
         _card.atk1dmg=_attack1DamageBox.text;
        self.next.enabled=YES;
        self.damagewarning.hidden=YES;
    }
}

//checks attack name length and sets card name to it if ol
- (IBAction)attack1NameChanged:(id)sender {
    if(self.attack1NameBox.text.length>13){
        self.next.enabled=NO;
        self.namewarning.hidden=NO;
    }else{
        _card.atk1name=_attack1NameBox.text;
        self.next.enabled=YES;
        self.namewarning.hidden=YES;
    }
}


//changes description
- (IBAction)attack1DescChange:(id)sender {
    if(self.attack1Description.text.length>117){
        self.next.enabled=NO;
        self.descriptionwarning.hidden=NO;
    }else{
        _card.atk1desc=_attack1Description.text;
        self.next.enabled=YES;
        self.descriptionwarning.hidden=YES;
    }
}
//Editing began on sender disables all other boxes and calls textFieldDid begin editing to scroll up screen and allow for keyboard input
- (IBAction)attack2Begin:(id)sender {
    [self textFieldDidBeginEditing: _attack2NameBox];
    _attack1NameBox.enabled=NO;
    _attack1DamageBox.enabled=NO;
    _attack1Description.enabled=NO;
    _attack2DamageBox.enabled=NO;
    _attack2DescriptionBox.enabled=NO;
}
//Set variable if underlength; else enable warning and lock next
- (IBAction)attack2NameChanged:(id)sender {
    if(self.attack2NameBox.text.length>13){
        self.next.enabled=NO;
        self.namewarning.hidden=NO;
    }else{
        self.next.enabled=YES;
        self.namewarning.hidden=YES;
         _card.atk2name=_attack2NameBox.text;
    }
    //disable to prevent autoscrolling  :)
    _attack1NameBox.enabled=YES;
    _attack1DamageBox.enabled=YES;
    _attack1Description.enabled=YES;
    _attack2DamageBox.enabled=YES;
    _attack2DescriptionBox.enabled=YES;
    [self textFieldDidEndEditing: _attack2NameBox];
}
//Set variable if underlength; else send warning and lock next
- (IBAction)attack2DamageChanged:(id)sender {
    if(self.attack2DamageBox.text.length>3){
        self.next.enabled=NO;
        self.damagewarning.hidden=NO;
    }else{
        _card.atk2dmg=_attack2DamageBox.text;
        self.next.enabled=YES;
        self.damagewarning.hidden=YES;
    }
    //diable to prevent autoscrolling
    _attack1NameBox.enabled=YES;
    _attack1DamageBox.enabled=YES;
    _attack1Description.enabled=YES;
    _attack2NameBox.enabled=YES;
    _attack2DescriptionBox.enabled=YES;
    [self textFieldDidEndEditing: _attack2DamageBox];
}
//Editing began on sender disables all other boxes and calls textFieldDid begin editing to scroll up screen and allow for keyboard input
- (IBAction)attack2DamageBegan:(id)sender {
    [self textFieldDidBeginEditing: _attack2DamageBox];
    _attack1NameBox.enabled=NO;
    _attack1DamageBox.enabled=NO;
    _attack1Description.enabled=NO;
    _attack2NameBox.enabled=NO;
    _attack2DescriptionBox.enabled=NO;
}

- (IBAction)attack2Description:(id)sender {
    if(self.attack2DescriptionBox.text.length>117){
        self.next.enabled=NO;
        self.descriptionwarning.hidden=NO;
    }else{
        _card.atk2desc=_attack2DescriptionBox.text;
        self.next.enabled=YES;
        self.descriptionwarning.hidden=YES;
    }
    _attack1NameBox.enabled=YES;
    _attack1DamageBox.enabled=YES;
    _attack1Description.enabled=YES;
    _attack2NameBox.enabled=YES;
    _attack2DamageBox.enabled=YES;
    [self textFieldDidEndEditing: _attack2DescriptionBox];
}
- (IBAction)attack2DescriptionBegan:(id)sender {
    [self textFieldDidBeginEditing: _attack2DescriptionBox];
    _attack1NameBox.enabled=NO;
    _attack1DamageBox.enabled=NO;
    _attack1Description.enabled=NO;
    _attack2NameBox.enabled=NO;
    _attack2DamageBox.enabled=NO;
}

- (IBAction)backButtonPressed:(id)sender {
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"pokeBack" ofType:@"wav" ];
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    [self.audioPlayer play];
     [self dismissViewControllerAnimated:YES completion:nil];
}
//Sets to Nil and clears the text box
- (IBAction)clearAttack1:(id)sender {
    _card.atk1type=nil;
    _costBox1.text=@"";
}
- (IBAction)clearAttack2:(id)sender {
    _card.atk2type=nil;
    _costBox2.text=@"";
}

//Tis section involves a bunch of functions that are nearly indetical and are linked to the type buttons below each attack
//They set the cost of the of each attack; if there is already 4 costs we reset with latest

- (IBAction)fire1pressed:(id)sender {
    if(attack1cost==3){
        attack1cost=0;
        _costBox1.text=@"/f";
    }else{
        attack1cost++;
        _costBox1.text= [ _costBox1.text stringByAppendingString:@"/f"];
    }
    _card.atk1type=_costBox1.text;
}

- (IBAction)grass1pressed:(id)sender {
    if(attack1cost==3){
        attack1cost=0;
        _costBox1.text=@"/g";
    }else{
        attack1cost++;
        _costBox1.text= [ _costBox1.text stringByAppendingString:@"/g"];
    }
     _card.atk1type=_costBox1.text;
}
- (IBAction)water1pressed:(id)sender {
    if(attack1cost==3){
        attack1cost=0;
        _costBox1.text=@"/w";
    }else{
        attack1cost++;
        _costBox1.text= [ _costBox1.text stringByAppendingString:@"/w"];
    }
     _card.atk1type=_costBox1.text;
}
- (IBAction)psy1pressed:(id)sender {
    if(attack1cost==3){
        attack1cost=0;
        _costBox1.text=@"/p";
    }else{
        attack1cost++;
        _costBox1.text= [ _costBox1.text stringByAppendingString:@"/p"];
    }
     _card.atk1type=_costBox1.text;
}
- (IBAction)norm1pressed:(id)sender {
    if(attack1cost==3){
        attack1cost=0;
        _costBox1.text=@"/c";
    }else{
        attack1cost++;
        _costBox1.text= [ _costBox1.text stringByAppendingString:@"/c"];
    }
     _card.atk1type=_costBox1.text;
}
- (IBAction)fight1pressed:(id)sender {
    if(attack1cost==3){
        attack1cost=0;
        _costBox1.text=@"/r";
    }else{
        attack1cost++;
        _costBox1.text= [ _costBox1.text stringByAppendingString:@"/r"];
    }
     _card.atk1type=_costBox1.text;
}
- (IBAction)light1pressed:(id)sender {
    if(attack1cost==3){
        attack1cost=0;
        _costBox1.text=@"/l";
    }else{
        attack1cost++;
        _costBox1.text= [ _costBox1.text stringByAppendingString:@"/l"];
    }
     _card.atk1type=_costBox1.text;
}
- (IBAction)metal1pressed:(id)sender {
    if(attack1cost==3){
        attack1cost=0;
        _costBox1.text=@"/m";
    }else{
        attack1cost++;
        _costBox1.text= [ _costBox1.text stringByAppendingString:@"/m"];
    }
     _card.atk1type=_costBox1.text;
}
- (IBAction)dark1pressed:(id)sender {
    if(attack1cost==3){
        attack1cost=0;
        _costBox1.text=@"/d";
    }else{
        attack1cost++;
        _costBox1.text= [ _costBox1.text stringByAppendingString:@"/d"];
    }
     _card.atk1type=_costBox1.text;
}
- (IBAction)fire2pressed:(id)sender {
    if(attack2cost==3){
        attack2cost=0;
        _costBox2.text=@"/f";
    }else{
        attack2cost++;
        _costBox2.text= [ _costBox2.text stringByAppendingString:@"/f"];
    }
     _card.atk2type=_costBox2.text;
}
- (IBAction)grass2pressed:(id)sender {
    if(attack2cost==3){
        attack2cost=0;
        _costBox2.text=@"/g";
    }else{
        attack2cost++;
        _costBox2.text= [ _costBox2.text stringByAppendingString:@"/g"];
    }
    _card.atk2type=_costBox2.text;
}
- (IBAction)water2pressed:(id)sender {
    if(attack2cost==3){
        attack2cost=0;
        _costBox2.text=@"/w";
    }else{
        attack2cost++;
        _costBox2.text= [ _costBox2.text stringByAppendingString:@"/w"];
    }
    _card.atk2type=_costBox2.text;
}
- (IBAction)psy2pressed:(id)sender {
    if(attack2cost==3){
        attack2cost=0;
        _costBox2.text=@"/p";
    }else{
        attack2cost++;
        _costBox2.text= [ _costBox2.text stringByAppendingString:@"/p"];
    }
    _card.atk2type=_costBox2.text;
}
- (IBAction)norm2pressed:(id)sender {
    if(attack2cost==3){
        attack2cost=0;
        _costBox2.text=@"/c";
    }else{
        attack2cost++;
        _costBox2.text= [ _costBox2.text stringByAppendingString:@"/c"];
    }
    _card.atk2type=_costBox2.text;
}
- (IBAction)fight2pressed:(id)sender {
    if(attack2cost==3){
        attack2cost=0;
        _costBox2.text=@"/r";
    }else{
        attack2cost++;
        _costBox2.text= [ _costBox2.text stringByAppendingString:@"/r"];
    }
    _card.atk2type=_costBox2.text;
}
- (IBAction)light2pressed:(id)sender {
    if(attack2cost==3){
        attack2cost=0;
        _costBox2.text=@"/l";
    }else{
        attack2cost++;
        _costBox2.text= [ _costBox2.text stringByAppendingString:@"/l"];
    }
    _card.atk2type=_costBox2.text;
}
- (IBAction)metal2pressed:(id)sender {
    if(attack2cost==3){
        attack2cost=0;
        _costBox2.text=@"/m";
    }else{
        attack2cost++;
        _costBox2.text= [ _costBox2.text stringByAppendingString:@"/m"];
    }
    _card.atk2type=_costBox2.text;
}
- (IBAction)dark2pressed:(id)sender {
    if(attack2cost==3){
        attack2cost=0;
        _costBox2.text=@"/d";
    }else{
        attack2cost++;
        _costBox2.text= [ _costBox2.text stringByAppendingString:@"/d"];
    }
    _card.atk2type=_costBox2.text;
}

//Sent next VC card to this card
- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    PokeFinalVC* dest = [segue destinationViewController];
    dest.card = self.card;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self animateTextField:textField up:YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextField:textField up:NO];
}

-(void)animateTextField:(UITextField*)textField up:(BOOL)up
{
    const int movementDistance = -130; // tweak as needed
    const float movementDuration = 0.3f; // tweak as needed
    
    int movement = (up ? movementDistance : -movementDistance);
    
    [UIView beginAnimations: @"animateTextField" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}

- (IBAction)nextPressed:(id)sender {
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:@"pokeBeep" ofType:@"wav" ];
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    NSError *error;
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    [self.audioPlayer play];
}

@end

