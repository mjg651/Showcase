//
//  TCGPickerVC.m
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/4/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "TCGPickerVC.h"
#import <AVFoundation/AVFoundation.h>

@interface TCGPickerVC ()
@property (weak, nonatomic) IBOutlet UIButton *createCustomCard;
@property (weak, nonatomic) IBOutlet UIButton *lifeCounter;
@property (weak, nonatomic) IBOutlet UIButton *rules;
@property (strong,nonatomic) AVAudioPlayer *audioPlayer;

-(void)formatButton:(UIButton*) button;
@end

@implementation TCGPickerVC

// Format the buttons for this view
// Input: UIButton*
// Output: void
-(void)formatButton:(UIButton*) button
{
    // format the button properly
    button.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:25];
    // make it a rounded button
    button.layer.cornerRadius = 15;
    // clip it to the bounds
    button.clipsToBounds = true;
    // set the border width
    button.layer.borderWidth = 1.0;
    // set the border color
    button.layer.borderColor = [[UIColor blackColor] CGColor];
}

// Function to setup the view after it loads
- (void)viewDidLoad
{
    // call the superclass' viewDidLoad method
    [super viewDidLoad];
    // format each of the buttons on the page
    [self formatButton:self.createCustomCard];
    [self formatButton:self.lifeCounter];
    [self formatButton:self.rules];
}

// Function to play a sound depending on which button is pressed
// Input: NSString*, which is the resource to be played
// Output: void
-(void) playSound:(NSString*) resource
{
    // construct the audio path
    NSString *audioPath = [[NSBundle mainBundle] pathForResource:resource ofType:@"wav" ];
    // constrict the url from the audio path
    NSURL *audioURL = [NSURL fileURLWithPath:audioPath];
    // declare the error
    NSError *error;
    // instantiate the audio player object
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioURL error:&error];
    // play the sound
    [self.audioPlayer play];
}

// Function to play a sound and dismiss the view controller when pressed
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)backButtonPressed:(id)sender
{
    // play the cancel sound
    [self playSound:@"OOT_Cancel"];
    // dismiss view controller
    [self dismissViewControllerAnimated:YES completion:nil];
}

// Function to play sound when create custom card, life counter, or rules button button is pressed
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)createOrLifeOrRulesPressed:(id)sender
{
    [self playSound:@"OOT_MainMenu_Select"];
}

@end
