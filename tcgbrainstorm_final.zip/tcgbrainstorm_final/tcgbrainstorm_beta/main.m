//
//  main.m
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/4/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
