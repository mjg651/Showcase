//
//  MTGLifePickerVC.m
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/12/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "MTGLifePickerVC.h"

@interface MTGLifePickerVC ()
@end

@implementation MTGLifePickerVC

// Function to hide the status bar
// Input: void
// Output: BOOL
- (BOOL)prefersStatusBarHidden
{
    // hide the status bar
    return YES;
}

// Function to do any additional setup after loading the view.
- (void)viewDidLoad {
    // load the superclass
    [super viewDidLoad];
    
    // set the fonts for each of the buttons
    self.b0.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:50];
    self.b1.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:50];
    self.b2.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:50];
    self.b3.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:50];
    self.b4.titleLabel .font = [UIFont fontWithName:@"Matrix-Bold" size:50];
    self.b5.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:50];
    self.b6.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:50];
    self.b7.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:50];
    self.b8.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:50];
    self.b9.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:50];
    self.bClear.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:40];
    self.bContinue.titleLabel.font = [UIFont fontWithName:@"Matrix-Bold" size:40];
    self.lifeTotal.font = [UIFont fontWithName:@"Matrix-Bold" size:50];
}

// Function that sets the life total based on the user input
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)lifeTotalChanged:(id)sender
{
    // cast the sender to a UIButton object
    UIButton* button = (UIButton*) sender;
    // the maximum number of digits for the life total is 3
    if (self.lifeTotal.text.length < 3)
    {
        // if the life total right now is empty
        if ([self.lifeTotal.text isEqualToString:@"0"])
        {
            // set the life total text to the button pressed
            self.lifeTotal.text = [NSString stringWithFormat:@"%lu",button.tag];
            // set the life equal to the int value of the text
            self.life = [self.lifeTotal.text intValue];
        }
        // otherwise, the life total has something
        else
        {
                // append the button pressed to the current life total
                self.lifeTotal.text = [NSString stringWithFormat:@"%@%lu",self.lifeTotal.text,button.tag];
                // set the life equal to the int value of the text
                self.life = [self.lifeTotal.text intValue];
        }
    }
}

// Function to clear the life total
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)clear:(id)sender
{
    // set the life total text to 0
    self.lifeTotal.text = @"0";
}

// Function to dismiss the view controller when the back button is pressed
// Input: id, which is always UIButton*
// Output: IBAction
- (IBAction)backButtonPressed:(id)sender
{
    // dismiss the view controller
    [self dismissViewControllerAnimated:YES completion:nil];
}

// In a storyboard-based application, you will often want to do a little preparation before navigation
// Input: UIStoryboardSegue*, id (which is always of type UIButton*)
// Output: void
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // get the destination view controller
    MTGPlayerPickerVC* dest = [segue destinationViewController];
    // set the destination view controller's life variable equal to this view controller's life variable
    dest.life = self.life;
}

@end
