//
//  MagicCardInfoVC.h
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/5/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomMagicCard.h"
#import "MagicTypeVC.h"

NS_ASSUME_NONNULL_BEGIN

/*
 MagicCardInfoVC
 This class is the first VC in the sequence of creating the custom card. This is where the users can pick the image they want on the card, enter the name of the card, and pick the color of the card.
 For picking the image, we need to declare this VC as a UIImagePickerControllerDelegate.
 For moving the screen when we hit a text field, we need to declare this VC as a UINavigationControllerDelegate.
 */
@interface MagicCardInfoVC : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>

// the next button to move to the next view
@property (weak, nonatomic) IBOutlet UIButton* nextButton;

// declare the custom card object to hold the various properties as we move along views
@property (strong, nonatomic) CustomMagicCard* card;

// text field that will hold the name of the card, displaying it to the user
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;

// error is displayed if the name entered in the text field is too long (too many characters)
@property (weak, nonatomic) IBOutlet UILabel *nameTextFieldError;

// image view that will hold the chosen image for the card
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@end

NS_ASSUME_NONNULL_END
