//
//  MTGPlayerPickerVC.m
//  tcgbrainstorm_beta
//
//  Created by McKennah Genovese on 4/12/19.
//  Copyright © 2019 McKennah Genovese. All rights reserved.
//

#import "MTGPlayerPickerVC.h"

@interface MTGPlayerPickerVC ()

@end

@implementation MTGPlayerPickerVC

// Function to hide the status bar
// Input: void
// Output: BOOL
- (BOOL)prefersStatusBarHidden
{
    // hide the status bar
    return YES;
}

// Function to do additional setup after loading the view
- (void)viewDidLoad
{
    // call the superclass' viewDidLoad function
    [super viewDidLoad];
}

// In a storyboard-based application, you will often want to do a little preparation before navigation
// Input: UIStoryboardSegue*, id (which is always a UIButton*)
// Output: void
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // get the destination view controller
    MTGLifeCounterVC* dest = [segue destinationViewController];
    // if 1 player was picked, set the destination VC's number of players to 1
    if ([segue.identifier isEqualToString:@"1"])
        dest.players = 1;
    // if 2 players were picked, set the destination VC's number of players to 2
    else if ([segue.identifier isEqualToString:@"2"])
        dest.players = 2;
    // if 3 players were picked, set the destination VC's number of players to 3
    else if ([segue.identifier isEqualToString:@"3"])
        dest.players = 3;
    // if 4 players were picked, set the destination VC's number of players to 4
    else
        dest.players = 4;
    // set the destination view controller's life to this view controller's life
    dest.life = self.life;
}

// Function to dismiss the view controller when the back button was pressed
// Input: id, which is always of type UIButton*
// Output: IBAction
- (IBAction)backButtonPressed:(id)sender
{
    // dismiss the view controller
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
