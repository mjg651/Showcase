import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner; 

/*
 * This program implements a two pass linker.
 * It returns a symbol table with the absolute addresses of each variable
 * as well as a memory map that relocates changes addresses based on
 * the instructions given.
 * @author Matthew Guarneri
 * September 16, 2018 
 */

public class two_way_linker {

	public static void main(String [] args){
		Scanner in = new Scanner(System.in);

		ArrayList<String> symlist= new ArrayList<String>();// used to check what symbols are being used

		ArrayList<String> use= new ArrayList<String>();//line 2 of each module

		ArrayList<String> inst = new ArrayList<String>(); // line 3 of each module

		ArrayList<String> mem = new ArrayList<String>();// final memory map
		
		ArrayList<symbol> symbols = new ArrayList<symbol>();// arraylist of type symbols
		
		
		


		// first loop through
		int I=0;
		int[] base=null;
		try {
			int c2 =0;
			I = in.nextInt();
			base = new int [I+1];
			int ans = 0;//offset keep track of value
			base[0]=ans;// base address of first module is always 0
			for(int i=0; i<I;i++) {//loop through module
				int N = in.nextInt();//number of symbols in module
				for(int n=0;n<N;n++) {
					String sym = in.next();
					int rel = in.nextInt();
					int loc = rel+base[i];// location is relative + base address
					symbol new_sym = new symbol (sym,i,loc);//instantiate a new symbol
					new_sym.setRel(rel);
					if (symlist.contains(sym)) {//checks if a symbol was previously defined
						int s = symlist.indexOf(sym);
						symbols.get(s).setLoc(loc);
						symbols.get(s).setError("Error: This variable is multiply defined; last value used.");
					}if(!symlist.contains(sym)) {//add normally is symbol was already defined
						symlist.add(sym);
						symbols.add(new_sym);
					}
				}
				
				String line2="";
				
				int num_uses = in.nextInt();
				for(int l=0;l<num_uses;l++) {// for loop to add the second line of each module, stopping at each -1
					String use_L="";
					String add  = in.next();
					while (add.equals("-1")==false) {
						 use_L +=add+" ";
						 add=in.next();
					}
					line2 += use_L+"-1 ";
				}
				use.add(line2);
				int num_inst=in.nextInt();
				String line3=num_inst+" ";
				for(int j=0;j<num_inst;j++) {// for loop to add third line
					line3+=in.nextInt()+" ";
				}
				inst.add(line3);
				ans+=num_inst;
				base[i+1]=ans;//base address of next module
				int c1;
				for( c1 = c2;c1<symbols.size();c1++) {// check if the defintion is larger than the module size
					if(symbols.get(c1).relative>=num_inst) {
					   symbols.get(c1).setLoc(symbols.get(c1).location-1);
					   symbols.get(c1).setError("Error: Definition exceeds module size; last word in module used");
					}
				}
				c2=c1;
			}
		} catch (Exception e) {
		
			System.out.println("Error! Input format incorrect. Exiting.");
			System.exit(0);
		}
		
		//print out symbol table
		System.out.println("Symbol Table:");
		
		for(int x =0; x< symbols.size();x++) {
				symbol printSymbol=symbols.get(x);
				System.out.println(printSymbol.getSym()+" = "+ printSymbol.getLoc()+" "+printSymbol.getError());
			
		}
		

		
		//2nd loop
		for(int j=0;j<I;j++) {
			String instruct = inst.get(j);
			String[] split = instruct.split("\\s+");
			int num_inst = Integer.parseInt(split[0]);//number of instructions
			for(int k = 1;k<=num_inst;k++) {
				String fin = null;
				if(split[k].charAt(4)=='1') {//unchanged
					fin=(split[k].substring(0, 4));
				}else if(split[k].charAt(4)=='2') {//unchanged unless absolute address is exceeded
					fin=(split[k].substring(0, 4));
					if(Integer.parseInt(fin.substring(1,4))>=300) {// check if address not too large
						fin=Integer.toString(Integer.parseInt(fin.substring(0,1))*1000+299)+" Error: Absolute address exceeds machine size;"
								+ " largest legal value used.";
					}
				}else if(split[k].charAt(4)=='3') {//relocated
					int relo= Integer.parseInt(split[k].substring(0, 4))+base[j];
					fin=(Integer.toString(relo));
				}else if(split[k].charAt(4)=='4') {//resolved
					String users = use.get(j);//module j of uses
					String NU = users.trim();
					String[] NU_split= NU.split("-1"); //split use list
					ArrayList<String> ph= new ArrayList<String>();
					for(int i=0; i< NU_split.length; i++) {// add each symbol use to its own array list
						ph.add(NU_split[i].trim()); 
					}
					int counter = 0;
					for(int x=0; x< ph.size(); x++){
						ArrayList<String> uses = new ArrayList<String>();
						String [] big = ph.get(x).split("\\s+");//split all use module use locations
						uses.addAll(Arrays.asList(big));// add them to an array list
							if(uses.contains(Integer.toString(k-1))) {//if iterating through correct location
								if(symlist.contains(uses.get(0))==false){//if symbol is used but undefined
		                          fin=(Integer.parseInt(split[k].substring(0,1))*1000+111+" Error "+uses.get(0)+" is not defined, 111 is used");
								}else {
								int ind = symlist.indexOf(uses.get(0));
								symbols.get(ind).setUsed(true);// symbol was used
								int locate = (symbols.get(ind).getLoc());
								int reso= (Integer.parseInt(split[k].substring(0,1))*1000)+locate;
								fin=(Integer.toString(reso));
								}
								if(counter ==1) {//if it goes through this loop more than once it has been used
								   fin = fin +" Error: Multiple variables used in instruction; all but last ignored.";
								}
						   counter ++;
						}
					}
				}
				mem.add(fin);
			}
		}
		// print out answers
		
		System.out.println("Table Map:");
		for(int y =0; y< mem.size();y++) {
			System.out.println(y+": "+ mem.get(y));
		}
		
		for(int x =0; x< symbols.size();x++) {// check what symbols were use
			symbol printSymbol=symbols.get(x);
			if(printSymbol.getUsed()==false) {
			System.out.println("Warning: "+printSymbol.getSym()+" was definied in module "+printSymbol.getMod()
			+" but never used");
			}
		}
		
	}
	
}
//Class for each symbol including its's module, location, relative address
//it's used status and any errors related to the symbol
class  symbol {
	String symbol;
	int module;
	int location;
	int relative;
	boolean used;
	String error;
	symbol(String sym,int mod, int loc){
		symbol = sym;
		 module = mod;
		location = loc;
		 used =false;
		 error = " ";
	}
	public int getRel() {
		return relative;
	}
	public void setRel(int rel) {
		relative = rel;
	}
	public String getSym() {
		return symbol;
	}
	public void setSym(String sym) {
		symbol = sym;
	}
	public int getMod() {
		return module;
	}
	public void setMod(int mod) {
		module = mod;
	}
	public int getLoc() {
		return location;
	}
	public void setLoc(int loc) {
		location=loc;
	}
	public boolean getUsed() {
		return used;
	}
	public void setUsed(boolean use) {
		used = use;
	}
	public String getError() {
		return error;
	}
	public void setError(String e) {
		error = error + e;
	}
}