import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class os3 {
	static ArrayList<Task>tasks=new ArrayList<Task>();//for bankers
	static ArrayList<Task>tasks2=new ArrayList<Task>();//for fifo
	public static void main(String[] args) {
		tasks= new ArrayList<Task>();
		tasks2= new ArrayList<Task>();
		String file = args[0];
		int T = 0;//tasks
		int R = 0;//num resource
		int [] U= null; //units of each resource
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			Scanner in = new Scanner(br);
			T=in.nextInt();
			R=in.nextInt();
		    U= new int[R];
			for(int j =0;j<R;j++) {
				U[j]= in.nextInt();
			}
			for (int i = 0; i<T;i++) {
				Task task = new Task();
				Task task2 = new Task();
				task.id=i+1;
				task2.id=i+1;
				tasks.add(task);
				tasks2.add(task2);
			}
			while(in.hasNext()) {
				String line=in.nextLine();
				if(!line.trim().isEmpty()) {
					//System.out.println(line);
					String [] split = line.split("\\s+");//split line
					int id = Integer.parseInt(split[1]);
					tasks.get(id-1).activities.add(split);//add input as array into Task component activities
					tasks2.get(id-1).activities.add(split);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		bankers_algo(T,R,U);
		FIFO(T,R,U);
	}
	
	public static void bankers_algo(int T,int R,int[] U) {
		ArrayList<Task> block = new ArrayList<Task>();//blocked tasks
		ArrayList<Task> ready = tasks;//tasks that are ready
		ArrayList<Task> no_issue = new ArrayList<Task>();//tasks that are not blocked
		ArrayList<Task> terminated = new ArrayList<Task>();//tasks that have been terminated or aborted
		int [] available = new int [R];//matrix to hold the amount of each resource type available
	    int [][] max = new int [T][R];//max demand for each resource of each process
	    int [][] alloc= new int [T][R];//allocated resources for each process
	    int [][] need= new int [T][R];//how much each resource needs
	    int cycle = 0;
	    Task task;
		for (int i =0; i< available.length;i++) {
			available[i]=U[i];//each resource has U units available to start
		}//terminated.size()!=T
		while(terminated.size()!=T) {
			//System.out.println("\nCycle: "+cycle);
			for(int i = 0; i< ready.size();i++) {
				//System.out.println("\n");
				task=ready.get(i);//next task
				int curr=task.actPt;//pointer for the activities array list
				String[] activity=task.activities.get(curr);//get the activity itself
				String type =activity[0];//type of the activity
				//System.out.println("TASK:  "+task.id+"  ACTIVITY:  "+type);
				if(task.end_comp==0) {//not computing
					if(type.equals("initiate")) {
						int resourcetype=Integer.parseInt(activity[2]);
						int resourceclaim=Integer.parseInt(activity[3]);
						if(resourceclaim>U[resourcetype-1]) {//if claim exceeds resource available abort
							task.aborted=true;
							terminated.add(task);
							//System.out.println("ABORTED!!!");
						}else {//otherwise change max for the task's resource
							max[task.id-1][resourcetype-1]=resourceclaim;
							need[task.id-1][resourcetype-1]=resourceclaim;
							task.actPt+=1;//increment pointer by one to get next activity
							no_issue.add(task);
						//	System.out.println("CLAIM: "+resourceclaim);
						}
					}else if(type.equals("request")) {
						int resourcetype=Integer.parseInt(activity[2]);
						int resourcereq=Integer.parseInt(activity[3]);
						int needhold= need[task.id-1][resourcetype-1];//place holder for need
						int availhold= available[resourcetype-1];// place holder for available
//						System.out.println("BEFORE REQ:"
//								+ " AVAILABLE: "+available[resourcetype-1]+"   REQUESTED: "+resourcereq+"  NEED: "+need[task.id-1][resourcetype-1]+
//								"   ALLOC: "+alloc[task.id-1][resourcetype-1]);
						available[resourcetype-1]=available[resourcetype-1]-resourcereq;//next three lines grant the request and change avail, alloc and need
						alloc[task.id-1][resourcetype-1]+=resourcereq;
						need[task.id-1][resourcetype-1]=max[task.id-1][resourcetype-1]-alloc[task.id-1][resourcetype-1];
//						System.out.println("AFTER REQ:"
//								+ " AVAILABLE: "+available[resourcetype-1]+"   REQUESTED: "+resourcereq+"  NEED: "+need[task.id-1][resourcetype-1]+
//								"   ALLOC: "+alloc[task.id-1][resourcetype-1]);
						boolean safe = safe(T,R,available,need,alloc);//check if the granted request was safe
						//System.out.println("IS SAFE?: "+safe);
						if(alloc[task.id-1][resourcetype-1]>max[task.id-1][resourcetype-1]) {//if the request exceeds claim we abort
							available[resourcetype-1]+=alloc[task.id-1][resourcetype-1];
							task.aborted=true;
							terminated.add(task);
							//System.out.println("ABORTED!!! REQUEST EXCEEDS CLAIM");
							continue;
						}
						if(safe==true&&availhold>=resourcereq) {//if we're safe and the availability before the request caused no issues we grant the request
							task.actPt+=1;
							no_issue.add(task);
						}else {//other wise undo the request and block
							available[resourcetype-1]=available[resourcetype-1]+resourcereq;
							alloc[task.id-1][resourcetype-1]-=resourcereq;
							need[task.id-1][resourcetype-1]=needhold;
							task.block_time+=1;
							block.add(task);
							//System.out.println("BLOCKED!! CURRENT BLOCK TIME: "+task.block_time);
						}
					}else if(type.equals("release")) {//release the amount the activity requests
						int resourcetype=Integer.parseInt(activity[2]);
						int resourcerel=Integer.parseInt(activity[3]);
						alloc[task.id-1][resourcetype-1]-=resourcerel;
						available[resourcetype-1]+=resourcerel;
						need[task.id-1][resourcetype-1]=max[task.id-1][resourcetype-1]-alloc[task.id-1][resourcetype-1];
						task.actPt+=1;
						no_issue.add(task);
						//System.out.println("RELEASED: "+resourcerel+" of resource "+resourcetype+" AVAILABLE AFTER RELEASE:"+available[resourcetype-1]);
					}else if(type.equals("terminate")) {//end the process
						task.end=cycle;
						terminated.add(task);
					}else if(type.equals("compute")) {//compute
						task.computing=true;
						task.end_comp=Integer.parseInt(activity[2]);
						--task.end_comp;
						//System.out.println("COMPUTING START! "+task.comp_time+" out of "+task.end_comp+" REMAINING");
						if(task.end_comp==0) {//if it computes for one cycle immediately finish and increment the pointer
							task.computing=false;
							++task.actPt;
						}
						no_issue.add(task);
					}
				}else if(task.end_comp!=0) {//if computing
					--task.end_comp;//add to the timer
					//System.out.println("COMPUTING!"+task.comp_time+" out of "+task.end_comp);
					if(task.end_comp==0) {// time to end computation
						//task.comp_time=0;//reset total computation time
						task.computing=!task.computing;
						task.actPt+=1;//increment pointer
						//System.out.println("FINISHED COMPUTING!!");
					}
					no_issue.add(task);
				}
				
			}
			    ready.clear();// clear ready
	            ready.addAll(block);// add all the blocked tasks to ready first
	            ready.addAll(no_issue);// then add all the unblocked tasks
	            block.clear();//reset for the next cycle
	            no_issue.clear();
	            cycle++;
		}
		int ft=0;//total time across all cycles
		int fb = 0;//total time blocked across all cycles
		Collections.sort(terminated);
		System.out.println("Banker's");
		for(int i = 0;i<terminated.size();i++) {
			terminated.get(i).total_time=cycle;
			terminated.get(i).printAns();
			fb+=terminated.get(i).block_time;//add task's block time to total block time
			ft+=terminated.get(i).end;//add tasks total time
		}
		System.out.printf("total      "+ft+"     "+fb+"     %.0f",((double)fb/ (double)ft) * 100);//print out answer according to specs
		System.out.println("%\n");
	}
	
	public static boolean safe(int T,int R,int [] available,int[][] need, int [][]alloc) {//Algorthim to check for safety of proposed state
		int[] work= new int [R];
		boolean[] finish=new boolean [T];
		for(int i =0;i<R;i++) {
			work[i]=available[i];//Set work to available
		}
		int count = 0;
		while(count<T) {// While count is less than number of tasks
			boolean found = false;
			for(int t =0;t<T;t++) {//iterate through task
				if(finish[t]==false) {
					int j;
					for(j=0;j<R;j++) {
						if(need[t][j]>work[j]) {//if need is larger than currently available we break
							break;
						}
					}
					if(j==R) {// if you did not break all resources in Tasks do not excced the need
						for(int k=0;k<R;k++) {//simulate releasing by adding the allocation
							work[k]+=alloc[t][k];
						}
						finish[t]=true;//mark as finished
						found=true;
						count +=1;//the number of finished tasks increases
					}
				}
			}
			if(found==false) {//if need is ever larger than the available we break and return false
				return false;
			}
			
		}
		return true;
			
	}
	
	public static void FIFO(int T,int R,int[] U) {
		ArrayList<Task> block = new ArrayList<Task>();// array list of tasks that are blocked
		ArrayList<Task> ready = tasks2;// arraylist of tasks that are ready
		ArrayList<Task> no_issue = new ArrayList<Task>();//not blocked, terminated or aborted
		ArrayList<Task> terminated = new ArrayList<Task>();//finished and aborted tasks
		int [] available = new int [R];//matrix to hold the amount of each resource type available
	    int [][] alloc= new int [T][R];//allocated resources for each process
	    int [] pend_release = new int[R];// use to hold released resources at the very end of the cycle as per the specs
	    int cycle = 0;
	    Task task;
		for (int i =0; i< available.length;i++) {
			available[i]=U[i];//each resource has U units available to start
		}//terminated.size()!=T
		while(terminated.size()!=T) {
			//System.out.println("\nCycle: "+cycle);
			for(int i = 0; i< ready.size();i++) {
				//System.out.println("\n");
				task=ready.get(i);
				int curr=task.actPt;
				String[] activity=task.activities.get(curr);
				String type =activity[0];
				//System.out.println("TASK:  "+task.id+"  ACTIVITY:  "+type);
				if(task.computing == false) {
					if(type.equals("initiate")) {	//if initiate advance to next task			
						task.actPt+=1;
						no_issue.add(task);
					}else if(type.equals("request")) {
						int resourcetype=Integer.parseInt(activity[2]);
						int resourcereq=Integer.parseInt(activity[3]);			
						int availhold= available[resourcetype-1];
						if(availhold>=resourcereq) {//there are enough resources left to satisfy request
							available[resourcetype-1]=available[resourcetype-1]-resourcereq;
							alloc[task.id-1][resourcetype-1]+=resourcereq;
							task.actPt+=1;
							no_issue.add(task);
						}else {//block the request if not enough resources
							task.block_time+=1;
							block.add(task);
							//System.out.println("BLOCKED!! CURRENT BLOCK TIME: "+task.block_time);
						}
					}else if(type.equals("release")) {//give away resources as dictated by the activity
						int resourcetype=Integer.parseInt(activity[2]);
						int resourcerel=Integer.parseInt(activity[3]);
						alloc[task.id-1][resourcetype-1]-=resourcerel;
						pend_release[resourcetype-1]+=resourcerel;//add to pend release to release at the end of the cycle
						task.actPt+=1;//advance pointer
						no_issue.add(task);//do not block or terminated
						//System.out.println("RELEASED: "+resourcerel+" of resource "+resourcetype+" AVAILABLE AFTER RELEASE:"+available[resourcetype-1]);
					}else if(type.equals("terminate")) {	
						task.end=cycle;//cycle when the task terminated
						terminated.add(task);//add task to the list of terminated
					}else if(type.equals("compute")) {//Same computing as Banker's
						task.computing=true;
						task.end_comp=Integer.parseInt(activity[2]);
						task.comp_time=1;
						if(task.comp_time==task.end_comp) {
							task.computing=false;
							++task.actPt;
						}
						no_issue.add(task);
					}
				}else if(task.computing==true) {//Same as bankers
					++task.comp_time;
					//System.out.println("COMPUTING!"+task.comp_time+" out of "+task.end_comp);
					if(task.comp_time==task.end_comp) {
						task.comp_time=0;
						task.computing=!task.computing;
						task.actPt+=1;
						//System.out.println("FINISHED COMPUTING!!");
					}
					no_issue.add(task);
				}
				
			}  
			if(block.size()>0&&no_issue.size()==0) {//If everything is blocked there is a deadlock
				int abortions=0;
				int hold= block.size()-1;//abort everything except the largest id
				while(abortions!=hold) {// loop until all but largest id aborted
					int min = 100000000;
					int plc =0;
					for(int i =0; i<block.size();i++) {//get the task from block with the smallest id
						if(block.get(i).id<min) {
							min = block.get(i).id;
							plc=i;
						}
					}
					Task abort=block.get(plc);//abort the smallest id
					block.remove(abort);
					abort.aborted=true;
					for(int i =0;i<R;i++) {
						available[i]+=alloc[abort.id-1][i];//deallocate aborted task's resources
						alloc[abort.id-1][i]=0;
					}
					//abort.block_time=0;// set for the print statement at the end
					//System.out.println("TASK "+abort.id+"Aborted!!");
					abort.block_time=0;
					terminated.add(abort);//end the aborted task
					++abortions;
				}
			}
			for(int i=0;i<R;i++) {//go through and grant the pending releases
				available[i]+=pend_release[i];
				pend_release[i]=0;//  set to 0 for next cycle
			}
			    ready.clear();
	            ready.addAll(block);
	            ready.addAll(no_issue);
	            block.clear();
	            no_issue.clear();
	            cycle++;
		}
		int ft=0;
		int fb = 0;
		Collections.sort(terminated);
		System.out.println("FIFO");
		for(int i = 0;i<terminated.size();i++) {
			terminated.get(i).total_time=cycle;
			terminated.get(i).printAns();
			fb+=terminated.get(i).block_time;
			ft+=terminated.get(i).end;
		}
		System.out.printf("total      "+ft+"     "+fb+"     %.0f",((double)fb/ (double)ft) * 100);
		System.out.println("%");
		
	}
		

}
 class Task implements Comparable<Task>{
	int id;//id for process
	int block_time=0;//how long it has been blocked
	int comp_time = 0;//how long has it been computing
	int end_comp=0;//when to end computation????
	boolean aborted=false;//was it aborted?
	ArrayList<String[]> activities=new ArrayList<String[]>();//Arraylist of every activity for the task
	int actPt=0;//current activity
	int end=0;//cycle when it terminated
	int total_time=0;//total time the algorithim has ram
	boolean computing=false;
	public void printAns(){//print answer according to the spec
		if(aborted) {
			System.out.println("Task "+id+"   aborted");
		}else {
		System.out.printf("Task "+id+"     "+end+"     "+block_time+"     %.0f",((double)block_time/ (double)end) * 100);	
		System.out.println("%");
		} 
	}
	@Override
	public int compareTo(Task o) {//used to sort arraylists if takss
		int ans= this.id-o.id;
		return ans;
	}
}
