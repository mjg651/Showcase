import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Stack;
import java.util.concurrent.LinkedBlockingQueue;

//Mathew Guarneri mjg651

public class schedule {
	private static int num;
	private static ArrayList<proc> processes = null;
	private static Scanner rand_scanner = null;
	private static boolean verbosity = false;
	public static void main(String[] args) throws FileNotFoundException {
		File file = null;
		if(args.length == 1){
			file = new File(args[0]);
			verbosity=false;
		}else if(args[0].equals("--verbose")){
			file = new File(args[1]);
			verbosity=true;
		}else {
			throw new IllegalArgumentException("Arguements not according to problem statement!");
		}
		rand_scanner = new Scanner(new File("random-numbers"));
		processes = Input(file, rand_scanner);
		FCFS(processes,rand_scanner);
		System.out.println("______________________________________________________________\n");
		rand_scanner = new Scanner(new File("random-numbers"));
		processes = Input(file, rand_scanner);
		RR(processes, rand_scanner);
		System.out.println("______________________________________________________________\n");
		rand_scanner = new Scanner(new File("random-numbers"));
		processes = Input(file, rand_scanner);
		LCFS(processes, rand_scanner);
		System.out.println("______________________________________________________________\n");
		rand_scanner = new Scanner(new File("random-numbers"));
		processes = Input(file, rand_scanner);
		HPRN(processes, rand_scanner);
	}

	private static ArrayList<proc> Input(File file, Scanner random_scanner) throws FileNotFoundException {
		ArrayList<proc> processes = new ArrayList<proc>();
		Scanner input = new Scanner(file);
		num = input.nextInt();
		for (int i=0;i<num;i++){
			int A = Integer.parseInt(input.next().replace("(", ""));
			int B = input.nextInt();
			int C = input.nextInt();
			int M = Integer.parseInt(input.next().replace(")", ""));
			processes.add(new proc(i, A, B,C,M));
		}
		System.out.print("The original input was: ");
		System.out.print(processes.size() + " ");
		for(proc p : processes){
			System.out.print(p.toString() + " ");
		}
		return processes;
	}

	private static int randomOS(int u) throws FileNotFoundException {
		int random_int = rand_scanner.nextInt();
		return 1+(random_int % u);
	}

	public static ArrayList<proc> sortProcessListByArrival(ArrayList<proc> processes,boolean print){
		Collections.sort(processes, new Comparator<proc>() {
			public int compare(proc p1, proc p2) {
				if (p1.A == p2.A) {
					return 0;
				}
				return p1.A < p2.A ? -1 : 1;
			}
		});
		if(print == true) {
			System.out.print("\nThe (sorted) input is: ");
			System.out.print(" " + processes.size());
			for(proc p : processes){
				System.out.print(" " + p.toString());
			}
			System.out.println("\n");
		}
		return processes;
	}

	public static ArrayList<proc> sortProcessListById(ArrayList<proc> processes){
		Collections.sort(processes, new Comparator<proc>() {
			public int compare(proc p1, proc p2) {
				if (p1.pid == p2.pid) {
					return 0;
				}
				return p1.pid < p2.pid ? -1 : 1;
			}

		});
		return processes;
	}

	public static ArrayList<proc>tieBreaker(ArrayList<proc> processes){
		Collections.sort(processes, new Comparator<proc>() {
			public int compare(proc p1, proc p2) {
				if (p1.A == p2.A) {
					return p1.pid < p2.pid ? -1 : 1;
				}
				return p1.A < p2.A ? -1 : 1;
			}
		});
		return processes;
	}

	public static void FCFS(ArrayList<proc> processes, Scanner scanner) throws FileNotFoundException {
		int nah=0;
		proc current = null;
		rand_scanner = scanner;
		LinkedBlockingQueue<proc> sort = new LinkedBlockingQueue<proc>();
		LinkedBlockingQueue<proc> ready = new LinkedBlockingQueue<proc>();
		ArrayList<proc> block = new ArrayList<proc>();
		ArrayList<proc> done = new ArrayList<proc>();
		int time=0, cpu_time=0, io_time=0;
		processes = sortProcessListByArrival(processes,true);
		if(verbosity){
			System.out.println("This detailed printout gives the state and remaining burst for each process\n");
		}
		for(int i=0; i<processes.size(); i++){
			processes.get(i).pid = i;
			sort.add(processes.get(i));
		}
		while(done.size() < num){
			if(verbosity){
				System.out.print( "Before cycle " + time + ": ");
				for(proc p : processes){
					int burst;
					if(p.state==proc.blocked){
						burst = p.io_burst;
					}else if(p.state==proc.running){
						burst = p.cpu_burst;
					}else{
						burst = 0;
					}
					System.out.print( p.stateToString() + " " + Integer.toString(burst)+" ");
				}
				System.out.println();
			}
			if(!block.isEmpty()){//doBlocking()
				ArrayList<proc> finished_io = new ArrayList<proc>();
				io_time++;
				for(proc p : block) {
					p.io_burst--;
					p.io_time++;
					if(p.io_burst == 0){
						p.state = proc.ready;
						finished_io.add(p);
					}
				}
				finished_io = tieBreaker(finished_io);
				ready.addAll(finished_io);
				block.removeAll(finished_io);
			}
			if(current != null){
				current.cpu_time--;
				current.cpu_burst--;
				cpu_time++;
				if(current.cpu_time == 0){
					current.state = proc.done;
					current.finishing_time = time;
					done.add(current);
					current = null;
				}else if(current.cpu_burst == 0){
					current.state = proc.blocked;
					block.add(current);
					current.io_burst = nah*current.M;
					current = null;
				}

			}while (!sort.isEmpty() && sort.peek().A == time){
				proc p = sort.poll();
				p.state = proc.ready;
				ready.add(p);
			}if(current == null && !ready.isEmpty()){
				if(ready.peek().A != time || time == 0){
					proc p = ready.poll();
					current = p;
					p.state = proc.running;
					current.cpu_burst = randomOS(current.B);
					nah=current.cpu_burst;
				}
			}
			time++;
		}
		done = sortProcessListById(done);
		System.out.println("The scheduling algorithm used was First Come First Served\n");
		printAns(done,time,cpu_time,io_time);
	}

	public static void printAns(ArrayList<proc> done,int cycle, int cpu_cycles,int io_cycles) {
		for(proc p : done){
			p.turnaround_time = p.finishing_time-p.A;
			p.waiting_time = p.finishing_time-p.C-p.io_time-p.A;
			System.out.println(p.summary() + "\n");
		}
		float avg_turnaround = 0;
		float avg_waiting = 0;
		for(proc p : done){
			avg_turnaround += p.turnaround_time;
			avg_waiting += p.waiting_time;
		}
		avg_turnaround = avg_turnaround / num;
		avg_waiting = avg_waiting / num;
		System.out.println("Summary Data: ");
		System.out.println("Finishing time: " + (cycle-1));
		System.out.print("CPU Utilization: ");
		System.out.printf("%.6f",(float)cpu_cycles/(cycle - 1));
		System.out.println();
		System.out.print("I/O Utilization: ");
		System.out.printf("%.6f", (float)io_cycles/(cycle - 1));
		System.out.println();
		System.out.print("Throughput: ");
		System.out.printf("%.6f", (float)num/(cycle-1) * 100);
		System.out.println(" processes per hundred cycles");
		System.out.print("Average turnaround time: ");
		System.out.printf("%.6f", avg_turnaround);
		System.out.println();
		System.out.print("Average waiting time: ");
		System.out.printf("%.6f", avg_waiting);
		System.out.println();
	}

	public static void RR(ArrayList<proc> processes, Scanner scanner) throws FileNotFoundException {
		int nah=0;
		rand_scanner = scanner;
		proc current = null;
		LinkedBlockingQueue<proc> sort = new LinkedBlockingQueue<proc>();
		LinkedBlockingQueue<proc>ready = new LinkedBlockingQueue<proc>();
		ArrayList<proc> blocked = new ArrayList<proc>();
		ArrayList<proc> done = new ArrayList<proc>();
		int time=0, cpu_time=0, io_time=0;
		processes = sortProcessListByArrival(processes,true);
		if(verbosity){
			System.out.println("This detailed printout gives the state and remaining burst for each process\n");
		}
		for(int i=0; i<processes.size(); i++){
			processes.get(i).pid = i;
			sort.add(processes.get(i));
		}
		while(done.size() < num){
			ArrayList<proc> add_to_ready = new ArrayList<proc>();
			if(verbosity){
				System.out.print("Before cycle " + time + ": ");
				for(proc p : processes){
					if(p.state==proc.blocked){
						System.out.print(p.stateToString() + " " + Integer.toString(p.io_burst)+" ");
					}else if(p.state==proc.running){
						System.out.print(p.stateToString() + " " + Integer.toString(Math.min(p.cpu_burst, p.quantum))+" ");
					}else{
						int burst = 0;
						System.out.print(p.stateToString() + " " + Integer.toString(Math.min(burst, p.quantum))+" ");
					}
				}
				System.out.println();
			}
			if(!blocked.isEmpty()){//do_blocked()
				ArrayList<proc> finished_io = new ArrayList<proc>();
				io_time++;
				for(proc p : blocked) {
					p.io_burst--;
					p.io_time++;
					if(p.io_burst == 0){
						p.state = proc.ready;
						finished_io.add(p);
					}
				}
				finished_io = tieBreaker(finished_io);
				add_to_ready.addAll(finished_io);
				blocked.removeAll(finished_io);
			}
			if(current != null){//do_running
				current.cpu_time--;
				current.cpu_burst--;
				cpu_time++;
				current.quantum--;
				if(current.cpu_time == 0){
					current.state = proc.done;
					current.finishing_time = time;
					done.add(current);
					current = null;
				}else if(current.cpu_burst == 0){
					current.state = proc.blocked;
					blocked.add(current);
					current.io_burst = nah*current.M;
					current = null;
				} else if(current.quantum == 0){
					current.state = proc.ready;
					add_to_ready.add(current);
					current = null;
				}
			}
			while (!sort.isEmpty() && sort.peek().A == time){//do_arriving
				proc p = sort.poll();
				p.state = proc.ready;
				add_to_ready.add(p);
			}
			add_to_ready = tieBreaker(add_to_ready);
			ready.addAll(add_to_ready);
			if(current == null && !ready.isEmpty()){//do ready
				if(ready.peek().A != time || time == 0){
					proc p = ready.poll();
					current = p;
					p.state = proc.running;
					current.cpu_burst = randomOS(current.B);
					nah=current.cpu_burst;
					current.quantum = 2;
				}

			}
			time++;
		}
		done = sortProcessListById(done);
		System.out.println("The scheduling algorithm used was Round Robin\n");
		printAns(done,time,cpu_time,io_time);
	}

	public static void LCFS(ArrayList<proc> processes, Scanner scanner) throws FileNotFoundException {
		int nah =0;
		rand_scanner = scanner;
		proc current = null;
		LinkedList<proc> sort = new LinkedList<proc>();
		Stack<proc> ready = new Stack<proc>();
		ArrayList<proc> blocked = new ArrayList<proc>();
		ArrayList<proc> done = new ArrayList<proc>();
		int time=0, cpu_time=0, io_time=0;
		processes = sortProcessListByArrival(processes,true);
		processes = sortProcessListByArrivalRev(processes);
		if(verbosity){
			System.out.println("This detailed printout gives the state and remaining burst for each process\n");
		}
		for(int i=0; i<processes.size(); i++){
			sort.add(processes.get(i));
		}
		ArrayList<proc> asc_processes = sortProcessListByArrival(processes,false);
		for(int i=0; i<asc_processes.size(); i++){
			asc_processes.get(i).pid = i;
		}
		while(done.size() < num){
			ArrayList<proc> add_to_ready = new ArrayList<proc>();
			if(verbosity){
				System.out.print( "Before cycle " + time + ": ");
				for(int i=0; i<processes.size(); i++){
					int burst;
					if(processes.get(i).state==proc.blocked){
						burst = processes.get(i).io_burst;
					} else if(processes.get(i).state==proc.running){
						burst = processes.get(i).cpu_burst;
					}else{
						burst = 0;
					}
					System.out.print(processes.get(i).stateToString() + " " + Integer.toString(burst)+" ");
				}
				System.out.println();
			}
			if(!blocked.isEmpty()){// do Blocked()
				ArrayList<proc> finished_io = new ArrayList<proc>();
				io_time++;
				for(proc p : blocked) {
					p.io_burst--;
					p.io_time++;
					if(p.io_burst == 0){
						p.state = proc.ready;
						finished_io.add(p);
					}
				}             
				add_to_ready.addAll(finished_io);
				blocked.removeAll(finished_io);
			} 
			if(current != null){// do Running()
				current.cpu_time--;
				current.cpu_burst--;
				cpu_time++;
				if(current.cpu_time == 0){
					current.state = proc.done;
					current.finishing_time = time;
					done.add(current);
					current = null;
				} else if(current.cpu_burst == 0){
					current.state = proc.blocked;
					blocked.add(current);
					current.io_burst = nah*current.M;
					current = null;
				}

			}
			while (!sort.isEmpty() && sort.peekLast().A == time){//do_arriving()
				proc p = sort.getLast();
				sort.remove(p);
				p.state = proc.ready;
				add_to_ready.add(p);
			}
			add_to_ready = tieBreakerRev(add_to_ready);
			ready.addAll(add_to_ready);
			if(current == null && !ready.isEmpty()){//do_ready
				if(!ready.isEmpty() || time == 0){
					proc p = ready.pop();
					current = p;
					p.state = proc.running;
					current.cpu_burst = randomOS(current.B);
					nah = current.cpu_burst;
				}

			}
			time++;
		}
		done = sortProcessListById(done);
		System.out.println("The scheduling algorithm used was Last Come First Served\n");
		printAns(done,time,cpu_time,io_time);
	}

	public static ArrayList<proc> sortProcessListByArrivalRev(ArrayList<proc> processes){
		Collections.sort(processes, new Comparator<proc>() {
			public int compare(proc p1, proc p2) {
				if (p1.A == p2.A) {
					return 0;
				}
				return p1.A > p2.A ? -1 : 1;
			}
		});
		return processes;
	}

	public static ArrayList<proc> tieBreakerRev(ArrayList<proc> processes){
		Collections.sort(processes, new Comparator<proc>() {
			public int compare(proc p1, proc p2) {
				if (p1.A == p2.A) {
					return p1.pid > p2.pid ? -1 : 1;
				}
				return p1.A > p2.A ? -1 : 1;
			}
		});
		return processes;
	}

	public static void HPRN(ArrayList<proc> processes, Scanner scanner) throws FileNotFoundException {
		int nah = 0;
		rand_scanner = scanner;
		proc current = null;
		LinkedBlockingQueue<proc> sort = new LinkedBlockingQueue<proc>();
		ArrayList<proc> ready = new ArrayList<proc>();
		ArrayList<proc> block = new ArrayList<proc>();
		ArrayList<proc> done = new ArrayList<proc>();
		int cycle = 0;
		int cpu_cycles = 0;
		int io_cycles = 0;
		processes = sortProcessListByArrival(processes,true);     
		if(verbosity){
			System.out.println("This detailed printout gives the state and remaining burst for each process\n");
		}
		for(int i=0; i<processes.size(); i++){
			processes.get(i).pid = i;
			sort.add(processes.get(i));
		}
		while(done.size() < num){
			if(verbosity){
				System.out.print( "Before cycle " + cycle + ": ");
				for(proc p : processes){
					int burst;
					if(p.state==proc.blocked){
						burst = p.io_burst;
					}else if(p.state==proc.running){
						burst = p.cpu_burst;
					}else{
						burst = 0;
					}
					System.out.print( p.stateToString() + " " + Integer.toString(burst)+" ");
				}
				System.out.println();
			}
			if(!block.isEmpty()){//do_blocked
				ArrayList<proc> finished_io = new ArrayList<proc>();
				io_cycles++;
				for(proc p : block) {
					p.io_burst--;
					p.io_time++;
					if(p.io_burst == 0){
						p.state = proc.ready;
						finished_io.add(p);
					}
				}
				finished_io = tieBreaker(finished_io);
				ready.addAll(finished_io);
				block.removeAll(finished_io);
			}
			if(current!= null){
				current.cpu_time--;
				current.cpu_burst--;
				cpu_cycles++;
				if(current.cpu_time == 0){
					current.state = proc.done;
					current.finishing_time = cycle;
					done.add(current);
					current = null;
				} else if(current.cpu_burst == 0){
					current.state = proc.blocked;
					block.add(current);
					current.io_burst = nah*current.M;
					current = null;
				}
			}
			while (!sort.isEmpty() && sort.peek().A == cycle){
				proc p = sort.poll();
				p.state = proc.ready;
				ready.add(p);
			}
			if(current == null && !ready.isEmpty()){
				for(proc p : ready){
					p.penalty_ratio = ((float)(cycle-p.A))/Math.max(1,p.C-p.cpu_time);
				}
				ready = tieBreaker(ready);
				float max_penalty_ratio = -1;
				int max_loc=0;
				for(int i=0; i<ready.size(); i++){
					if(ready.get(i).penalty_ratio > max_penalty_ratio){
						max_penalty_ratio = ready.get(i).penalty_ratio;
						max_loc = i;
					}
				}
				current = ready.get(max_loc);
				ready.get(max_loc).state = proc.running;
				ready.remove(max_loc);
				current.cpu_burst = randomOS(current.B);
				nah=current.cpu_burst;
			}
			cycle++;
		}
		done = sortProcessListById(done);
		System.out.println("The scheduling algorithm used was Highest Penalty Ratio Next\n");
		printAns( done, cycle, cpu_cycles,io_cycles);
	}

}

class proc{ 
	public static int unstarted = -1;
	public static int running = 0;
	public static int ready = 1;
	public static int blocked = 2;
	public static int done = 3;
	public int pid;
	public int state;
	public float penalty_ratio;
	public int quantum;
	public int A;
	public int B;
	public int C;
	public int M;
	public int cpu_time;
	public int cpu_burst;
	public int io_burst = -1;
	public int waiting_time = 0;
	public int finishing_time;
	public int turnaround_time;
	public int io_time;
	public proc(int pid, int a, int b, int c, int m){
		this.pid = pid;
		this.A = a;
		this.B = b;
		this.C = c;
		this.M = m;
		this.state = unstarted;
		this.cpu_time = c;
	}
	public String toString(){
		return " ("+Integer.toString(A) + " " + Integer.toString(B) + " " + Integer.toString(C) + " " + Integer.toString(M)+")";
	}
	public String stateToString() {
		if (this.state==-1) return "unstarted";
		else if(this.state==0)return "running";
		else if(this.state==1)return "ready";
		else if(this.state==2)return "blocked";
		else return "done";
	}
	public String summary(){
		String outputstring = "Process: " + pid;
		outputstring += "\n(A,B,C,M) = " + "(" + A + "," + B + "," + C + "," + M + ")";
		outputstring += "\nFinishing time: " + finishing_time;
		outputstring += "\nTurnaround time: " + turnaround_time;
		outputstring += "\nI/O time: " + io_time;
		outputstring += "\nWaiting time: " + waiting_time;
		return outputstring;
	}

}

