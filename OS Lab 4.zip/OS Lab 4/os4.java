import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;


public class os4 {
	static Process [] processes;
	static int M; //machine size
	static int P; //page size
	static int J; // job mix
	static int S; //process size
	static int N; // ref number
	static String R;//algo
	static FrameTable table;
	static Scanner random;
	public static void main(String[] args) throws FileNotFoundException {
		random = new Scanner(new FileReader("random-numbers"));
		M = Integer.parseInt(args[0]);
		P = Integer.parseInt(args[1]);
		S = Integer.parseInt(args[2]);
		J = Integer.parseInt(args[3]);
		N = Integer.parseInt(args[4]);
		R = args[5];
		table = new FrameTable(M,P,R,random);
		System.out.println("The machine size is " + M);
		System.out.println("The page size is " + P);
		System.out.println("The process size is " + S);
		System.out.println("The job mix number is " + J);
		System.out.println("The number of references per process is " + N);
		System.out.println("The replacement algorithm is " + R);
		System.out.println("The level of debugging output is 0\n");	
		run();
	}

	public static void run() {
		if (J == 1) {//if mix is simple
			Process process= new Process(S,1);
			process.A=1;
			processes=new Process[1];
		    processes[0]=process;
			//System.ou't.println(processes.length);
			for (int cycle = 1; cycle <N+1; cycle++) {//one ref per cycle
				int page = process.word / P;			
				if (table.checkFault(page, 1, cycle)) {
					table.replace(processes, page, 1, cycle);
					process.faults++;
				}
				process.computeNext(random);
			}
		} 
		else if(J==2 || J==3 || J==4 ){//if mix is not simple
			processes = new Process[4];
			for(int i=0;i<4;i++){
				Process process= new Process(S, i+1);
				processes[i] = process;
			}
			RR();//start the round robin
		}
		int numEvictions = 0;
		int numFaults = 0;
		int numResidency = 0;	
		//Start printing here
		for (int i = 0; i < processes.length; i++) {
			if (processes[i].evictions > 0) {
				double avgRes= (double) processes[i].residency/processes[i].evictions;
				System.out.println("Process "+(i + 1)+" had "+ processes[i].faults+" faults and "+ avgRes +" average residency.");
			}else {
				System.out.println("Process " +(i + 1)+" had "+processes[i].faults+ " faults.\n With no evictons, the average residencey is undefined.");
			}
			numEvictions+=processes[i].evictions;
			numFaults+= processes[i].faults;
			numResidency+=processes[i].residency;
		}		
		if (numEvictions > 0) {
			double totalAverageResidency = (double)numResidency / numEvictions;
			System.out.println("\nThe total number of faults is "+ numFaults+ " and the overall average residency is " + totalAverageResidency);
		}else {
			System.out.println("\nThe total number of faults is"+numFaults+" faults .\n With no evictons, the overall average residency is undefined.");
		}
	}
	public static void RR(){
		if(J == 2){ //initialize based on job mix
			for(int i=0;i<4;i++){
				processes[i].A = 1;
			}
		}else if(J == 3){		
			//already all 0
		}else if(J == 4){
			processes[0].A = 0.75;
			processes[0].B = 0.25;  
			processes[0].C = 0;
			processes[1].A = 0.75;
			processes[1].B = 0; 
			processes[1].C = 0.25;
			processes[2].A = 0.75;
			processes[2].B = 0.125;
			processes[2].C = 0.125;
			processes[3].A = 0.5;
			processes[3].B = 0.125;
			processes[3].C = 0.125;
		}
		for (int cycle = 0; cycle <=N/3; cycle++) {//round robin--> num ref/quant
			int base = 4*cycle*3;//used to keep track of time num_procs *num_cycle*quantum
			for(int j=0;j<4;j++){//number of processes
				int refs;
				if(cycle!=N/3){
					refs = 3;//number of references to be processed for each process
				}else{//last cycle
					refs = N%3;
				}
				for (int i = 0; i < refs; i++) {
					int t=(base+(i+1))+(j * refs);//for each reference processed time increments by one starting at t=1
					int page=processes[j].word/P;
					if (table.checkFault(page,j+1,t)) {
						table.replace(processes, page, j+1, t);
						processes[j].faults++;
					}
					processes[j].computeNext(random);
				}
			}
		}
	}
}

class Process {
	int size;
	int word;
	int faults;
	int evictions;
	int residency;
	double A=0;
	double B=0;
	double C=0;

	public Process(int size, int name) {
		this.size = size;
		this.word = (111*name) % size;
		this.faults = 0;
		this.evictions = 0;
		this.residency = 0;
	}

	public void computeNext(Scanner random) {
		int r = random.nextInt();
		double y = r/(Integer.MAX_VALUE + 1d);
		if (y < A) {//case 1
			word = (word+1)%size;
		} else if (y < A + B) {//case 2
			word = (word-5+size) % size;
		} else if (y < A + B + C) {//case 3
			word = (word + 4) % size;
		} else {
			int r2 =random.nextInt() % size;//case 4
			word = r2;
		}
	}

}

class FrameTable {
	int frames;
	ArrayList<int[]> frameTable;
	boolean lru = false;
	boolean lifo = false;
	boolean rand = false;
	Scanner random;
	Stack<int[]> lifoStack;
	public FrameTable(int M,int P,String R,Scanner random){
		frames = M/P;
		frameTable = new ArrayList<int[]>();
		lifoStack = new Stack<int[]>();
		if(R.equals("lru")){
			lru=true;
		}else if(R.equals("lifo")){
			lifo=true;
		}else if(R.equals("random")){
			rand=true;
		}
		for(int i = 0;i<frames;i++) {//initialize frame table
			int [] toAdd = new int [4];
			frameTable.add(toAdd);
		}
		this.random=random;
	}
	public boolean checkFault(int page, int pro_num, int time) {
		for (int i = 0; i < frameTable.size(); i++) {
			int[] framePage = frameTable.get(i);
			if ((framePage[0] == page) && (framePage[1] == pro_num)) {
				if(lru) {
					frameTable.get(i)[2] = time;//modify for lru
				}
				return false;//page is in the table
			}
		}
		return true;//page is NOT in the table
	}

	public void replace(Process[] processes, int page, int pro_num, int time) {
		if(lru) {
			lruReplace(processes,page,pro_num,time);
		}else if (rand) {
			randomReplace(processes,page,pro_num,time);
		}else if (lifo) {
            lifoReplace(processes,page,pro_num,time);
		}

	}

	public void lruReplace(Process[] processes, int page, int pro_num, int time) {
		int lr = time;
		int toReplace = 0;
		for (int i=frames-1; i >= 0; i--) {
			int [] p = frameTable.get(i);
			if ((p[0] == 0) && (p[1] == 0)) {
				p[0] = page;
				p[1] = pro_num;
				p[2] = time;
				p[3] = time;
				return;
			}else if (lr > p[2]) {
				toReplace = i;
				lr = p[2];
			}
		}
		int ev_pro[] = frameTable.get(toReplace);
		Process proc = processes[ev_pro[1] - 1];
		proc.evictions++;
		int load = ev_pro[3];
		ev_pro[0] = page;
		ev_pro[1] = pro_num;
		ev_pro[2] = time;
		ev_pro[3] = time;
		int residency = time - load;
		proc.residency+=residency;	
	}

	public void randomReplace(Process[] processes, int page, int pro_num,int time) {
		for (int i=frames-1; i >= 0; i--) {
			int [] p = frameTable.get(i);
			if ((p[0] == 0) && (p[1] == 0)) {
				p[0] = page;
				p[1] = pro_num;
				p[2] = time;
				p[3] = time;
				return;
			}
		}	
		int r = random.nextInt();
		int ev_pro []= frameTable.get(r%frames);
		Process proc = processes[ev_pro[1] - 1];
		proc.evictions++;
		int loadTime = ev_pro[2];
		ev_pro[0] = page;
		ev_pro[1] = pro_num;
		ev_pro[2] = time;
		ev_pro[3] = time;
		int residencyTime = time - loadTime;
		proc.residency+=residencyTime;
	}

	public void lifoReplace(Process[] processes, int page, int pro_num,int time) {
		if(lifoStack.size()==frames) {//no vacancy
			int[] evictedFrame = lifoStack.pop();
			int evicted_pro_num = evictedFrame[1];
			Process evictedProcess = processes[evicted_pro_num - 1];
			evictedProcess.evictions++;
			int loadTime = evictedFrame[2];
			int residencyTime = time - loadTime;
			evictedProcess.residency+=residencyTime;
			int ind = frameTable.indexOf(evictedFrame);
			frameTable.get(ind)[0]=0;
			frameTable.get(ind)[1]=0;
		}
		for (int i = 0; i <= frames-1; i++) {
			if ((frameTable.get(i)[0] == 0) && (frameTable.get(i)[1] == 0)) {//replace empty
				frameTable.get(i)[0] = page;
				frameTable.get(i)[1] = pro_num;
				frameTable.get(i)[2] = time;
				lifoStack.add(frameTable.get(i));
				return;
			}
		}
	
	}

}