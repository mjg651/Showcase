import re
filename = input("Specify file or file path: ")
pattern  = '\+?[1]?[-\s]?\(?\d{3}?\)?[-\s]?\d{3}[-\s]?\d{4}'
new_file = []

with open(filename, 'r') as f:
   
   lines = f.readlines()


for line in lines:

    match = re.search(pattern, line)
    if match:
        new_line = match.group() + '\n'
        print (new_line)
        new_file.append(new_line)
