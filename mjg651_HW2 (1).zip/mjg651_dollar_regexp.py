import re
filename = input("Specify file or file path: ")
pattern  = '(([a-zA-Z]+|[1-9]+)\s((hundred)*\s?(thousand)*\s?(million)*\s?(billion)*)\s?((dollars)|(cents)))|\$(([0-9]{1,3})(\,[0-9]{3})*|([0-9]{1,2}))(\.[0-9]{2})?'
new_file = []

#open file and put it to lines
with open(filename, 'r') as f:
   
   lines = f.readlines()

#search for matches using regex patterm
for line in lines:

    match = re.search(pattern, line)
    if match:
        new_line = match.group() + '\n'
        print (new_line)
        new_file.append(new_line)

